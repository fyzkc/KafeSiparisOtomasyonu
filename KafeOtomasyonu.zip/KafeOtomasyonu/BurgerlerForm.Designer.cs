﻿
namespace KafeOtomasyonu
{
    partial class BurgerlerForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(BurgerlerForm));
            this.splitBurger = new System.Windows.Forms.SplitContainer();
            this.btnMenuDon3 = new System.Windows.Forms.Button();
            this.dgwBurger = new System.Windows.Forms.DataGridView();
            this.lblTripleBurger = new System.Windows.Forms.Label();
            this.lblDubleBurger = new System.Windows.Forms.Label();
            this.lblMantarBurger = new System.Windows.Forms.Label();
            this.lblBarbekuBurger = new System.Windows.Forms.Label();
            this.lblVeganBurger = new System.Windows.Forms.Label();
            this.lblChickenBurger = new System.Windows.Forms.Label();
            this.btnTripleBurger = new System.Windows.Forms.Button();
            this.btnDubleBurger = new System.Windows.Forms.Button();
            this.btnMantarBurger = new System.Windows.Forms.Button();
            this.lblCheeseBurger = new System.Windows.Forms.Label();
            this.btnBarbekuBurger = new System.Windows.Forms.Button();
            this.btnVeganBurger = new System.Windows.Forms.Button();
            this.btnChickenBurger = new System.Windows.Forms.Button();
            this.btnCheeseBurger = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.splitBurger)).BeginInit();
            this.splitBurger.Panel1.SuspendLayout();
            this.splitBurger.Panel2.SuspendLayout();
            this.splitBurger.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgwBurger)).BeginInit();
            this.SuspendLayout();
            // 
            // splitBurger
            // 
            this.splitBurger.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitBurger.Location = new System.Drawing.Point(0, 0);
            this.splitBurger.Name = "splitBurger";
            // 
            // splitBurger.Panel1
            // 
            this.splitBurger.Panel1.Controls.Add(this.dgwBurger);
            // 
            // splitBurger.Panel2
            // 
            this.splitBurger.Panel2.Controls.Add(this.btnMenuDon3);
            this.splitBurger.Panel2.Controls.Add(this.lblTripleBurger);
            this.splitBurger.Panel2.Controls.Add(this.lblDubleBurger);
            this.splitBurger.Panel2.Controls.Add(this.lblMantarBurger);
            this.splitBurger.Panel2.Controls.Add(this.lblBarbekuBurger);
            this.splitBurger.Panel2.Controls.Add(this.lblVeganBurger);
            this.splitBurger.Panel2.Controls.Add(this.lblChickenBurger);
            this.splitBurger.Panel2.Controls.Add(this.btnTripleBurger);
            this.splitBurger.Panel2.Controls.Add(this.btnDubleBurger);
            this.splitBurger.Panel2.Controls.Add(this.btnMantarBurger);
            this.splitBurger.Panel2.Controls.Add(this.lblCheeseBurger);
            this.splitBurger.Panel2.Controls.Add(this.btnBarbekuBurger);
            this.splitBurger.Panel2.Controls.Add(this.btnVeganBurger);
            this.splitBurger.Panel2.Controls.Add(this.btnChickenBurger);
            this.splitBurger.Panel2.Controls.Add(this.btnCheeseBurger);
            this.splitBurger.Size = new System.Drawing.Size(1255, 657);
            this.splitBurger.SplitterDistance = 326;
            this.splitBurger.TabIndex = 2;
            // 
            // btnMenuDon3
            // 
            this.btnMenuDon3.BackColor = System.Drawing.Color.Snow;
            this.btnMenuDon3.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.btnMenuDon3.Location = new System.Drawing.Point(775, 595);
            this.btnMenuDon3.Name = "btnMenuDon3";
            this.btnMenuDon3.Size = new System.Drawing.Size(138, 50);
            this.btnMenuDon3.TabIndex = 3;
            this.btnMenuDon3.Text = "Geri";
            this.btnMenuDon3.UseVisualStyleBackColor = false;
            this.btnMenuDon3.Click += new System.EventHandler(this.btnMenuDon3_Click);
            // 
            // dgwBurger
            // 
            this.dgwBurger.BackgroundColor = System.Drawing.Color.Snow;
            this.dgwBurger.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgwBurger.Location = new System.Drawing.Point(12, 12);
            this.dgwBurger.Name = "dgwBurger";
            this.dgwBurger.RowHeadersWidth = 62;
            this.dgwBurger.RowTemplate.Height = 28;
            this.dgwBurger.Size = new System.Drawing.Size(297, 503);
            this.dgwBurger.TabIndex = 2;
            // 
            // lblTripleBurger
            // 
            this.lblTripleBurger.AutoSize = true;
            this.lblTripleBurger.BackColor = System.Drawing.Color.Snow;
            this.lblTripleBurger.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.lblTripleBurger.Location = new System.Drawing.Point(463, 350);
            this.lblTripleBurger.Name = "lblTripleBurger";
            this.lblTripleBurger.Size = new System.Drawing.Size(34, 23);
            this.lblTripleBurger.TabIndex = 17;
            this.lblTripleBurger.Text = "80";
            // 
            // lblDubleBurger
            // 
            this.lblDubleBurger.AutoSize = true;
            this.lblDubleBurger.BackColor = System.Drawing.Color.Snow;
            this.lblDubleBurger.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.lblDubleBurger.Location = new System.Drawing.Point(275, 350);
            this.lblDubleBurger.Name = "lblDubleBurger";
            this.lblDubleBurger.Size = new System.Drawing.Size(34, 23);
            this.lblDubleBurger.TabIndex = 16;
            this.lblDubleBurger.Text = "60";
            // 
            // lblMantarBurger
            // 
            this.lblMantarBurger.AutoSize = true;
            this.lblMantarBurger.BackColor = System.Drawing.Color.Snow;
            this.lblMantarBurger.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.lblMantarBurger.Location = new System.Drawing.Point(87, 350);
            this.lblMantarBurger.Name = "lblMantarBurger";
            this.lblMantarBurger.Size = new System.Drawing.Size(34, 23);
            this.lblMantarBurger.TabIndex = 15;
            this.lblMantarBurger.Text = "45";
            // 
            // lblBarbekuBurger
            // 
            this.lblBarbekuBurger.AutoSize = true;
            this.lblBarbekuBurger.BackColor = System.Drawing.Color.Snow;
            this.lblBarbekuBurger.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.lblBarbekuBurger.Location = new System.Drawing.Point(651, 165);
            this.lblBarbekuBurger.Name = "lblBarbekuBurger";
            this.lblBarbekuBurger.Size = new System.Drawing.Size(34, 23);
            this.lblBarbekuBurger.TabIndex = 14;
            this.lblBarbekuBurger.Text = "55";
            // 
            // lblVeganBurger
            // 
            this.lblVeganBurger.AutoSize = true;
            this.lblVeganBurger.BackColor = System.Drawing.Color.Snow;
            this.lblVeganBurger.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.lblVeganBurger.Location = new System.Drawing.Point(463, 165);
            this.lblVeganBurger.Name = "lblVeganBurger";
            this.lblVeganBurger.Size = new System.Drawing.Size(34, 23);
            this.lblVeganBurger.TabIndex = 13;
            this.lblVeganBurger.Text = "40";
            // 
            // lblChickenBurger
            // 
            this.lblChickenBurger.AutoSize = true;
            this.lblChickenBurger.BackColor = System.Drawing.Color.Snow;
            this.lblChickenBurger.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.lblChickenBurger.Location = new System.Drawing.Point(275, 165);
            this.lblChickenBurger.Name = "lblChickenBurger";
            this.lblChickenBurger.Size = new System.Drawing.Size(34, 23);
            this.lblChickenBurger.TabIndex = 12;
            this.lblChickenBurger.Text = "35";
            // 
            // btnTripleBurger
            // 
            this.btnTripleBurger.BackColor = System.Drawing.Color.Snow;
            this.btnTripleBurger.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.btnTripleBurger.Location = new System.Drawing.Point(389, 197);
            this.btnTripleBurger.Name = "btnTripleBurger";
            this.btnTripleBurger.Size = new System.Drawing.Size(182, 150);
            this.btnTripleBurger.TabIndex = 10;
            this.btnTripleBurger.Text = "Triple Burger";
            this.btnTripleBurger.UseVisualStyleBackColor = false;
            this.btnTripleBurger.Click += new System.EventHandler(this.btnTripleBurger_Click);
            // 
            // btnDubleBurger
            // 
            this.btnDubleBurger.BackColor = System.Drawing.Color.Snow;
            this.btnDubleBurger.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.btnDubleBurger.Location = new System.Drawing.Point(201, 197);
            this.btnDubleBurger.Name = "btnDubleBurger";
            this.btnDubleBurger.Size = new System.Drawing.Size(182, 150);
            this.btnDubleBurger.TabIndex = 9;
            this.btnDubleBurger.Text = "Duble Burger";
            this.btnDubleBurger.UseVisualStyleBackColor = false;
            this.btnDubleBurger.Click += new System.EventHandler(this.btnDubleBurger_Click);
            // 
            // btnMantarBurger
            // 
            this.btnMantarBurger.BackColor = System.Drawing.Color.Snow;
            this.btnMantarBurger.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.btnMantarBurger.Location = new System.Drawing.Point(13, 197);
            this.btnMantarBurger.Name = "btnMantarBurger";
            this.btnMantarBurger.Size = new System.Drawing.Size(182, 150);
            this.btnMantarBurger.TabIndex = 8;
            this.btnMantarBurger.Text = "Mantar Burger";
            this.btnMantarBurger.UseVisualStyleBackColor = false;
            this.btnMantarBurger.Click += new System.EventHandler(this.btnMantarBurger_Click);
            // 
            // lblCheeseBurger
            // 
            this.lblCheeseBurger.AutoSize = true;
            this.lblCheeseBurger.BackColor = System.Drawing.Color.Snow;
            this.lblCheeseBurger.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.lblCheeseBurger.Location = new System.Drawing.Point(87, 165);
            this.lblCheeseBurger.Name = "lblCheeseBurger";
            this.lblCheeseBurger.Size = new System.Drawing.Size(34, 23);
            this.lblCheeseBurger.TabIndex = 7;
            this.lblCheeseBurger.Text = "40";
            // 
            // btnBarbekuBurger
            // 
            this.btnBarbekuBurger.BackColor = System.Drawing.Color.Snow;
            this.btnBarbekuBurger.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.btnBarbekuBurger.Location = new System.Drawing.Point(577, 12);
            this.btnBarbekuBurger.Name = "btnBarbekuBurger";
            this.btnBarbekuBurger.Size = new System.Drawing.Size(182, 150);
            this.btnBarbekuBurger.TabIndex = 6;
            this.btnBarbekuBurger.Text = "Barbekü Burger";
            this.btnBarbekuBurger.UseVisualStyleBackColor = false;
            this.btnBarbekuBurger.Click += new System.EventHandler(this.btnBarbekuBurger_Click);
            // 
            // btnVeganBurger
            // 
            this.btnVeganBurger.BackColor = System.Drawing.Color.Snow;
            this.btnVeganBurger.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.btnVeganBurger.Location = new System.Drawing.Point(389, 12);
            this.btnVeganBurger.Name = "btnVeganBurger";
            this.btnVeganBurger.Size = new System.Drawing.Size(182, 150);
            this.btnVeganBurger.TabIndex = 2;
            this.btnVeganBurger.Text = "Vegan Burger";
            this.btnVeganBurger.UseVisualStyleBackColor = false;
            this.btnVeganBurger.Click += new System.EventHandler(this.btnVeganBurger_Click);
            // 
            // btnChickenBurger
            // 
            this.btnChickenBurger.BackColor = System.Drawing.Color.Snow;
            this.btnChickenBurger.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.btnChickenBurger.Location = new System.Drawing.Point(201, 12);
            this.btnChickenBurger.Name = "btnChickenBurger";
            this.btnChickenBurger.Size = new System.Drawing.Size(182, 150);
            this.btnChickenBurger.TabIndex = 1;
            this.btnChickenBurger.Text = "Chicken Burger";
            this.btnChickenBurger.UseVisualStyleBackColor = false;
            this.btnChickenBurger.Click += new System.EventHandler(this.btnChickenBurger_Click);
            // 
            // btnCheeseBurger
            // 
            this.btnCheeseBurger.BackColor = System.Drawing.Color.Snow;
            this.btnCheeseBurger.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.btnCheeseBurger.Location = new System.Drawing.Point(13, 12);
            this.btnCheeseBurger.Name = "btnCheeseBurger";
            this.btnCheeseBurger.Size = new System.Drawing.Size(182, 150);
            this.btnCheeseBurger.TabIndex = 0;
            this.btnCheeseBurger.Text = "Cheese Burger";
            this.btnCheeseBurger.UseVisualStyleBackColor = false;
            this.btnCheeseBurger.Click += new System.EventHandler(this.btnCheeseBurger_Click);
            // 
            // BurgerlerForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.RosyBrown;
            this.ClientSize = new System.Drawing.Size(1255, 657);
            this.Controls.Add(this.splitBurger);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "BurgerlerForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Burgerler";
            this.Load += new System.EventHandler(this.BurgerlerForm_Load);
            this.splitBurger.Panel1.ResumeLayout(false);
            this.splitBurger.Panel2.ResumeLayout(false);
            this.splitBurger.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitBurger)).EndInit();
            this.splitBurger.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgwBurger)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.SplitContainer splitBurger;
        private System.Windows.Forms.Label lblTripleBurger;
        private System.Windows.Forms.Label lblDubleBurger;
        private System.Windows.Forms.Label lblMantarBurger;
        private System.Windows.Forms.Label lblBarbekuBurger;
        private System.Windows.Forms.Label lblVeganBurger;
        private System.Windows.Forms.Label lblChickenBurger;
        private System.Windows.Forms.Button btnTripleBurger;
        private System.Windows.Forms.Button btnDubleBurger;
        private System.Windows.Forms.Button btnMantarBurger;
        private System.Windows.Forms.Label lblCheeseBurger;
        private System.Windows.Forms.Button btnBarbekuBurger;
        private System.Windows.Forms.Button btnVeganBurger;
        private System.Windows.Forms.Button btnChickenBurger;
        private System.Windows.Forms.Button btnCheeseBurger;
        private System.Windows.Forms.Button btnMenuDon3;
        private System.Windows.Forms.DataGridView dgwBurger;
    }
}