﻿
namespace KafeOtomasyonu
{
    partial class IzgaralarForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(IzgaralarForm));
            this.splitIzgara = new System.Windows.Forms.SplitContainer();
            this.btnMenuDon8 = new System.Windows.Forms.Button();
            this.dgwIzgara = new System.Windows.Forms.DataGridView();
            this.lblIzgKarisik = new System.Windows.Forms.Label();
            this.lblIzgTavuk = new System.Windows.Forms.Label();
            this.lblIzgBiftek = new System.Windows.Forms.Label();
            this.lblIzgKofte = new System.Windows.Forms.Label();
            this.btnIzgKarisik = new System.Windows.Forms.Button();
            this.btnIzgTavuk = new System.Windows.Forms.Button();
            this.btnIzgBiftek = new System.Windows.Forms.Button();
            this.btnIzgKofte = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.splitIzgara)).BeginInit();
            this.splitIzgara.Panel1.SuspendLayout();
            this.splitIzgara.Panel2.SuspendLayout();
            this.splitIzgara.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgwIzgara)).BeginInit();
            this.SuspendLayout();
            // 
            // splitIzgara
            // 
            this.splitIzgara.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitIzgara.Location = new System.Drawing.Point(0, 0);
            this.splitIzgara.Name = "splitIzgara";
            // 
            // splitIzgara.Panel1
            // 
            this.splitIzgara.Panel1.Controls.Add(this.dgwIzgara);
            // 
            // splitIzgara.Panel2
            // 
            this.splitIzgara.Panel2.Controls.Add(this.btnMenuDon8);
            this.splitIzgara.Panel2.Controls.Add(this.lblIzgKarisik);
            this.splitIzgara.Panel2.Controls.Add(this.lblIzgTavuk);
            this.splitIzgara.Panel2.Controls.Add(this.lblIzgBiftek);
            this.splitIzgara.Panel2.Controls.Add(this.lblIzgKofte);
            this.splitIzgara.Panel2.Controls.Add(this.btnIzgKarisik);
            this.splitIzgara.Panel2.Controls.Add(this.btnIzgTavuk);
            this.splitIzgara.Panel2.Controls.Add(this.btnIzgBiftek);
            this.splitIzgara.Panel2.Controls.Add(this.btnIzgKofte);
            this.splitIzgara.Size = new System.Drawing.Size(1255, 657);
            this.splitIzgara.SplitterDistance = 326;
            this.splitIzgara.TabIndex = 5;
            // 
            // btnMenuDon8
            // 
            this.btnMenuDon8.BackColor = System.Drawing.Color.Snow;
            this.btnMenuDon8.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.btnMenuDon8.Location = new System.Drawing.Point(775, 595);
            this.btnMenuDon8.Name = "btnMenuDon8";
            this.btnMenuDon8.Size = new System.Drawing.Size(138, 50);
            this.btnMenuDon8.TabIndex = 11;
            this.btnMenuDon8.Text = "Geri";
            this.btnMenuDon8.UseVisualStyleBackColor = false;
            this.btnMenuDon8.Click += new System.EventHandler(this.btnMenuDon8_Click);
            // 
            // dgwIzgara
            // 
            this.dgwIzgara.BackgroundColor = System.Drawing.Color.Snow;
            this.dgwIzgara.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgwIzgara.Location = new System.Drawing.Point(12, 12);
            this.dgwIzgara.Name = "dgwIzgara";
            this.dgwIzgara.RowHeadersWidth = 62;
            this.dgwIzgara.RowTemplate.Height = 28;
            this.dgwIzgara.Size = new System.Drawing.Size(297, 503);
            this.dgwIzgara.TabIndex = 10;
            // 
            // lblIzgKarisik
            // 
            this.lblIzgKarisik.AutoSize = true;
            this.lblIzgKarisik.BackColor = System.Drawing.Color.Snow;
            this.lblIzgKarisik.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.lblIzgKarisik.Location = new System.Drawing.Point(646, 165);
            this.lblIzgKarisik.Name = "lblIzgKarisik";
            this.lblIzgKarisik.Size = new System.Drawing.Size(46, 23);
            this.lblIzgKarisik.TabIndex = 14;
            this.lblIzgKarisik.Text = "150";
            // 
            // lblIzgTavuk
            // 
            this.lblIzgTavuk.AutoSize = true;
            this.lblIzgTavuk.BackColor = System.Drawing.Color.Snow;
            this.lblIzgTavuk.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.lblIzgTavuk.Location = new System.Drawing.Point(464, 165);
            this.lblIzgTavuk.Name = "lblIzgTavuk";
            this.lblIzgTavuk.Size = new System.Drawing.Size(34, 23);
            this.lblIzgTavuk.TabIndex = 13;
            this.lblIzgTavuk.Text = "55";
            // 
            // lblIzgBiftek
            // 
            this.lblIzgBiftek.AutoSize = true;
            this.lblIzgBiftek.BackColor = System.Drawing.Color.Snow;
            this.lblIzgBiftek.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.lblIzgBiftek.Location = new System.Drawing.Point(276, 165);
            this.lblIzgBiftek.Name = "lblIzgBiftek";
            this.lblIzgBiftek.Size = new System.Drawing.Size(34, 23);
            this.lblIzgBiftek.TabIndex = 12;
            this.lblIzgBiftek.Text = "85";
            // 
            // lblIzgKofte
            // 
            this.lblIzgKofte.AutoSize = true;
            this.lblIzgKofte.BackColor = System.Drawing.Color.Snow;
            this.lblIzgKofte.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.lblIzgKofte.Location = new System.Drawing.Point(88, 165);
            this.lblIzgKofte.Name = "lblIzgKofte";
            this.lblIzgKofte.Size = new System.Drawing.Size(34, 23);
            this.lblIzgKofte.TabIndex = 7;
            this.lblIzgKofte.Text = "60";
            // 
            // btnIzgKarisik
            // 
            this.btnIzgKarisik.BackColor = System.Drawing.Color.Snow;
            this.btnIzgKarisik.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.btnIzgKarisik.Location = new System.Drawing.Point(578, 12);
            this.btnIzgKarisik.Name = "btnIzgKarisik";
            this.btnIzgKarisik.Size = new System.Drawing.Size(182, 150);
            this.btnIzgKarisik.TabIndex = 6;
            this.btnIzgKarisik.Text = "Karışık Izgara";
            this.btnIzgKarisik.UseVisualStyleBackColor = false;
            this.btnIzgKarisik.Click += new System.EventHandler(this.btnIzgKarisik_Click);
            // 
            // btnIzgTavuk
            // 
            this.btnIzgTavuk.BackColor = System.Drawing.Color.Snow;
            this.btnIzgTavuk.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.btnIzgTavuk.Location = new System.Drawing.Point(390, 12);
            this.btnIzgTavuk.Name = "btnIzgTavuk";
            this.btnIzgTavuk.Size = new System.Drawing.Size(182, 150);
            this.btnIzgTavuk.TabIndex = 2;
            this.btnIzgTavuk.Text = "Izgara Tavuk";
            this.btnIzgTavuk.UseVisualStyleBackColor = false;
            this.btnIzgTavuk.Click += new System.EventHandler(this.btnIzgTavuk_Click);
            // 
            // btnIzgBiftek
            // 
            this.btnIzgBiftek.BackColor = System.Drawing.Color.Snow;
            this.btnIzgBiftek.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.btnIzgBiftek.Location = new System.Drawing.Point(202, 12);
            this.btnIzgBiftek.Name = "btnIzgBiftek";
            this.btnIzgBiftek.Size = new System.Drawing.Size(182, 150);
            this.btnIzgBiftek.TabIndex = 1;
            this.btnIzgBiftek.Text = "Izgara Biftek";
            this.btnIzgBiftek.UseVisualStyleBackColor = false;
            this.btnIzgBiftek.Click += new System.EventHandler(this.btnIzgBiftek_Click);
            // 
            // btnIzgKofte
            // 
            this.btnIzgKofte.BackColor = System.Drawing.Color.Snow;
            this.btnIzgKofte.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.btnIzgKofte.Location = new System.Drawing.Point(14, 12);
            this.btnIzgKofte.Name = "btnIzgKofte";
            this.btnIzgKofte.Size = new System.Drawing.Size(182, 150);
            this.btnIzgKofte.TabIndex = 0;
            this.btnIzgKofte.Text = "Izgara Köfte";
            this.btnIzgKofte.UseVisualStyleBackColor = false;
            this.btnIzgKofte.Click += new System.EventHandler(this.btnIzgKofte_Click);
            // 
            // IzgaralarForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.RosyBrown;
            this.ClientSize = new System.Drawing.Size(1255, 657);
            this.Controls.Add(this.splitIzgara);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "IzgaralarForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Izgaralar";
            this.Load += new System.EventHandler(this.IzgaralarForm_Load);
            this.splitIzgara.Panel1.ResumeLayout(false);
            this.splitIzgara.Panel2.ResumeLayout(false);
            this.splitIzgara.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitIzgara)).EndInit();
            this.splitIzgara.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgwIzgara)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.SplitContainer splitIzgara;
        private System.Windows.Forms.Label lblIzgKarisik;
        private System.Windows.Forms.Label lblIzgTavuk;
        private System.Windows.Forms.Label lblIzgBiftek;
        private System.Windows.Forms.Label lblIzgKofte;
        private System.Windows.Forms.Button btnIzgKarisik;
        private System.Windows.Forms.Button btnIzgTavuk;
        private System.Windows.Forms.Button btnIzgBiftek;
        private System.Windows.Forms.Button btnIzgKofte;
        private System.Windows.Forms.Button btnMenuDon8;
        private System.Windows.Forms.DataGridView dgwIzgara;
    }
}