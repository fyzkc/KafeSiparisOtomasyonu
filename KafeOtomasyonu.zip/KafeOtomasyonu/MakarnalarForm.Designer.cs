﻿
namespace KafeOtomasyonu
{
    partial class MakarnalarForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MakarnalarForm));
            this.splitMakarna = new System.Windows.Forms.SplitContainer();
            this.btnMenuDon7 = new System.Windows.Forms.Button();
            this.dgwMakarna = new System.Windows.Forms.DataGridView();
            this.lblBolonez = new System.Windows.Forms.Label();
            this.btnBolonez = new System.Windows.Forms.Button();
            this.lblMac = new System.Windows.Forms.Label();
            this.lblTonMakarna = new System.Windows.Forms.Label();
            this.lblTavukluMakarna = new System.Windows.Forms.Label();
            this.lblPesto = new System.Windows.Forms.Label();
            this.lblPenneArabiata = new System.Windows.Forms.Label();
            this.btnMac = new System.Windows.Forms.Button();
            this.btnTonMakarna = new System.Windows.Forms.Button();
            this.lblSadeMakarna = new System.Windows.Forms.Label();
            this.btnTavukluMakarna = new System.Windows.Forms.Button();
            this.btnPesto = new System.Windows.Forms.Button();
            this.btnPenneArabiata = new System.Windows.Forms.Button();
            this.btnSadeMakarna = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.splitMakarna)).BeginInit();
            this.splitMakarna.Panel1.SuspendLayout();
            this.splitMakarna.Panel2.SuspendLayout();
            this.splitMakarna.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgwMakarna)).BeginInit();
            this.SuspendLayout();
            // 
            // splitMakarna
            // 
            this.splitMakarna.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitMakarna.Location = new System.Drawing.Point(0, 0);
            this.splitMakarna.Name = "splitMakarna";
            // 
            // splitMakarna.Panel1
            // 
            this.splitMakarna.Panel1.Controls.Add(this.dgwMakarna);
            // 
            // splitMakarna.Panel2
            // 
            this.splitMakarna.Panel2.Controls.Add(this.btnMenuDon7);
            this.splitMakarna.Panel2.Controls.Add(this.lblBolonez);
            this.splitMakarna.Panel2.Controls.Add(this.btnBolonez);
            this.splitMakarna.Panel2.Controls.Add(this.lblMac);
            this.splitMakarna.Panel2.Controls.Add(this.lblTonMakarna);
            this.splitMakarna.Panel2.Controls.Add(this.lblTavukluMakarna);
            this.splitMakarna.Panel2.Controls.Add(this.lblPesto);
            this.splitMakarna.Panel2.Controls.Add(this.lblPenneArabiata);
            this.splitMakarna.Panel2.Controls.Add(this.btnMac);
            this.splitMakarna.Panel2.Controls.Add(this.btnTonMakarna);
            this.splitMakarna.Panel2.Controls.Add(this.lblSadeMakarna);
            this.splitMakarna.Panel2.Controls.Add(this.btnTavukluMakarna);
            this.splitMakarna.Panel2.Controls.Add(this.btnPesto);
            this.splitMakarna.Panel2.Controls.Add(this.btnPenneArabiata);
            this.splitMakarna.Panel2.Controls.Add(this.btnSadeMakarna);
            this.splitMakarna.Size = new System.Drawing.Size(1255, 657);
            this.splitMakarna.SplitterDistance = 326;
            this.splitMakarna.TabIndex = 5;
            // 
            // btnMenuDon7
            // 
            this.btnMenuDon7.BackColor = System.Drawing.Color.Snow;
            this.btnMenuDon7.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.btnMenuDon7.Location = new System.Drawing.Point(775, 595);
            this.btnMenuDon7.Name = "btnMenuDon7";
            this.btnMenuDon7.Size = new System.Drawing.Size(138, 50);
            this.btnMenuDon7.TabIndex = 9;
            this.btnMenuDon7.Text = "Geri";
            this.btnMenuDon7.UseVisualStyleBackColor = false;
            this.btnMenuDon7.Click += new System.EventHandler(this.btnMenuDon7_Click);
            // 
            // dgwMakarna
            // 
            this.dgwMakarna.BackgroundColor = System.Drawing.Color.Snow;
            this.dgwMakarna.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgwMakarna.Location = new System.Drawing.Point(12, 12);
            this.dgwMakarna.Name = "dgwMakarna";
            this.dgwMakarna.RowHeadersWidth = 62;
            this.dgwMakarna.RowTemplate.Height = 28;
            this.dgwMakarna.Size = new System.Drawing.Size(297, 503);
            this.dgwMakarna.TabIndex = 8;
            // 
            // lblBolonez
            // 
            this.lblBolonez.AutoSize = true;
            this.lblBolonez.BackColor = System.Drawing.Color.Snow;
            this.lblBolonez.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.lblBolonez.Location = new System.Drawing.Point(462, 350);
            this.lblBolonez.Name = "lblBolonez";
            this.lblBolonez.Size = new System.Drawing.Size(34, 23);
            this.lblBolonez.TabIndex = 18;
            this.lblBolonez.Text = "50";
            // 
            // btnBolonez
            // 
            this.btnBolonez.BackColor = System.Drawing.Color.Snow;
            this.btnBolonez.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.btnBolonez.Location = new System.Drawing.Point(388, 197);
            this.btnBolonez.Name = "btnBolonez";
            this.btnBolonez.Size = new System.Drawing.Size(182, 150);
            this.btnBolonez.TabIndex = 17;
            this.btnBolonez.Text = "Bolonez Makarna";
            this.btnBolonez.UseVisualStyleBackColor = false;
            this.btnBolonez.Click += new System.EventHandler(this.btnBolonez_Click);
            // 
            // lblMac
            // 
            this.lblMac.AutoSize = true;
            this.lblMac.BackColor = System.Drawing.Color.Snow;
            this.lblMac.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.lblMac.Location = new System.Drawing.Point(274, 350);
            this.lblMac.Name = "lblMac";
            this.lblMac.Size = new System.Drawing.Size(34, 23);
            this.lblMac.TabIndex = 16;
            this.lblMac.Text = "47";
            // 
            // lblTonMakarna
            // 
            this.lblTonMakarna.AutoSize = true;
            this.lblTonMakarna.BackColor = System.Drawing.Color.Snow;
            this.lblTonMakarna.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.lblTonMakarna.Location = new System.Drawing.Point(86, 350);
            this.lblTonMakarna.Name = "lblTonMakarna";
            this.lblTonMakarna.Size = new System.Drawing.Size(34, 23);
            this.lblTonMakarna.TabIndex = 15;
            this.lblTonMakarna.Text = "70";
            // 
            // lblTavukluMakarna
            // 
            this.lblTavukluMakarna.AutoSize = true;
            this.lblTavukluMakarna.BackColor = System.Drawing.Color.Snow;
            this.lblTavukluMakarna.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.lblTavukluMakarna.Location = new System.Drawing.Point(650, 165);
            this.lblTavukluMakarna.Name = "lblTavukluMakarna";
            this.lblTavukluMakarna.Size = new System.Drawing.Size(34, 23);
            this.lblTavukluMakarna.TabIndex = 14;
            this.lblTavukluMakarna.Text = "58";
            // 
            // lblPesto
            // 
            this.lblPesto.AutoSize = true;
            this.lblPesto.BackColor = System.Drawing.Color.Snow;
            this.lblPesto.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.lblPesto.Location = new System.Drawing.Point(462, 165);
            this.lblPesto.Name = "lblPesto";
            this.lblPesto.Size = new System.Drawing.Size(34, 23);
            this.lblPesto.TabIndex = 13;
            this.lblPesto.Text = "50";
            // 
            // lblPenneArabiata
            // 
            this.lblPenneArabiata.AutoSize = true;
            this.lblPenneArabiata.BackColor = System.Drawing.Color.Snow;
            this.lblPenneArabiata.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.lblPenneArabiata.Location = new System.Drawing.Point(274, 165);
            this.lblPenneArabiata.Name = "lblPenneArabiata";
            this.lblPenneArabiata.Size = new System.Drawing.Size(34, 23);
            this.lblPenneArabiata.TabIndex = 12;
            this.lblPenneArabiata.Text = "50";
            // 
            // btnMac
            // 
            this.btnMac.BackColor = System.Drawing.Color.Snow;
            this.btnMac.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.btnMac.Location = new System.Drawing.Point(200, 197);
            this.btnMac.Name = "btnMac";
            this.btnMac.Size = new System.Drawing.Size(182, 150);
            this.btnMac.TabIndex = 9;
            this.btnMac.Text = "Mac And Cheese";
            this.btnMac.UseVisualStyleBackColor = false;
            this.btnMac.Click += new System.EventHandler(this.btnMac_Click);
            // 
            // btnTonMakarna
            // 
            this.btnTonMakarna.BackColor = System.Drawing.Color.Snow;
            this.btnTonMakarna.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.btnTonMakarna.Location = new System.Drawing.Point(12, 197);
            this.btnTonMakarna.Name = "btnTonMakarna";
            this.btnTonMakarna.Size = new System.Drawing.Size(182, 150);
            this.btnTonMakarna.TabIndex = 8;
            this.btnTonMakarna.Text = "Ton Balıklı Makarna";
            this.btnTonMakarna.UseVisualStyleBackColor = false;
            this.btnTonMakarna.Click += new System.EventHandler(this.btnTonMakarna_Click);
            // 
            // lblSadeMakarna
            // 
            this.lblSadeMakarna.AutoSize = true;
            this.lblSadeMakarna.BackColor = System.Drawing.Color.Snow;
            this.lblSadeMakarna.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.lblSadeMakarna.Location = new System.Drawing.Point(86, 165);
            this.lblSadeMakarna.Name = "lblSadeMakarna";
            this.lblSadeMakarna.Size = new System.Drawing.Size(34, 23);
            this.lblSadeMakarna.TabIndex = 7;
            this.lblSadeMakarna.Text = "30";
            // 
            // btnTavukluMakarna
            // 
            this.btnTavukluMakarna.BackColor = System.Drawing.Color.Snow;
            this.btnTavukluMakarna.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.btnTavukluMakarna.Location = new System.Drawing.Point(576, 12);
            this.btnTavukluMakarna.Name = "btnTavukluMakarna";
            this.btnTavukluMakarna.Size = new System.Drawing.Size(182, 150);
            this.btnTavukluMakarna.TabIndex = 6;
            this.btnTavukluMakarna.Text = "Kremalı Tavuklu Makarna";
            this.btnTavukluMakarna.UseVisualStyleBackColor = false;
            this.btnTavukluMakarna.Click += new System.EventHandler(this.btnTavukluMakarna_Click);
            // 
            // btnPesto
            // 
            this.btnPesto.BackColor = System.Drawing.Color.Snow;
            this.btnPesto.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.btnPesto.Location = new System.Drawing.Point(388, 12);
            this.btnPesto.Name = "btnPesto";
            this.btnPesto.Size = new System.Drawing.Size(182, 150);
            this.btnPesto.TabIndex = 2;
            this.btnPesto.Text = "Pesto Soslu Makarna";
            this.btnPesto.UseVisualStyleBackColor = false;
            this.btnPesto.Click += new System.EventHandler(this.btnPesto_Click);
            // 
            // btnPenneArabiata
            // 
            this.btnPenneArabiata.BackColor = System.Drawing.Color.Snow;
            this.btnPenneArabiata.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.btnPenneArabiata.Location = new System.Drawing.Point(200, 12);
            this.btnPenneArabiata.Name = "btnPenneArabiata";
            this.btnPenneArabiata.Size = new System.Drawing.Size(182, 150);
            this.btnPenneArabiata.TabIndex = 1;
            this.btnPenneArabiata.Text = "Penne Arabiata";
            this.btnPenneArabiata.UseVisualStyleBackColor = false;
            this.btnPenneArabiata.Click += new System.EventHandler(this.btnPenneArabiata_Click);
            // 
            // btnSadeMakarna
            // 
            this.btnSadeMakarna.BackColor = System.Drawing.Color.Snow;
            this.btnSadeMakarna.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.btnSadeMakarna.Location = new System.Drawing.Point(12, 12);
            this.btnSadeMakarna.Name = "btnSadeMakarna";
            this.btnSadeMakarna.Size = new System.Drawing.Size(182, 150);
            this.btnSadeMakarna.TabIndex = 0;
            this.btnSadeMakarna.Text = "Sade Makarna";
            this.btnSadeMakarna.UseVisualStyleBackColor = false;
            this.btnSadeMakarna.Click += new System.EventHandler(this.btnSadeMakarna_Click);
            // 
            // MakarnalarForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.RosyBrown;
            this.ClientSize = new System.Drawing.Size(1255, 657);
            this.Controls.Add(this.splitMakarna);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "MakarnalarForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Makarnalar";
            this.Load += new System.EventHandler(this.MakarnalarForm_Load);
            this.splitMakarna.Panel1.ResumeLayout(false);
            this.splitMakarna.Panel2.ResumeLayout(false);
            this.splitMakarna.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitMakarna)).EndInit();
            this.splitMakarna.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgwMakarna)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.SplitContainer splitMakarna;
        private System.Windows.Forms.Label lblBolonez;
        private System.Windows.Forms.Button btnBolonez;
        private System.Windows.Forms.Label lblMac;
        private System.Windows.Forms.Label lblTonMakarna;
        private System.Windows.Forms.Label lblTavukluMakarna;
        private System.Windows.Forms.Label lblPesto;
        private System.Windows.Forms.Label lblPenneArabiata;
        private System.Windows.Forms.Button btnMac;
        private System.Windows.Forms.Button btnTonMakarna;
        private System.Windows.Forms.Label lblSadeMakarna;
        private System.Windows.Forms.Button btnTavukluMakarna;
        private System.Windows.Forms.Button btnPesto;
        private System.Windows.Forms.Button btnPenneArabiata;
        private System.Windows.Forms.Button btnSadeMakarna;
        private System.Windows.Forms.Button btnMenuDon7;
        private System.Windows.Forms.DataGridView dgwMakarna;
    }
}