﻿
namespace KafeOtomasyonu
{
    partial class MasalarForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MasalarForm));
            this.masa1Btn = new System.Windows.Forms.Button();
            this.lblBahce = new System.Windows.Forms.Label();
            this.masa2Btn = new System.Windows.Forms.Button();
            this.masa3Btn = new System.Windows.Forms.Button();
            this.masa4Btn = new System.Windows.Forms.Button();
            this.masa5Btn = new System.Windows.Forms.Button();
            this.masa6Btn = new System.Windows.Forms.Button();
            this.masa7Btn = new System.Windows.Forms.Button();
            this.masa8Btn = new System.Windows.Forms.Button();
            this.masa9Btn = new System.Windows.Forms.Button();
            this.masa10Btn = new System.Windows.Forms.Button();
            this.lblIceri = new System.Windows.Forms.Label();
            this.masa11Btn = new System.Windows.Forms.Button();
            this.masa12Btn = new System.Windows.Forms.Button();
            this.masa13Btn = new System.Windows.Forms.Button();
            this.masa14Btn = new System.Windows.Forms.Button();
            this.masa15Btn = new System.Windows.Forms.Button();
            this.masa16Btn = new System.Windows.Forms.Button();
            this.masa17Btn = new System.Windows.Forms.Button();
            this.masa18Btn = new System.Windows.Forms.Button();
            this.masa19Btn = new System.Windows.Forms.Button();
            this.masa20Btn = new System.Windows.Forms.Button();
            this.masa21Btn = new System.Windows.Forms.Button();
            this.masa22Btn = new System.Windows.Forms.Button();
            this.masa23Btn = new System.Windows.Forms.Button();
            this.masa24Btn = new System.Windows.Forms.Button();
            this.masa25Btn = new System.Windows.Forms.Button();
            this.masa26Btn = new System.Windows.Forms.Button();
            this.masa27Btn = new System.Windows.Forms.Button();
            this.masa28Btn = new System.Windows.Forms.Button();
            this.masa29Btn = new System.Windows.Forms.Button();
            this.masa30Btn = new System.Windows.Forms.Button();
            this.masa31Btn = new System.Windows.Forms.Button();
            this.masa32Btn = new System.Windows.Forms.Button();
            this.masa33Btn = new System.Windows.Forms.Button();
            this.masa34Btn = new System.Windows.Forms.Button();
            this.masa35Btn = new System.Windows.Forms.Button();
            this.masa36Btn = new System.Windows.Forms.Button();
            this.masa37Btn = new System.Windows.Forms.Button();
            this.masa38Btn = new System.Windows.Forms.Button();
            this.btnCikis = new System.Windows.Forms.Button();
            this.btnKasa = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // masa1Btn
            // 
            this.masa1Btn.BackColor = System.Drawing.Color.Snow;
            this.masa1Btn.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Bold);
            this.masa1Btn.Location = new System.Drawing.Point(51, 114);
            this.masa1Btn.Name = "masa1Btn";
            this.masa1Btn.Size = new System.Drawing.Size(97, 86);
            this.masa1Btn.TabIndex = 0;
            this.masa1Btn.Text = "1";
            this.masa1Btn.UseVisualStyleBackColor = false;
            this.masa1Btn.Click += new System.EventHandler(this.masa1Btn_Click);
            // 
            // lblBahce
            // 
            this.lblBahce.AutoSize = true;
            this.lblBahce.BackColor = System.Drawing.Color.Snow;
            this.lblBahce.Font = new System.Drawing.Font("Cambria", 16F, System.Drawing.FontStyle.Bold);
            this.lblBahce.Location = new System.Drawing.Point(54, 34);
            this.lblBahce.Name = "lblBahce";
            this.lblBahce.Size = new System.Drawing.Size(118, 37);
            this.lblBahce.TabIndex = 1;
            this.lblBahce.Text = "BAHÇE";
            // 
            // masa2Btn
            // 
            this.masa2Btn.BackColor = System.Drawing.Color.Snow;
            this.masa2Btn.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Bold);
            this.masa2Btn.Location = new System.Drawing.Point(148, 114);
            this.masa2Btn.Name = "masa2Btn";
            this.masa2Btn.Size = new System.Drawing.Size(97, 86);
            this.masa2Btn.TabIndex = 2;
            this.masa2Btn.Text = "2";
            this.masa2Btn.UseVisualStyleBackColor = false;
            this.masa2Btn.Click += new System.EventHandler(this.masa2Btn_Click);
            // 
            // masa3Btn
            // 
            this.masa3Btn.BackColor = System.Drawing.Color.Snow;
            this.masa3Btn.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Bold);
            this.masa3Btn.Location = new System.Drawing.Point(245, 114);
            this.masa3Btn.Name = "masa3Btn";
            this.masa3Btn.Size = new System.Drawing.Size(97, 86);
            this.masa3Btn.TabIndex = 3;
            this.masa3Btn.Text = "3";
            this.masa3Btn.UseVisualStyleBackColor = false;
            this.masa3Btn.Click += new System.EventHandler(this.masa3Btn_Click);
            // 
            // masa4Btn
            // 
            this.masa4Btn.BackColor = System.Drawing.Color.Snow;
            this.masa4Btn.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Bold);
            this.masa4Btn.Location = new System.Drawing.Point(342, 114);
            this.masa4Btn.Name = "masa4Btn";
            this.masa4Btn.Size = new System.Drawing.Size(97, 86);
            this.masa4Btn.TabIndex = 4;
            this.masa4Btn.Text = "4";
            this.masa4Btn.UseVisualStyleBackColor = false;
            this.masa4Btn.Click += new System.EventHandler(this.masa4Btn_Click);
            // 
            // masa5Btn
            // 
            this.masa5Btn.BackColor = System.Drawing.Color.Snow;
            this.masa5Btn.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Bold);
            this.masa5Btn.Location = new System.Drawing.Point(439, 114);
            this.masa5Btn.Name = "masa5Btn";
            this.masa5Btn.Size = new System.Drawing.Size(97, 86);
            this.masa5Btn.TabIndex = 5;
            this.masa5Btn.Text = "5";
            this.masa5Btn.UseVisualStyleBackColor = false;
            this.masa5Btn.Click += new System.EventHandler(this.masa5Btn_Click);
            // 
            // masa6Btn
            // 
            this.masa6Btn.BackColor = System.Drawing.Color.Snow;
            this.masa6Btn.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Bold);
            this.masa6Btn.Location = new System.Drawing.Point(536, 114);
            this.masa6Btn.Name = "masa6Btn";
            this.masa6Btn.Size = new System.Drawing.Size(97, 86);
            this.masa6Btn.TabIndex = 6;
            this.masa6Btn.Text = "6";
            this.masa6Btn.UseVisualStyleBackColor = false;
            this.masa6Btn.Click += new System.EventHandler(this.masa6Btn_Click);
            // 
            // masa7Btn
            // 
            this.masa7Btn.BackColor = System.Drawing.Color.Snow;
            this.masa7Btn.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Bold);
            this.masa7Btn.Location = new System.Drawing.Point(633, 114);
            this.masa7Btn.Name = "masa7Btn";
            this.masa7Btn.Size = new System.Drawing.Size(97, 86);
            this.masa7Btn.TabIndex = 7;
            this.masa7Btn.Text = "7";
            this.masa7Btn.UseVisualStyleBackColor = false;
            this.masa7Btn.Click += new System.EventHandler(this.masa7Btn_Click);
            // 
            // masa8Btn
            // 
            this.masa8Btn.BackColor = System.Drawing.Color.Snow;
            this.masa8Btn.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Bold);
            this.masa8Btn.Location = new System.Drawing.Point(730, 114);
            this.masa8Btn.Name = "masa8Btn";
            this.masa8Btn.Size = new System.Drawing.Size(97, 86);
            this.masa8Btn.TabIndex = 8;
            this.masa8Btn.Text = "8";
            this.masa8Btn.UseVisualStyleBackColor = false;
            this.masa8Btn.Click += new System.EventHandler(this.masa8Btn_Click);
            // 
            // masa9Btn
            // 
            this.masa9Btn.BackColor = System.Drawing.Color.Snow;
            this.masa9Btn.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Bold);
            this.masa9Btn.Location = new System.Drawing.Point(827, 114);
            this.masa9Btn.Name = "masa9Btn";
            this.masa9Btn.Size = new System.Drawing.Size(97, 86);
            this.masa9Btn.TabIndex = 9;
            this.masa9Btn.Text = "9";
            this.masa9Btn.UseVisualStyleBackColor = false;
            this.masa9Btn.Click += new System.EventHandler(this.masa9Btn_Click);
            // 
            // masa10Btn
            // 
            this.masa10Btn.BackColor = System.Drawing.Color.Snow;
            this.masa10Btn.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Bold);
            this.masa10Btn.Location = new System.Drawing.Point(924, 114);
            this.masa10Btn.Name = "masa10Btn";
            this.masa10Btn.Size = new System.Drawing.Size(97, 86);
            this.masa10Btn.TabIndex = 10;
            this.masa10Btn.Text = "10";
            this.masa10Btn.UseVisualStyleBackColor = false;
            this.masa10Btn.Click += new System.EventHandler(this.masa10Btn_Click);
            // 
            // lblIceri
            // 
            this.lblIceri.AutoSize = true;
            this.lblIceri.BackColor = System.Drawing.Color.Snow;
            this.lblIceri.Font = new System.Drawing.Font("Cambria", 16F, System.Drawing.FontStyle.Bold);
            this.lblIceri.Location = new System.Drawing.Point(54, 228);
            this.lblIceri.Name = "lblIceri";
            this.lblIceri.Size = new System.Drawing.Size(96, 37);
            this.lblIceri.TabIndex = 11;
            this.lblIceri.Text = "İÇERİ";
            // 
            // masa11Btn
            // 
            this.masa11Btn.BackColor = System.Drawing.Color.Snow;
            this.masa11Btn.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.masa11Btn.Location = new System.Drawing.Point(51, 307);
            this.masa11Btn.Name = "masa11Btn";
            this.masa11Btn.Size = new System.Drawing.Size(97, 86);
            this.masa11Btn.TabIndex = 12;
            this.masa11Btn.Text = "11";
            this.masa11Btn.UseVisualStyleBackColor = false;
            this.masa11Btn.Click += new System.EventHandler(this.masa11Btn_Click);
            // 
            // masa12Btn
            // 
            this.masa12Btn.BackColor = System.Drawing.Color.Snow;
            this.masa12Btn.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.masa12Btn.Location = new System.Drawing.Point(148, 307);
            this.masa12Btn.Name = "masa12Btn";
            this.masa12Btn.Size = new System.Drawing.Size(97, 86);
            this.masa12Btn.TabIndex = 13;
            this.masa12Btn.Text = "12";
            this.masa12Btn.UseVisualStyleBackColor = false;
            this.masa12Btn.Click += new System.EventHandler(this.masa12Btn_Click);
            // 
            // masa13Btn
            // 
            this.masa13Btn.BackColor = System.Drawing.Color.Snow;
            this.masa13Btn.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.masa13Btn.Location = new System.Drawing.Point(245, 307);
            this.masa13Btn.Name = "masa13Btn";
            this.masa13Btn.Size = new System.Drawing.Size(97, 86);
            this.masa13Btn.TabIndex = 14;
            this.masa13Btn.Text = "13";
            this.masa13Btn.UseVisualStyleBackColor = false;
            this.masa13Btn.Click += new System.EventHandler(this.masa13Btn_Click);
            // 
            // masa14Btn
            // 
            this.masa14Btn.BackColor = System.Drawing.Color.Snow;
            this.masa14Btn.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.masa14Btn.Location = new System.Drawing.Point(342, 307);
            this.masa14Btn.Name = "masa14Btn";
            this.masa14Btn.Size = new System.Drawing.Size(97, 86);
            this.masa14Btn.TabIndex = 15;
            this.masa14Btn.Text = "14";
            this.masa14Btn.UseVisualStyleBackColor = false;
            this.masa14Btn.Click += new System.EventHandler(this.masa14Btn_Click);
            // 
            // masa15Btn
            // 
            this.masa15Btn.BackColor = System.Drawing.Color.Snow;
            this.masa15Btn.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.masa15Btn.Location = new System.Drawing.Point(439, 307);
            this.masa15Btn.Name = "masa15Btn";
            this.masa15Btn.Size = new System.Drawing.Size(97, 86);
            this.masa15Btn.TabIndex = 16;
            this.masa15Btn.Text = "15";
            this.masa15Btn.UseVisualStyleBackColor = false;
            this.masa15Btn.Click += new System.EventHandler(this.masa15Btn_Click);
            // 
            // masa16Btn
            // 
            this.masa16Btn.BackColor = System.Drawing.Color.Snow;
            this.masa16Btn.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.masa16Btn.Location = new System.Drawing.Point(536, 307);
            this.masa16Btn.Name = "masa16Btn";
            this.masa16Btn.Size = new System.Drawing.Size(97, 86);
            this.masa16Btn.TabIndex = 17;
            this.masa16Btn.Text = "16";
            this.masa16Btn.UseVisualStyleBackColor = false;
            this.masa16Btn.Click += new System.EventHandler(this.masa16Btn_Click);
            // 
            // masa17Btn
            // 
            this.masa17Btn.BackColor = System.Drawing.Color.Snow;
            this.masa17Btn.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.masa17Btn.Location = new System.Drawing.Point(633, 307);
            this.masa17Btn.Name = "masa17Btn";
            this.masa17Btn.Size = new System.Drawing.Size(97, 86);
            this.masa17Btn.TabIndex = 18;
            this.masa17Btn.Text = "17";
            this.masa17Btn.UseVisualStyleBackColor = false;
            this.masa17Btn.Click += new System.EventHandler(this.masa17Btn_Click);
            // 
            // masa18Btn
            // 
            this.masa18Btn.BackColor = System.Drawing.Color.Snow;
            this.masa18Btn.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.masa18Btn.Location = new System.Drawing.Point(730, 307);
            this.masa18Btn.Name = "masa18Btn";
            this.masa18Btn.Size = new System.Drawing.Size(97, 86);
            this.masa18Btn.TabIndex = 19;
            this.masa18Btn.Text = "18";
            this.masa18Btn.UseVisualStyleBackColor = false;
            this.masa18Btn.Click += new System.EventHandler(this.masa18Btn_Click);
            // 
            // masa19Btn
            // 
            this.masa19Btn.BackColor = System.Drawing.Color.Snow;
            this.masa19Btn.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.masa19Btn.Location = new System.Drawing.Point(827, 307);
            this.masa19Btn.Name = "masa19Btn";
            this.masa19Btn.Size = new System.Drawing.Size(97, 86);
            this.masa19Btn.TabIndex = 20;
            this.masa19Btn.Text = "19";
            this.masa19Btn.UseVisualStyleBackColor = false;
            this.masa19Btn.Click += new System.EventHandler(this.masa19Btn_Click);
            // 
            // masa20Btn
            // 
            this.masa20Btn.BackColor = System.Drawing.Color.Snow;
            this.masa20Btn.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.masa20Btn.Location = new System.Drawing.Point(924, 307);
            this.masa20Btn.Name = "masa20Btn";
            this.masa20Btn.Size = new System.Drawing.Size(97, 86);
            this.masa20Btn.TabIndex = 21;
            this.masa20Btn.Text = "20";
            this.masa20Btn.UseVisualStyleBackColor = false;
            this.masa20Btn.Click += new System.EventHandler(this.masa20Btn_Click);
            // 
            // masa21Btn
            // 
            this.masa21Btn.BackColor = System.Drawing.Color.Snow;
            this.masa21Btn.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.masa21Btn.Location = new System.Drawing.Point(1021, 307);
            this.masa21Btn.Name = "masa21Btn";
            this.masa21Btn.Size = new System.Drawing.Size(97, 86);
            this.masa21Btn.TabIndex = 22;
            this.masa21Btn.Text = "21";
            this.masa21Btn.UseVisualStyleBackColor = false;
            this.masa21Btn.Click += new System.EventHandler(this.masa21Btn_Click);
            // 
            // masa22Btn
            // 
            this.masa22Btn.BackColor = System.Drawing.Color.Snow;
            this.masa22Btn.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.masa22Btn.Location = new System.Drawing.Point(1118, 307);
            this.masa22Btn.Name = "masa22Btn";
            this.masa22Btn.Size = new System.Drawing.Size(97, 86);
            this.masa22Btn.TabIndex = 23;
            this.masa22Btn.Text = "22";
            this.masa22Btn.UseVisualStyleBackColor = false;
            this.masa22Btn.Click += new System.EventHandler(this.masa22Btn_Click);
            // 
            // masa23Btn
            // 
            this.masa23Btn.BackColor = System.Drawing.Color.Snow;
            this.masa23Btn.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.masa23Btn.Location = new System.Drawing.Point(51, 399);
            this.masa23Btn.Name = "masa23Btn";
            this.masa23Btn.Size = new System.Drawing.Size(97, 86);
            this.masa23Btn.TabIndex = 24;
            this.masa23Btn.Text = "23";
            this.masa23Btn.UseVisualStyleBackColor = false;
            this.masa23Btn.Click += new System.EventHandler(this.masa23Btn_Click);
            // 
            // masa24Btn
            // 
            this.masa24Btn.BackColor = System.Drawing.Color.Snow;
            this.masa24Btn.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.masa24Btn.Location = new System.Drawing.Point(148, 399);
            this.masa24Btn.Name = "masa24Btn";
            this.masa24Btn.Size = new System.Drawing.Size(97, 86);
            this.masa24Btn.TabIndex = 25;
            this.masa24Btn.Text = "24";
            this.masa24Btn.UseVisualStyleBackColor = false;
            this.masa24Btn.Click += new System.EventHandler(this.masa24Btn_Click);
            // 
            // masa25Btn
            // 
            this.masa25Btn.BackColor = System.Drawing.Color.Snow;
            this.masa25Btn.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.masa25Btn.Location = new System.Drawing.Point(245, 399);
            this.masa25Btn.Name = "masa25Btn";
            this.masa25Btn.Size = new System.Drawing.Size(97, 86);
            this.masa25Btn.TabIndex = 26;
            this.masa25Btn.Text = "25";
            this.masa25Btn.UseVisualStyleBackColor = false;
            this.masa25Btn.Click += new System.EventHandler(this.masa25Btn_Click);
            // 
            // masa26Btn
            // 
            this.masa26Btn.BackColor = System.Drawing.Color.Snow;
            this.masa26Btn.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.masa26Btn.Location = new System.Drawing.Point(342, 399);
            this.masa26Btn.Name = "masa26Btn";
            this.masa26Btn.Size = new System.Drawing.Size(97, 86);
            this.masa26Btn.TabIndex = 27;
            this.masa26Btn.Text = "26";
            this.masa26Btn.UseVisualStyleBackColor = false;
            this.masa26Btn.Click += new System.EventHandler(this.masa26Btn_Click);
            // 
            // masa27Btn
            // 
            this.masa27Btn.BackColor = System.Drawing.Color.Snow;
            this.masa27Btn.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.masa27Btn.Location = new System.Drawing.Point(439, 399);
            this.masa27Btn.Name = "masa27Btn";
            this.masa27Btn.Size = new System.Drawing.Size(97, 86);
            this.masa27Btn.TabIndex = 28;
            this.masa27Btn.Text = "27";
            this.masa27Btn.UseVisualStyleBackColor = false;
            this.masa27Btn.Click += new System.EventHandler(this.masa27Btn_Click);
            // 
            // masa28Btn
            // 
            this.masa28Btn.BackColor = System.Drawing.Color.Snow;
            this.masa28Btn.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.masa28Btn.Location = new System.Drawing.Point(536, 399);
            this.masa28Btn.Name = "masa28Btn";
            this.masa28Btn.Size = new System.Drawing.Size(97, 86);
            this.masa28Btn.TabIndex = 29;
            this.masa28Btn.Text = "28";
            this.masa28Btn.UseVisualStyleBackColor = false;
            this.masa28Btn.Click += new System.EventHandler(this.masa28Btn_Click);
            // 
            // masa29Btn
            // 
            this.masa29Btn.BackColor = System.Drawing.Color.Snow;
            this.masa29Btn.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.masa29Btn.Location = new System.Drawing.Point(633, 399);
            this.masa29Btn.Name = "masa29Btn";
            this.masa29Btn.Size = new System.Drawing.Size(97, 86);
            this.masa29Btn.TabIndex = 30;
            this.masa29Btn.Text = "29";
            this.masa29Btn.UseVisualStyleBackColor = false;
            this.masa29Btn.Click += new System.EventHandler(this.masa29Btn_Click);
            // 
            // masa30Btn
            // 
            this.masa30Btn.BackColor = System.Drawing.Color.Snow;
            this.masa30Btn.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.masa30Btn.Location = new System.Drawing.Point(730, 399);
            this.masa30Btn.Name = "masa30Btn";
            this.masa30Btn.Size = new System.Drawing.Size(97, 86);
            this.masa30Btn.TabIndex = 31;
            this.masa30Btn.Text = "30";
            this.masa30Btn.UseVisualStyleBackColor = false;
            this.masa30Btn.Click += new System.EventHandler(this.masa30Btn_Click);
            // 
            // masa31Btn
            // 
            this.masa31Btn.BackColor = System.Drawing.Color.Snow;
            this.masa31Btn.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.masa31Btn.Location = new System.Drawing.Point(827, 399);
            this.masa31Btn.Name = "masa31Btn";
            this.masa31Btn.Size = new System.Drawing.Size(97, 86);
            this.masa31Btn.TabIndex = 32;
            this.masa31Btn.Text = "31";
            this.masa31Btn.UseVisualStyleBackColor = false;
            this.masa31Btn.Click += new System.EventHandler(this.masa31Btn_Click);
            // 
            // masa32Btn
            // 
            this.masa32Btn.BackColor = System.Drawing.Color.Snow;
            this.masa32Btn.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.masa32Btn.Location = new System.Drawing.Point(924, 399);
            this.masa32Btn.Name = "masa32Btn";
            this.masa32Btn.Size = new System.Drawing.Size(97, 86);
            this.masa32Btn.TabIndex = 33;
            this.masa32Btn.Text = "32";
            this.masa32Btn.UseVisualStyleBackColor = false;
            this.masa32Btn.Click += new System.EventHandler(this.masa32Btn_Click);
            // 
            // masa33Btn
            // 
            this.masa33Btn.BackColor = System.Drawing.Color.Snow;
            this.masa33Btn.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.masa33Btn.Location = new System.Drawing.Point(1021, 399);
            this.masa33Btn.Name = "masa33Btn";
            this.masa33Btn.Size = new System.Drawing.Size(97, 86);
            this.masa33Btn.TabIndex = 34;
            this.masa33Btn.Text = "33";
            this.masa33Btn.UseVisualStyleBackColor = false;
            this.masa33Btn.Click += new System.EventHandler(this.masa33Btn_Click);
            // 
            // masa34Btn
            // 
            this.masa34Btn.BackColor = System.Drawing.Color.Snow;
            this.masa34Btn.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.masa34Btn.Location = new System.Drawing.Point(1118, 399);
            this.masa34Btn.Name = "masa34Btn";
            this.masa34Btn.Size = new System.Drawing.Size(97, 86);
            this.masa34Btn.TabIndex = 35;
            this.masa34Btn.Text = "34";
            this.masa34Btn.UseVisualStyleBackColor = false;
            this.masa34Btn.Click += new System.EventHandler(this.masa34Btn_Click);
            // 
            // masa35Btn
            // 
            this.masa35Btn.BackColor = System.Drawing.Color.Snow;
            this.masa35Btn.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.masa35Btn.Location = new System.Drawing.Point(51, 491);
            this.masa35Btn.Name = "masa35Btn";
            this.masa35Btn.Size = new System.Drawing.Size(97, 86);
            this.masa35Btn.TabIndex = 36;
            this.masa35Btn.Text = "35";
            this.masa35Btn.UseVisualStyleBackColor = false;
            this.masa35Btn.Click += new System.EventHandler(this.masa35Btn_Click);
            // 
            // masa36Btn
            // 
            this.masa36Btn.BackColor = System.Drawing.Color.Snow;
            this.masa36Btn.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.masa36Btn.Location = new System.Drawing.Point(148, 491);
            this.masa36Btn.Name = "masa36Btn";
            this.masa36Btn.Size = new System.Drawing.Size(97, 86);
            this.masa36Btn.TabIndex = 37;
            this.masa36Btn.Text = "36";
            this.masa36Btn.UseVisualStyleBackColor = false;
            this.masa36Btn.Click += new System.EventHandler(this.masa36Btn_Click);
            // 
            // masa37Btn
            // 
            this.masa37Btn.BackColor = System.Drawing.Color.Snow;
            this.masa37Btn.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.masa37Btn.Location = new System.Drawing.Point(245, 491);
            this.masa37Btn.Name = "masa37Btn";
            this.masa37Btn.Size = new System.Drawing.Size(97, 86);
            this.masa37Btn.TabIndex = 38;
            this.masa37Btn.Text = "37";
            this.masa37Btn.UseVisualStyleBackColor = false;
            this.masa37Btn.Click += new System.EventHandler(this.masa37Btn_Click);
            // 
            // masa38Btn
            // 
            this.masa38Btn.BackColor = System.Drawing.Color.Snow;
            this.masa38Btn.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.masa38Btn.Location = new System.Drawing.Point(342, 491);
            this.masa38Btn.Name = "masa38Btn";
            this.masa38Btn.Size = new System.Drawing.Size(97, 86);
            this.masa38Btn.TabIndex = 39;
            this.masa38Btn.Text = "38";
            this.masa38Btn.UseVisualStyleBackColor = false;
            this.masa38Btn.Click += new System.EventHandler(this.masa38Btn_Click);
            // 
            // btnCikis
            // 
            this.btnCikis.BackColor = System.Drawing.Color.Snow;
            this.btnCikis.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.btnCikis.Location = new System.Drawing.Point(1065, 575);
            this.btnCikis.Name = "btnCikis";
            this.btnCikis.Size = new System.Drawing.Size(178, 70);
            this.btnCikis.TabIndex = 40;
            this.btnCikis.Text = "Çıkış";
            this.btnCikis.UseVisualStyleBackColor = false;
            this.btnCikis.Click += new System.EventHandler(this.btnCikis_Click);
            // 
            // btnKasa
            // 
            this.btnKasa.BackColor = System.Drawing.Color.Snow;
            this.btnKasa.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.btnKasa.Location = new System.Drawing.Point(863, 575);
            this.btnKasa.Name = "btnKasa";
            this.btnKasa.Size = new System.Drawing.Size(178, 70);
            this.btnKasa.TabIndex = 41;
            this.btnKasa.Text = "Kasa";
            this.btnKasa.UseVisualStyleBackColor = false;
            this.btnKasa.Click += new System.EventHandler(this.btnKasa_Click);
            // 
            // MasalarForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.RosyBrown;
            this.ClientSize = new System.Drawing.Size(1255, 657);
            this.Controls.Add(this.btnKasa);
            this.Controls.Add(this.btnCikis);
            this.Controls.Add(this.masa38Btn);
            this.Controls.Add(this.masa37Btn);
            this.Controls.Add(this.masa36Btn);
            this.Controls.Add(this.masa35Btn);
            this.Controls.Add(this.masa34Btn);
            this.Controls.Add(this.masa33Btn);
            this.Controls.Add(this.masa32Btn);
            this.Controls.Add(this.masa31Btn);
            this.Controls.Add(this.masa30Btn);
            this.Controls.Add(this.masa29Btn);
            this.Controls.Add(this.masa28Btn);
            this.Controls.Add(this.masa27Btn);
            this.Controls.Add(this.masa26Btn);
            this.Controls.Add(this.masa25Btn);
            this.Controls.Add(this.masa24Btn);
            this.Controls.Add(this.masa23Btn);
            this.Controls.Add(this.masa22Btn);
            this.Controls.Add(this.masa21Btn);
            this.Controls.Add(this.masa20Btn);
            this.Controls.Add(this.masa19Btn);
            this.Controls.Add(this.masa18Btn);
            this.Controls.Add(this.masa17Btn);
            this.Controls.Add(this.masa16Btn);
            this.Controls.Add(this.masa15Btn);
            this.Controls.Add(this.masa14Btn);
            this.Controls.Add(this.masa13Btn);
            this.Controls.Add(this.masa12Btn);
            this.Controls.Add(this.masa11Btn);
            this.Controls.Add(this.lblIceri);
            this.Controls.Add(this.masa10Btn);
            this.Controls.Add(this.masa9Btn);
            this.Controls.Add(this.masa8Btn);
            this.Controls.Add(this.masa7Btn);
            this.Controls.Add(this.masa6Btn);
            this.Controls.Add(this.masa5Btn);
            this.Controls.Add(this.masa4Btn);
            this.Controls.Add(this.masa3Btn);
            this.Controls.Add(this.masa2Btn);
            this.Controls.Add(this.lblBahce);
            this.Controls.Add(this.masa1Btn);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "MasalarForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Masalar";
            this.Load += new System.EventHandler(this.MasalarForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button masa1Btn;
        private System.Windows.Forms.Label lblBahce;
        private System.Windows.Forms.Button masa2Btn;
        private System.Windows.Forms.Button masa3Btn;
        private System.Windows.Forms.Button masa4Btn;
        private System.Windows.Forms.Button masa5Btn;
        private System.Windows.Forms.Button masa6Btn;
        private System.Windows.Forms.Button masa7Btn;
        private System.Windows.Forms.Button masa8Btn;
        private System.Windows.Forms.Button masa9Btn;
        private System.Windows.Forms.Button masa10Btn;
        private System.Windows.Forms.Label lblIceri;
        private System.Windows.Forms.Button masa11Btn;
        private System.Windows.Forms.Button masa12Btn;
        private System.Windows.Forms.Button masa13Btn;
        private System.Windows.Forms.Button masa14Btn;
        private System.Windows.Forms.Button masa15Btn;
        private System.Windows.Forms.Button masa16Btn;
        private System.Windows.Forms.Button masa17Btn;
        private System.Windows.Forms.Button masa18Btn;
        private System.Windows.Forms.Button masa19Btn;
        private System.Windows.Forms.Button masa20Btn;
        private System.Windows.Forms.Button masa21Btn;
        private System.Windows.Forms.Button masa22Btn;
        private System.Windows.Forms.Button masa23Btn;
        private System.Windows.Forms.Button masa24Btn;
        private System.Windows.Forms.Button masa25Btn;
        private System.Windows.Forms.Button masa26Btn;
        private System.Windows.Forms.Button masa27Btn;
        private System.Windows.Forms.Button masa28Btn;
        private System.Windows.Forms.Button masa29Btn;
        private System.Windows.Forms.Button masa30Btn;
        private System.Windows.Forms.Button masa31Btn;
        private System.Windows.Forms.Button masa32Btn;
        private System.Windows.Forms.Button masa33Btn;
        private System.Windows.Forms.Button masa34Btn;
        private System.Windows.Forms.Button masa35Btn;
        private System.Windows.Forms.Button masa36Btn;
        private System.Windows.Forms.Button masa37Btn;
        private System.Windows.Forms.Button masa38Btn;
        private System.Windows.Forms.Button btnCikis;
        private System.Windows.Forms.Button btnKasa;
    }
}