﻿
namespace KafeOtomasyonu
{
    partial class PizzalarForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(PizzalarForm));
            this.splitPizza = new System.Windows.Forms.SplitContainer();
            this.btnMenuDon6 = new System.Windows.Forms.Button();
            this.dgwPizza = new System.Windows.Forms.DataGridView();
            this.lblMantarPizza = new System.Windows.Forms.Label();
            this.btnMantarPizza = new System.Windows.Forms.Button();
            this.lblDortPeynirPizza = new System.Windows.Forms.Label();
            this.lblTonBalikliPizza = new System.Windows.Forms.Label();
            this.lblVeganPizza = new System.Windows.Forms.Label();
            this.lblKarisikPizza = new System.Windows.Forms.Label();
            this.lblSucukluPizza = new System.Windows.Forms.Label();
            this.btnDortPeynirPizza = new System.Windows.Forms.Button();
            this.btnTonBalikliPizza = new System.Windows.Forms.Button();
            this.lblMargarita = new System.Windows.Forms.Label();
            this.btnVeganPizza = new System.Windows.Forms.Button();
            this.btnKarisikPizza = new System.Windows.Forms.Button();
            this.btnSucukluPizza = new System.Windows.Forms.Button();
            this.btnMargarita = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.splitPizza)).BeginInit();
            this.splitPizza.Panel1.SuspendLayout();
            this.splitPizza.Panel2.SuspendLayout();
            this.splitPizza.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgwPizza)).BeginInit();
            this.SuspendLayout();
            // 
            // splitPizza
            // 
            this.splitPizza.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitPizza.Location = new System.Drawing.Point(0, 0);
            this.splitPizza.Name = "splitPizza";
            // 
            // splitPizza.Panel1
            // 
            this.splitPizza.Panel1.Controls.Add(this.dgwPizza);
            // 
            // splitPizza.Panel2
            // 
            this.splitPizza.Panel2.Controls.Add(this.btnMenuDon6);
            this.splitPizza.Panel2.Controls.Add(this.lblMantarPizza);
            this.splitPizza.Panel2.Controls.Add(this.btnMantarPizza);
            this.splitPizza.Panel2.Controls.Add(this.lblDortPeynirPizza);
            this.splitPizza.Panel2.Controls.Add(this.lblTonBalikliPizza);
            this.splitPizza.Panel2.Controls.Add(this.lblVeganPizza);
            this.splitPizza.Panel2.Controls.Add(this.lblKarisikPizza);
            this.splitPizza.Panel2.Controls.Add(this.lblSucukluPizza);
            this.splitPizza.Panel2.Controls.Add(this.btnDortPeynirPizza);
            this.splitPizza.Panel2.Controls.Add(this.btnTonBalikliPizza);
            this.splitPizza.Panel2.Controls.Add(this.lblMargarita);
            this.splitPizza.Panel2.Controls.Add(this.btnVeganPizza);
            this.splitPizza.Panel2.Controls.Add(this.btnKarisikPizza);
            this.splitPizza.Panel2.Controls.Add(this.btnSucukluPizza);
            this.splitPizza.Panel2.Controls.Add(this.btnMargarita);
            this.splitPizza.Size = new System.Drawing.Size(1255, 657);
            this.splitPizza.SplitterDistance = 326;
            this.splitPizza.TabIndex = 4;
            // 
            // btnMenuDon6
            // 
            this.btnMenuDon6.BackColor = System.Drawing.Color.Snow;
            this.btnMenuDon6.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.btnMenuDon6.Location = new System.Drawing.Point(775, 595);
            this.btnMenuDon6.Name = "btnMenuDon6";
            this.btnMenuDon6.Size = new System.Drawing.Size(138, 50);
            this.btnMenuDon6.TabIndex = 7;
            this.btnMenuDon6.Text = "Geri";
            this.btnMenuDon6.UseVisualStyleBackColor = false;
            this.btnMenuDon6.Click += new System.EventHandler(this.btnMenuDon6_Click);
            // 
            // dgwPizza
            // 
            this.dgwPizza.BackgroundColor = System.Drawing.Color.Snow;
            this.dgwPizza.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgwPizza.Location = new System.Drawing.Point(12, 12);
            this.dgwPizza.Name = "dgwPizza";
            this.dgwPizza.RowHeadersWidth = 62;
            this.dgwPizza.RowTemplate.Height = 28;
            this.dgwPizza.Size = new System.Drawing.Size(297, 503);
            this.dgwPizza.TabIndex = 6;
            // 
            // lblMantarPizza
            // 
            this.lblMantarPizza.AutoSize = true;
            this.lblMantarPizza.BackColor = System.Drawing.Color.Snow;
            this.lblMantarPizza.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.lblMantarPizza.Location = new System.Drawing.Point(462, 350);
            this.lblMantarPizza.Name = "lblMantarPizza";
            this.lblMantarPizza.Size = new System.Drawing.Size(34, 23);
            this.lblMantarPizza.TabIndex = 18;
            this.lblMantarPizza.Text = "35";
            // 
            // btnMantarPizza
            // 
            this.btnMantarPizza.BackColor = System.Drawing.Color.Snow;
            this.btnMantarPizza.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.btnMantarPizza.Location = new System.Drawing.Point(388, 197);
            this.btnMantarPizza.Name = "btnMantarPizza";
            this.btnMantarPizza.Size = new System.Drawing.Size(182, 150);
            this.btnMantarPizza.TabIndex = 17;
            this.btnMantarPizza.Text = "Mantarlı Pizza";
            this.btnMantarPizza.UseVisualStyleBackColor = false;
            this.btnMantarPizza.Click += new System.EventHandler(this.btnMantarPizza_Click);
            // 
            // lblDortPeynirPizza
            // 
            this.lblDortPeynirPizza.AutoSize = true;
            this.lblDortPeynirPizza.BackColor = System.Drawing.Color.Snow;
            this.lblDortPeynirPizza.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.lblDortPeynirPizza.Location = new System.Drawing.Point(274, 350);
            this.lblDortPeynirPizza.Name = "lblDortPeynirPizza";
            this.lblDortPeynirPizza.Size = new System.Drawing.Size(34, 23);
            this.lblDortPeynirPizza.TabIndex = 16;
            this.lblDortPeynirPizza.Text = "35";
            // 
            // lblTonBalikliPizza
            // 
            this.lblTonBalikliPizza.AutoSize = true;
            this.lblTonBalikliPizza.BackColor = System.Drawing.Color.Snow;
            this.lblTonBalikliPizza.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.lblTonBalikliPizza.Location = new System.Drawing.Point(86, 350);
            this.lblTonBalikliPizza.Name = "lblTonBalikliPizza";
            this.lblTonBalikliPizza.Size = new System.Drawing.Size(34, 23);
            this.lblTonBalikliPizza.TabIndex = 15;
            this.lblTonBalikliPizza.Text = "50";
            // 
            // lblVeganPizza
            // 
            this.lblVeganPizza.AutoSize = true;
            this.lblVeganPizza.BackColor = System.Drawing.Color.Snow;
            this.lblVeganPizza.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.lblVeganPizza.Location = new System.Drawing.Point(650, 165);
            this.lblVeganPizza.Name = "lblVeganPizza";
            this.lblVeganPizza.Size = new System.Drawing.Size(34, 23);
            this.lblVeganPizza.TabIndex = 14;
            this.lblVeganPizza.Text = "55";
            // 
            // lblKarisikPizza
            // 
            this.lblKarisikPizza.AutoSize = true;
            this.lblKarisikPizza.BackColor = System.Drawing.Color.Snow;
            this.lblKarisikPizza.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.lblKarisikPizza.Location = new System.Drawing.Point(462, 165);
            this.lblKarisikPizza.Name = "lblKarisikPizza";
            this.lblKarisikPizza.Size = new System.Drawing.Size(34, 23);
            this.lblKarisikPizza.TabIndex = 13;
            this.lblKarisikPizza.Text = "35";
            // 
            // lblSucukluPizza
            // 
            this.lblSucukluPizza.AutoSize = true;
            this.lblSucukluPizza.BackColor = System.Drawing.Color.Snow;
            this.lblSucukluPizza.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.lblSucukluPizza.Location = new System.Drawing.Point(274, 165);
            this.lblSucukluPizza.Name = "lblSucukluPizza";
            this.lblSucukluPizza.Size = new System.Drawing.Size(34, 23);
            this.lblSucukluPizza.TabIndex = 12;
            this.lblSucukluPizza.Text = "40";
            // 
            // btnDortPeynirPizza
            // 
            this.btnDortPeynirPizza.BackColor = System.Drawing.Color.Snow;
            this.btnDortPeynirPizza.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.btnDortPeynirPizza.Location = new System.Drawing.Point(200, 197);
            this.btnDortPeynirPizza.Name = "btnDortPeynirPizza";
            this.btnDortPeynirPizza.Size = new System.Drawing.Size(182, 150);
            this.btnDortPeynirPizza.TabIndex = 9;
            this.btnDortPeynirPizza.Text = "Dört Peynirli Pizza";
            this.btnDortPeynirPizza.UseVisualStyleBackColor = false;
            this.btnDortPeynirPizza.Click += new System.EventHandler(this.btnDortPeynirPizza_Click);
            // 
            // btnTonBalikliPizza
            // 
            this.btnTonBalikliPizza.BackColor = System.Drawing.Color.Snow;
            this.btnTonBalikliPizza.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.btnTonBalikliPizza.Location = new System.Drawing.Point(12, 197);
            this.btnTonBalikliPizza.Name = "btnTonBalikliPizza";
            this.btnTonBalikliPizza.Size = new System.Drawing.Size(182, 150);
            this.btnTonBalikliPizza.TabIndex = 8;
            this.btnTonBalikliPizza.Text = "Ton Balıklı Pizza";
            this.btnTonBalikliPizza.UseVisualStyleBackColor = false;
            this.btnTonBalikliPizza.Click += new System.EventHandler(this.btnTonBalikliPizza_Click);
            // 
            // lblMargarita
            // 
            this.lblMargarita.AutoSize = true;
            this.lblMargarita.BackColor = System.Drawing.Color.Snow;
            this.lblMargarita.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.lblMargarita.Location = new System.Drawing.Point(86, 165);
            this.lblMargarita.Name = "lblMargarita";
            this.lblMargarita.Size = new System.Drawing.Size(34, 23);
            this.lblMargarita.TabIndex = 7;
            this.lblMargarita.Text = "50";
            // 
            // btnVeganPizza
            // 
            this.btnVeganPizza.BackColor = System.Drawing.Color.Snow;
            this.btnVeganPizza.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.btnVeganPizza.Location = new System.Drawing.Point(576, 12);
            this.btnVeganPizza.Name = "btnVeganPizza";
            this.btnVeganPizza.Size = new System.Drawing.Size(182, 150);
            this.btnVeganPizza.TabIndex = 6;
            this.btnVeganPizza.Text = "Vegan Pizza";
            this.btnVeganPizza.UseVisualStyleBackColor = false;
            this.btnVeganPizza.Click += new System.EventHandler(this.btnVeganPizza_Click);
            // 
            // btnKarisikPizza
            // 
            this.btnKarisikPizza.BackColor = System.Drawing.Color.Snow;
            this.btnKarisikPizza.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.btnKarisikPizza.Location = new System.Drawing.Point(388, 12);
            this.btnKarisikPizza.Name = "btnKarisikPizza";
            this.btnKarisikPizza.Size = new System.Drawing.Size(182, 150);
            this.btnKarisikPizza.TabIndex = 2;
            this.btnKarisikPizza.Text = "Karışık Pizza";
            this.btnKarisikPizza.UseVisualStyleBackColor = false;
            this.btnKarisikPizza.Click += new System.EventHandler(this.btnKarisikPizza_Click);
            // 
            // btnSucukluPizza
            // 
            this.btnSucukluPizza.BackColor = System.Drawing.Color.Snow;
            this.btnSucukluPizza.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.btnSucukluPizza.Location = new System.Drawing.Point(200, 12);
            this.btnSucukluPizza.Name = "btnSucukluPizza";
            this.btnSucukluPizza.Size = new System.Drawing.Size(182, 150);
            this.btnSucukluPizza.TabIndex = 1;
            this.btnSucukluPizza.Text = "Sucuklu Pizza";
            this.btnSucukluPizza.UseVisualStyleBackColor = false;
            this.btnSucukluPizza.Click += new System.EventHandler(this.btnSucukluPizza_Click);
            // 
            // btnMargarita
            // 
            this.btnMargarita.BackColor = System.Drawing.Color.Snow;
            this.btnMargarita.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.btnMargarita.Location = new System.Drawing.Point(12, 12);
            this.btnMargarita.Name = "btnMargarita";
            this.btnMargarita.Size = new System.Drawing.Size(182, 150);
            this.btnMargarita.TabIndex = 0;
            this.btnMargarita.Text = "Margarita";
            this.btnMargarita.UseVisualStyleBackColor = false;
            this.btnMargarita.Click += new System.EventHandler(this.btnMargarita_Click);
            // 
            // PizzalarForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.RosyBrown;
            this.ClientSize = new System.Drawing.Size(1255, 657);
            this.Controls.Add(this.splitPizza);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "PizzalarForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Pizzalar";
            this.Load += new System.EventHandler(this.PizzalarForm_Load);
            this.splitPizza.Panel1.ResumeLayout(false);
            this.splitPizza.Panel2.ResumeLayout(false);
            this.splitPizza.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitPizza)).EndInit();
            this.splitPizza.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgwPizza)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.SplitContainer splitPizza;
        private System.Windows.Forms.Label lblDortPeynirPizza;
        private System.Windows.Forms.Label lblTonBalikliPizza;
        private System.Windows.Forms.Label lblVeganPizza;
        private System.Windows.Forms.Label lblKarisikPizza;
        private System.Windows.Forms.Label lblSucukluPizza;
        private System.Windows.Forms.Button btnDortPeynirPizza;
        private System.Windows.Forms.Button btnTonBalikliPizza;
        private System.Windows.Forms.Label lblMargarita;
        private System.Windows.Forms.Button btnVeganPizza;
        private System.Windows.Forms.Button btnKarisikPizza;
        private System.Windows.Forms.Button btnSucukluPizza;
        private System.Windows.Forms.Button btnMargarita;
        private System.Windows.Forms.Label lblMantarPizza;
        private System.Windows.Forms.Button btnMantarPizza;
        private System.Windows.Forms.Button btnMenuDon6;
        private System.Windows.Forms.DataGridView dgwPizza;
    }
}