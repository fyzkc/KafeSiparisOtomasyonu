﻿
namespace KafeOtomasyonu
{
    partial class SalatalarForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SalatalarForm));
            this.splitSalata = new System.Windows.Forms.SplitContainer();
            this.btnMenuDon9 = new System.Windows.Forms.Button();
            this.dgwSalata = new System.Windows.Forms.DataGridView();
            this.lblZeytinSalata = new System.Windows.Forms.Label();
            this.btnZeytinSalata = new System.Windows.Forms.Button();
            this.lblSoyaSalata = new System.Windows.Forms.Label();
            this.lblTonSalata = new System.Windows.Forms.Label();
            this.lblTavukluSalata = new System.Windows.Forms.Label();
            this.lblAvokadoSalata = new System.Windows.Forms.Label();
            this.lblPeynirSalata = new System.Windows.Forms.Label();
            this.btnSoyaSalata = new System.Windows.Forms.Button();
            this.btnTonSalata = new System.Windows.Forms.Button();
            this.lblMevsimSalata = new System.Windows.Forms.Label();
            this.btnTavukSalata = new System.Windows.Forms.Button();
            this.btnAvokadoSalata = new System.Windows.Forms.Button();
            this.btnPeynirSalata = new System.Windows.Forms.Button();
            this.btnMevsimSalata = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.splitSalata)).BeginInit();
            this.splitSalata.Panel1.SuspendLayout();
            this.splitSalata.Panel2.SuspendLayout();
            this.splitSalata.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgwSalata)).BeginInit();
            this.SuspendLayout();
            // 
            // splitSalata
            // 
            this.splitSalata.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitSalata.Location = new System.Drawing.Point(0, 0);
            this.splitSalata.Name = "splitSalata";
            // 
            // splitSalata.Panel1
            // 
            this.splitSalata.Panel1.Controls.Add(this.dgwSalata);
            // 
            // splitSalata.Panel2
            // 
            this.splitSalata.Panel2.Controls.Add(this.btnMenuDon9);
            this.splitSalata.Panel2.Controls.Add(this.lblZeytinSalata);
            this.splitSalata.Panel2.Controls.Add(this.btnZeytinSalata);
            this.splitSalata.Panel2.Controls.Add(this.lblSoyaSalata);
            this.splitSalata.Panel2.Controls.Add(this.lblTonSalata);
            this.splitSalata.Panel2.Controls.Add(this.lblTavukluSalata);
            this.splitSalata.Panel2.Controls.Add(this.lblAvokadoSalata);
            this.splitSalata.Panel2.Controls.Add(this.lblPeynirSalata);
            this.splitSalata.Panel2.Controls.Add(this.btnSoyaSalata);
            this.splitSalata.Panel2.Controls.Add(this.btnTonSalata);
            this.splitSalata.Panel2.Controls.Add(this.lblMevsimSalata);
            this.splitSalata.Panel2.Controls.Add(this.btnTavukSalata);
            this.splitSalata.Panel2.Controls.Add(this.btnAvokadoSalata);
            this.splitSalata.Panel2.Controls.Add(this.btnPeynirSalata);
            this.splitSalata.Panel2.Controls.Add(this.btnMevsimSalata);
            this.splitSalata.Size = new System.Drawing.Size(1255, 657);
            this.splitSalata.SplitterDistance = 326;
            this.splitSalata.TabIndex = 5;
            // 
            // btnMenuDon9
            // 
            this.btnMenuDon9.BackColor = System.Drawing.Color.Snow;
            this.btnMenuDon9.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.btnMenuDon9.Location = new System.Drawing.Point(775, 595);
            this.btnMenuDon9.Name = "btnMenuDon9";
            this.btnMenuDon9.Size = new System.Drawing.Size(138, 50);
            this.btnMenuDon9.TabIndex = 13;
            this.btnMenuDon9.Text = "Geri";
            this.btnMenuDon9.UseVisualStyleBackColor = false;
            this.btnMenuDon9.Click += new System.EventHandler(this.btnMenuDon9_Click);
            // 
            // dgwSalata
            // 
            this.dgwSalata.BackgroundColor = System.Drawing.Color.Snow;
            this.dgwSalata.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgwSalata.Location = new System.Drawing.Point(12, 12);
            this.dgwSalata.Name = "dgwSalata";
            this.dgwSalata.RowHeadersWidth = 62;
            this.dgwSalata.RowTemplate.Height = 28;
            this.dgwSalata.Size = new System.Drawing.Size(297, 503);
            this.dgwSalata.TabIndex = 12;
            // 
            // lblZeytinSalata
            // 
            this.lblZeytinSalata.AutoSize = true;
            this.lblZeytinSalata.BackColor = System.Drawing.Color.Snow;
            this.lblZeytinSalata.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.lblZeytinSalata.Location = new System.Drawing.Point(462, 350);
            this.lblZeytinSalata.Name = "lblZeytinSalata";
            this.lblZeytinSalata.Size = new System.Drawing.Size(34, 23);
            this.lblZeytinSalata.TabIndex = 18;
            this.lblZeytinSalata.Text = "32";
            // 
            // btnZeytinSalata
            // 
            this.btnZeytinSalata.BackColor = System.Drawing.Color.Snow;
            this.btnZeytinSalata.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.btnZeytinSalata.Location = new System.Drawing.Point(388, 197);
            this.btnZeytinSalata.Name = "btnZeytinSalata";
            this.btnZeytinSalata.Size = new System.Drawing.Size(182, 150);
            this.btnZeytinSalata.TabIndex = 17;
            this.btnZeytinSalata.Text = "Zeytinli Salata";
            this.btnZeytinSalata.UseVisualStyleBackColor = false;
            this.btnZeytinSalata.Click += new System.EventHandler(this.btnZeytinSalata_Click);
            // 
            // lblSoyaSalata
            // 
            this.lblSoyaSalata.AutoSize = true;
            this.lblSoyaSalata.BackColor = System.Drawing.Color.Snow;
            this.lblSoyaSalata.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.lblSoyaSalata.Location = new System.Drawing.Point(274, 350);
            this.lblSoyaSalata.Name = "lblSoyaSalata";
            this.lblSoyaSalata.Size = new System.Drawing.Size(34, 23);
            this.lblSoyaSalata.TabIndex = 16;
            this.lblSoyaSalata.Text = "72";
            // 
            // lblTonSalata
            // 
            this.lblTonSalata.AutoSize = true;
            this.lblTonSalata.BackColor = System.Drawing.Color.Snow;
            this.lblTonSalata.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.lblTonSalata.Location = new System.Drawing.Point(86, 350);
            this.lblTonSalata.Name = "lblTonSalata";
            this.lblTonSalata.Size = new System.Drawing.Size(34, 23);
            this.lblTonSalata.TabIndex = 15;
            this.lblTonSalata.Text = "68";
            // 
            // lblTavukluSalata
            // 
            this.lblTavukluSalata.AutoSize = true;
            this.lblTavukluSalata.BackColor = System.Drawing.Color.Snow;
            this.lblTavukluSalata.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.lblTavukluSalata.Location = new System.Drawing.Point(650, 165);
            this.lblTavukluSalata.Name = "lblTavukluSalata";
            this.lblTavukluSalata.Size = new System.Drawing.Size(34, 23);
            this.lblTavukluSalata.TabIndex = 14;
            this.lblTavukluSalata.Text = "60";
            // 
            // lblAvokadoSalata
            // 
            this.lblAvokadoSalata.AutoSize = true;
            this.lblAvokadoSalata.BackColor = System.Drawing.Color.Snow;
            this.lblAvokadoSalata.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.lblAvokadoSalata.Location = new System.Drawing.Point(462, 165);
            this.lblAvokadoSalata.Name = "lblAvokadoSalata";
            this.lblAvokadoSalata.Size = new System.Drawing.Size(34, 23);
            this.lblAvokadoSalata.TabIndex = 13;
            this.lblAvokadoSalata.Text = "50";
            // 
            // lblPeynirSalata
            // 
            this.lblPeynirSalata.AutoSize = true;
            this.lblPeynirSalata.BackColor = System.Drawing.Color.Snow;
            this.lblPeynirSalata.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.lblPeynirSalata.Location = new System.Drawing.Point(274, 165);
            this.lblPeynirSalata.Name = "lblPeynirSalata";
            this.lblPeynirSalata.Size = new System.Drawing.Size(34, 23);
            this.lblPeynirSalata.TabIndex = 12;
            this.lblPeynirSalata.Text = "40";
            // 
            // btnSoyaSalata
            // 
            this.btnSoyaSalata.BackColor = System.Drawing.Color.Snow;
            this.btnSoyaSalata.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.btnSoyaSalata.Location = new System.Drawing.Point(200, 197);
            this.btnSoyaSalata.Name = "btnSoyaSalata";
            this.btnSoyaSalata.Size = new System.Drawing.Size(182, 150);
            this.btnSoyaSalata.TabIndex = 9;
            this.btnSoyaSalata.Text = "Soya Soslu Salata";
            this.btnSoyaSalata.UseVisualStyleBackColor = false;
            this.btnSoyaSalata.Click += new System.EventHandler(this.btnSoyaSalata_Click);
            // 
            // btnTonSalata
            // 
            this.btnTonSalata.BackColor = System.Drawing.Color.Snow;
            this.btnTonSalata.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.btnTonSalata.Location = new System.Drawing.Point(12, 197);
            this.btnTonSalata.Name = "btnTonSalata";
            this.btnTonSalata.Size = new System.Drawing.Size(182, 150);
            this.btnTonSalata.TabIndex = 8;
            this.btnTonSalata.Text = "Ton Balıklı Salata";
            this.btnTonSalata.UseVisualStyleBackColor = false;
            this.btnTonSalata.Click += new System.EventHandler(this.btnTonSalata_Click);
            // 
            // lblMevsimSalata
            // 
            this.lblMevsimSalata.AutoSize = true;
            this.lblMevsimSalata.BackColor = System.Drawing.Color.Snow;
            this.lblMevsimSalata.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.lblMevsimSalata.Location = new System.Drawing.Point(86, 165);
            this.lblMevsimSalata.Name = "lblMevsimSalata";
            this.lblMevsimSalata.Size = new System.Drawing.Size(34, 23);
            this.lblMevsimSalata.TabIndex = 7;
            this.lblMevsimSalata.Text = "30";
            // 
            // btnTavukSalata
            // 
            this.btnTavukSalata.BackColor = System.Drawing.Color.Snow;
            this.btnTavukSalata.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.btnTavukSalata.Location = new System.Drawing.Point(576, 12);
            this.btnTavukSalata.Name = "btnTavukSalata";
            this.btnTavukSalata.Size = new System.Drawing.Size(182, 150);
            this.btnTavukSalata.TabIndex = 6;
            this.btnTavukSalata.Text = "Tavuklu Salata";
            this.btnTavukSalata.UseVisualStyleBackColor = false;
            this.btnTavukSalata.Click += new System.EventHandler(this.btnTavukSalata_Click);
            // 
            // btnAvokadoSalata
            // 
            this.btnAvokadoSalata.BackColor = System.Drawing.Color.Snow;
            this.btnAvokadoSalata.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.btnAvokadoSalata.Location = new System.Drawing.Point(388, 12);
            this.btnAvokadoSalata.Name = "btnAvokadoSalata";
            this.btnAvokadoSalata.Size = new System.Drawing.Size(182, 150);
            this.btnAvokadoSalata.TabIndex = 2;
            this.btnAvokadoSalata.Text = "Avokadolu Salata";
            this.btnAvokadoSalata.UseVisualStyleBackColor = false;
            this.btnAvokadoSalata.Click += new System.EventHandler(this.btnAvokadoSalata_Click);
            // 
            // btnPeynirSalata
            // 
            this.btnPeynirSalata.BackColor = System.Drawing.Color.Snow;
            this.btnPeynirSalata.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.btnPeynirSalata.Location = new System.Drawing.Point(200, 12);
            this.btnPeynirSalata.Name = "btnPeynirSalata";
            this.btnPeynirSalata.Size = new System.Drawing.Size(182, 150);
            this.btnPeynirSalata.TabIndex = 1;
            this.btnPeynirSalata.Text = "Beyaz Peynrili Salata";
            this.btnPeynirSalata.UseVisualStyleBackColor = false;
            this.btnPeynirSalata.Click += new System.EventHandler(this.btnPeynirSalata_Click);
            // 
            // btnMevsimSalata
            // 
            this.btnMevsimSalata.BackColor = System.Drawing.Color.Snow;
            this.btnMevsimSalata.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.btnMevsimSalata.Location = new System.Drawing.Point(12, 12);
            this.btnMevsimSalata.Name = "btnMevsimSalata";
            this.btnMevsimSalata.Size = new System.Drawing.Size(182, 150);
            this.btnMevsimSalata.TabIndex = 0;
            this.btnMevsimSalata.Text = "Mevsim Salata";
            this.btnMevsimSalata.UseVisualStyleBackColor = false;
            this.btnMevsimSalata.Click += new System.EventHandler(this.btnMevsimSalata_Click);
            // 
            // SalatalarForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.RosyBrown;
            this.ClientSize = new System.Drawing.Size(1255, 657);
            this.Controls.Add(this.splitSalata);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "SalatalarForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Salatalar";
            this.Load += new System.EventHandler(this.SalatalarForm_Load);
            this.splitSalata.Panel1.ResumeLayout(false);
            this.splitSalata.Panel2.ResumeLayout(false);
            this.splitSalata.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitSalata)).EndInit();
            this.splitSalata.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgwSalata)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.SplitContainer splitSalata;
        private System.Windows.Forms.Label lblZeytinSalata;
        private System.Windows.Forms.Button btnZeytinSalata;
        private System.Windows.Forms.Label lblSoyaSalata;
        private System.Windows.Forms.Label lblTonSalata;
        private System.Windows.Forms.Label lblTavukluSalata;
        private System.Windows.Forms.Label lblAvokadoSalata;
        private System.Windows.Forms.Label lblPeynirSalata;
        private System.Windows.Forms.Button btnSoyaSalata;
        private System.Windows.Forms.Button btnTonSalata;
        private System.Windows.Forms.Label lblMevsimSalata;
        private System.Windows.Forms.Button btnTavukSalata;
        private System.Windows.Forms.Button btnAvokadoSalata;
        private System.Windows.Forms.Button btnPeynirSalata;
        private System.Windows.Forms.Button btnMevsimSalata;
        private System.Windows.Forms.Button btnMenuDon9;
        private System.Windows.Forms.DataGridView dgwSalata;
    }
}