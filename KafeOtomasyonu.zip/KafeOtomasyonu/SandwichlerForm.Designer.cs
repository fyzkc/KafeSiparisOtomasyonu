﻿
namespace KafeOtomasyonu
{
    partial class SandwichlerForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SandwichlerForm));
            this.splitSandwich = new System.Windows.Forms.SplitContainer();
            this.btnMenuDon5 = new System.Windows.Forms.Button();
            this.dgwSandwich = new System.Windows.Forms.DataGridView();
            this.lblKumruSand = new System.Windows.Forms.Label();
            this.lblSucukSand = new System.Windows.Forms.Label();
            this.lblKofteSand = new System.Windows.Forms.Label();
            this.lblSogukSand = new System.Windows.Forms.Label();
            this.btnKumruSand = new System.Windows.Forms.Button();
            this.btnSucukSand = new System.Windows.Forms.Button();
            this.btnKofteSand = new System.Windows.Forms.Button();
            this.btnSogukSand = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.splitSandwich)).BeginInit();
            this.splitSandwich.Panel1.SuspendLayout();
            this.splitSandwich.Panel2.SuspendLayout();
            this.splitSandwich.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgwSandwich)).BeginInit();
            this.SuspendLayout();
            // 
            // splitSandwich
            // 
            this.splitSandwich.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitSandwich.Location = new System.Drawing.Point(0, 0);
            this.splitSandwich.Name = "splitSandwich";
            // 
            // splitSandwich.Panel1
            // 
            this.splitSandwich.Panel1.Controls.Add(this.dgwSandwich);
            // 
            // splitSandwich.Panel2
            // 
            this.splitSandwich.Panel2.Controls.Add(this.btnMenuDon5);
            this.splitSandwich.Panel2.Controls.Add(this.lblKumruSand);
            this.splitSandwich.Panel2.Controls.Add(this.lblSucukSand);
            this.splitSandwich.Panel2.Controls.Add(this.lblKofteSand);
            this.splitSandwich.Panel2.Controls.Add(this.lblSogukSand);
            this.splitSandwich.Panel2.Controls.Add(this.btnKumruSand);
            this.splitSandwich.Panel2.Controls.Add(this.btnSucukSand);
            this.splitSandwich.Panel2.Controls.Add(this.btnKofteSand);
            this.splitSandwich.Panel2.Controls.Add(this.btnSogukSand);
            this.splitSandwich.Size = new System.Drawing.Size(1255, 657);
            this.splitSandwich.SplitterDistance = 326;
            this.splitSandwich.TabIndex = 4;
            // 
            // btnMenuDon5
            // 
            this.btnMenuDon5.BackColor = System.Drawing.Color.Snow;
            this.btnMenuDon5.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.btnMenuDon5.Location = new System.Drawing.Point(775, 595);
            this.btnMenuDon5.Name = "btnMenuDon5";
            this.btnMenuDon5.Size = new System.Drawing.Size(138, 50);
            this.btnMenuDon5.TabIndex = 5;
            this.btnMenuDon5.Text = "Geri";
            this.btnMenuDon5.UseVisualStyleBackColor = false;
            this.btnMenuDon5.Click += new System.EventHandler(this.btnMenuDon5_Click);
            // 
            // dgwSandwich
            // 
            this.dgwSandwich.BackgroundColor = System.Drawing.Color.Snow;
            this.dgwSandwich.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgwSandwich.Location = new System.Drawing.Point(12, 12);
            this.dgwSandwich.Name = "dgwSandwich";
            this.dgwSandwich.RowHeadersWidth = 62;
            this.dgwSandwich.RowTemplate.Height = 28;
            this.dgwSandwich.Size = new System.Drawing.Size(297, 503);
            this.dgwSandwich.TabIndex = 4;
            // 
            // lblKumruSand
            // 
            this.lblKumruSand.AutoSize = true;
            this.lblKumruSand.BackColor = System.Drawing.Color.Snow;
            this.lblKumruSand.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.lblKumruSand.Location = new System.Drawing.Point(650, 165);
            this.lblKumruSand.Name = "lblKumruSand";
            this.lblKumruSand.Size = new System.Drawing.Size(34, 23);
            this.lblKumruSand.TabIndex = 14;
            this.lblKumruSand.Text = "55";
            // 
            // lblSucukSand
            // 
            this.lblSucukSand.AutoSize = true;
            this.lblSucukSand.BackColor = System.Drawing.Color.Snow;
            this.lblSucukSand.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.lblSucukSand.Location = new System.Drawing.Point(462, 165);
            this.lblSucukSand.Name = "lblSucukSand";
            this.lblSucukSand.Size = new System.Drawing.Size(34, 23);
            this.lblSucukSand.TabIndex = 13;
            this.lblSucukSand.Text = "40";
            // 
            // lblKofteSand
            // 
            this.lblKofteSand.AutoSize = true;
            this.lblKofteSand.BackColor = System.Drawing.Color.Snow;
            this.lblKofteSand.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.lblKofteSand.Location = new System.Drawing.Point(274, 165);
            this.lblKofteSand.Name = "lblKofteSand";
            this.lblKofteSand.Size = new System.Drawing.Size(34, 23);
            this.lblKofteSand.TabIndex = 12;
            this.lblKofteSand.Text = "40";
            // 
            // lblSogukSand
            // 
            this.lblSogukSand.AutoSize = true;
            this.lblSogukSand.BackColor = System.Drawing.Color.Snow;
            this.lblSogukSand.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.lblSogukSand.Location = new System.Drawing.Point(86, 165);
            this.lblSogukSand.Name = "lblSogukSand";
            this.lblSogukSand.Size = new System.Drawing.Size(34, 23);
            this.lblSogukSand.TabIndex = 7;
            this.lblSogukSand.Text = "25";
            // 
            // btnKumruSand
            // 
            this.btnKumruSand.BackColor = System.Drawing.Color.Snow;
            this.btnKumruSand.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.btnKumruSand.Location = new System.Drawing.Point(576, 12);
            this.btnKumruSand.Name = "btnKumruSand";
            this.btnKumruSand.Size = new System.Drawing.Size(182, 150);
            this.btnKumruSand.TabIndex = 6;
            this.btnKumruSand.Text = "Kumru Sandwich";
            this.btnKumruSand.UseVisualStyleBackColor = false;
            this.btnKumruSand.Click += new System.EventHandler(this.btnKumruSand_Click);
            // 
            // btnSucukSand
            // 
            this.btnSucukSand.BackColor = System.Drawing.Color.Snow;
            this.btnSucukSand.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.btnSucukSand.Location = new System.Drawing.Point(388, 12);
            this.btnSucukSand.Name = "btnSucukSand";
            this.btnSucukSand.Size = new System.Drawing.Size(182, 150);
            this.btnSucukSand.TabIndex = 2;
            this.btnSucukSand.Text = "Sucuklu Sandwich";
            this.btnSucukSand.UseVisualStyleBackColor = false;
            this.btnSucukSand.Click += new System.EventHandler(this.btnSucukSand_Click);
            // 
            // btnKofteSand
            // 
            this.btnKofteSand.BackColor = System.Drawing.Color.Snow;
            this.btnKofteSand.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.btnKofteSand.Location = new System.Drawing.Point(200, 12);
            this.btnKofteSand.Name = "btnKofteSand";
            this.btnKofteSand.Size = new System.Drawing.Size(182, 150);
            this.btnKofteSand.TabIndex = 1;
            this.btnKofteSand.Text = "Köfte Sandwich";
            this.btnKofteSand.UseVisualStyleBackColor = false;
            this.btnKofteSand.Click += new System.EventHandler(this.btnKofteSand_Click);
            // 
            // btnSogukSand
            // 
            this.btnSogukSand.BackColor = System.Drawing.Color.Snow;
            this.btnSogukSand.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.btnSogukSand.Location = new System.Drawing.Point(12, 12);
            this.btnSogukSand.Name = "btnSogukSand";
            this.btnSogukSand.Size = new System.Drawing.Size(182, 150);
            this.btnSogukSand.TabIndex = 0;
            this.btnSogukSand.Text = "Soğuk Sandwich";
            this.btnSogukSand.UseVisualStyleBackColor = false;
            this.btnSogukSand.Click += new System.EventHandler(this.btnSogukSand_Click);
            // 
            // SandwichlerForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.RosyBrown;
            this.ClientSize = new System.Drawing.Size(1255, 657);
            this.Controls.Add(this.splitSandwich);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "SandwichlerForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Sandwichler";
            this.Load += new System.EventHandler(this.SandwichlerForm_Load);
            this.splitSandwich.Panel1.ResumeLayout(false);
            this.splitSandwich.Panel2.ResumeLayout(false);
            this.splitSandwich.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitSandwich)).EndInit();
            this.splitSandwich.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgwSandwich)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.SplitContainer splitSandwich;
        private System.Windows.Forms.Label lblKumruSand;
        private System.Windows.Forms.Label lblSucukSand;
        private System.Windows.Forms.Label lblKofteSand;
        private System.Windows.Forms.Label lblSogukSand;
        private System.Windows.Forms.Button btnKumruSand;
        private System.Windows.Forms.Button btnSucukSand;
        private System.Windows.Forms.Button btnKofteSand;
        private System.Windows.Forms.Button btnSogukSand;
        private System.Windows.Forms.Button btnMenuDon5;
        private System.Windows.Forms.DataGridView dgwSandwich;
    }
}