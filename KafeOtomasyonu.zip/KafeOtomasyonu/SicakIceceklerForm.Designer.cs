﻿
namespace KafeOtomasyonu
{
    partial class SicakIceceklerForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SicakIceceklerForm));
            this.splitSicakI = new System.Windows.Forms.SplitContainer();
            this.btnMenuDon11 = new System.Windows.Forms.Button();
            this.dgwSicakI = new System.Windows.Forms.DataGridView();
            this.lblSicakCiko = new System.Windows.Forms.Label();
            this.btnSicakCiko = new System.Windows.Forms.Button();
            this.lblBalliSut = new System.Windows.Forms.Label();
            this.btnBalliSut = new System.Windows.Forms.Button();
            this.lblSahlep = new System.Windows.Forms.Label();
            this.btnSahlep = new System.Windows.Forms.Button();
            this.lblMenengic = new System.Windows.Forms.Label();
            this.btnMenengic = new System.Windows.Forms.Button();
            this.lblDibek = new System.Windows.Forms.Label();
            this.btnDibek = new System.Windows.Forms.Button();
            this.lblDamlaTurk = new System.Windows.Forms.Label();
            this.btnDamlaTurk = new System.Windows.Forms.Button();
            this.lblTurk = new System.Windows.Forms.Label();
            this.lblEspresso = new System.Windows.Forms.Label();
            this.lblCapp = new System.Windows.Forms.Label();
            this.lblLatte = new System.Windows.Forms.Label();
            this.lblMocha = new System.Windows.Forms.Label();
            this.btnTurk = new System.Windows.Forms.Button();
            this.btnEspresso = new System.Windows.Forms.Button();
            this.lblCay = new System.Windows.Forms.Label();
            this.btnCapp = new System.Windows.Forms.Button();
            this.btnLatte = new System.Windows.Forms.Button();
            this.btnMocha = new System.Windows.Forms.Button();
            this.btnCay = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.splitSicakI)).BeginInit();
            this.splitSicakI.Panel1.SuspendLayout();
            this.splitSicakI.Panel2.SuspendLayout();
            this.splitSicakI.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgwSicakI)).BeginInit();
            this.SuspendLayout();
            // 
            // splitSicakI
            // 
            this.splitSicakI.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitSicakI.Location = new System.Drawing.Point(0, 0);
            this.splitSicakI.Name = "splitSicakI";
            // 
            // splitSicakI.Panel1
            // 
            this.splitSicakI.Panel1.Controls.Add(this.dgwSicakI);
            // 
            // splitSicakI.Panel2
            // 
            this.splitSicakI.Panel2.Controls.Add(this.btnMenuDon11);
            this.splitSicakI.Panel2.Controls.Add(this.lblSicakCiko);
            this.splitSicakI.Panel2.Controls.Add(this.btnSicakCiko);
            this.splitSicakI.Panel2.Controls.Add(this.lblBalliSut);
            this.splitSicakI.Panel2.Controls.Add(this.btnBalliSut);
            this.splitSicakI.Panel2.Controls.Add(this.lblSahlep);
            this.splitSicakI.Panel2.Controls.Add(this.btnSahlep);
            this.splitSicakI.Panel2.Controls.Add(this.lblMenengic);
            this.splitSicakI.Panel2.Controls.Add(this.btnMenengic);
            this.splitSicakI.Panel2.Controls.Add(this.lblDibek);
            this.splitSicakI.Panel2.Controls.Add(this.btnDibek);
            this.splitSicakI.Panel2.Controls.Add(this.lblDamlaTurk);
            this.splitSicakI.Panel2.Controls.Add(this.btnDamlaTurk);
            this.splitSicakI.Panel2.Controls.Add(this.lblTurk);
            this.splitSicakI.Panel2.Controls.Add(this.lblEspresso);
            this.splitSicakI.Panel2.Controls.Add(this.lblCapp);
            this.splitSicakI.Panel2.Controls.Add(this.lblLatte);
            this.splitSicakI.Panel2.Controls.Add(this.lblMocha);
            this.splitSicakI.Panel2.Controls.Add(this.btnTurk);
            this.splitSicakI.Panel2.Controls.Add(this.btnEspresso);
            this.splitSicakI.Panel2.Controls.Add(this.lblCay);
            this.splitSicakI.Panel2.Controls.Add(this.btnCapp);
            this.splitSicakI.Panel2.Controls.Add(this.btnLatte);
            this.splitSicakI.Panel2.Controls.Add(this.btnMocha);
            this.splitSicakI.Panel2.Controls.Add(this.btnCay);
            this.splitSicakI.Size = new System.Drawing.Size(1255, 657);
            this.splitSicakI.SplitterDistance = 326;
            this.splitSicakI.TabIndex = 6;
            // 
            // btnMenuDon11
            // 
            this.btnMenuDon11.BackColor = System.Drawing.Color.Snow;
            this.btnMenuDon11.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.btnMenuDon11.Location = new System.Drawing.Point(775, 595);
            this.btnMenuDon11.Name = "btnMenuDon11";
            this.btnMenuDon11.Size = new System.Drawing.Size(138, 50);
            this.btnMenuDon11.TabIndex = 17;
            this.btnMenuDon11.Text = "Geri";
            this.btnMenuDon11.UseVisualStyleBackColor = false;
            this.btnMenuDon11.Click += new System.EventHandler(this.btnMenuDon11_Click);
            // 
            // dgwSicakI
            // 
            this.dgwSicakI.BackgroundColor = System.Drawing.Color.Snow;
            this.dgwSicakI.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgwSicakI.Location = new System.Drawing.Point(12, 12);
            this.dgwSicakI.Name = "dgwSicakI";
            this.dgwSicakI.RowHeadersWidth = 62;
            this.dgwSicakI.RowTemplate.Height = 28;
            this.dgwSicakI.Size = new System.Drawing.Size(297, 503);
            this.dgwSicakI.TabIndex = 16;
            // 
            // lblSicakCiko
            // 
            this.lblSicakCiko.AutoSize = true;
            this.lblSicakCiko.BackColor = System.Drawing.Color.Snow;
            this.lblSicakCiko.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.lblSicakCiko.Location = new System.Drawing.Point(650, 553);
            this.lblSicakCiko.Name = "lblSicakCiko";
            this.lblSicakCiko.Size = new System.Drawing.Size(34, 23);
            this.lblSicakCiko.TabIndex = 28;
            this.lblSicakCiko.Text = "20";
            // 
            // btnSicakCiko
            // 
            this.btnSicakCiko.BackColor = System.Drawing.Color.Snow;
            this.btnSicakCiko.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.btnSicakCiko.Location = new System.Drawing.Point(576, 400);
            this.btnSicakCiko.Name = "btnSicakCiko";
            this.btnSicakCiko.Size = new System.Drawing.Size(182, 150);
            this.btnSicakCiko.TabIndex = 27;
            this.btnSicakCiko.Text = "Sıcak Çikolata";
            this.btnSicakCiko.UseVisualStyleBackColor = false;
            this.btnSicakCiko.Click += new System.EventHandler(this.btnSicakCiko_Click);
            // 
            // lblBalliSut
            // 
            this.lblBalliSut.AutoSize = true;
            this.lblBalliSut.BackColor = System.Drawing.Color.Snow;
            this.lblBalliSut.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.lblBalliSut.Location = new System.Drawing.Point(462, 553);
            this.lblBalliSut.Name = "lblBalliSut";
            this.lblBalliSut.Size = new System.Drawing.Size(34, 23);
            this.lblBalliSut.TabIndex = 26;
            this.lblBalliSut.Text = "15";
            // 
            // btnBalliSut
            // 
            this.btnBalliSut.BackColor = System.Drawing.Color.Snow;
            this.btnBalliSut.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.btnBalliSut.Location = new System.Drawing.Point(388, 400);
            this.btnBalliSut.Name = "btnBalliSut";
            this.btnBalliSut.Size = new System.Drawing.Size(182, 150);
            this.btnBalliSut.TabIndex = 25;
            this.btnBalliSut.Text = "Ballı Süt";
            this.btnBalliSut.UseVisualStyleBackColor = false;
            this.btnBalliSut.Click += new System.EventHandler(this.btnBalliSut_Click);
            // 
            // lblSahlep
            // 
            this.lblSahlep.AutoSize = true;
            this.lblSahlep.BackColor = System.Drawing.Color.Snow;
            this.lblSahlep.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.lblSahlep.Location = new System.Drawing.Point(274, 553);
            this.lblSahlep.Name = "lblSahlep";
            this.lblSahlep.Size = new System.Drawing.Size(34, 23);
            this.lblSahlep.TabIndex = 24;
            this.lblSahlep.Text = "15";
            // 
            // btnSahlep
            // 
            this.btnSahlep.BackColor = System.Drawing.Color.Snow;
            this.btnSahlep.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.btnSahlep.Location = new System.Drawing.Point(200, 400);
            this.btnSahlep.Name = "btnSahlep";
            this.btnSahlep.Size = new System.Drawing.Size(182, 150);
            this.btnSahlep.TabIndex = 23;
            this.btnSahlep.Text = "Sahlep";
            this.btnSahlep.UseVisualStyleBackColor = false;
            this.btnSahlep.Click += new System.EventHandler(this.btnSahlep_Click);
            // 
            // lblMenengic
            // 
            this.lblMenengic.AutoSize = true;
            this.lblMenengic.BackColor = System.Drawing.Color.Snow;
            this.lblMenengic.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.lblMenengic.Location = new System.Drawing.Point(86, 553);
            this.lblMenengic.Name = "lblMenengic";
            this.lblMenengic.Size = new System.Drawing.Size(34, 23);
            this.lblMenengic.TabIndex = 22;
            this.lblMenengic.Text = "30";
            // 
            // btnMenengic
            // 
            this.btnMenengic.BackColor = System.Drawing.Color.Snow;
            this.btnMenengic.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.btnMenengic.Location = new System.Drawing.Point(12, 400);
            this.btnMenengic.Name = "btnMenengic";
            this.btnMenengic.Size = new System.Drawing.Size(182, 150);
            this.btnMenengic.TabIndex = 21;
            this.btnMenengic.Text = "Menengiç Kahvesi";
            this.btnMenengic.UseVisualStyleBackColor = false;
            this.btnMenengic.Click += new System.EventHandler(this.btnMenengic_Click);
            // 
            // lblDibek
            // 
            this.lblDibek.AutoSize = true;
            this.lblDibek.BackColor = System.Drawing.Color.Snow;
            this.lblDibek.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.lblDibek.Location = new System.Drawing.Point(650, 350);
            this.lblDibek.Name = "lblDibek";
            this.lblDibek.Size = new System.Drawing.Size(34, 23);
            this.lblDibek.TabIndex = 20;
            this.lblDibek.Text = "30";
            // 
            // btnDibek
            // 
            this.btnDibek.BackColor = System.Drawing.Color.Snow;
            this.btnDibek.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.btnDibek.Location = new System.Drawing.Point(576, 197);
            this.btnDibek.Name = "btnDibek";
            this.btnDibek.Size = new System.Drawing.Size(182, 150);
            this.btnDibek.TabIndex = 19;
            this.btnDibek.Text = "Dibek Kahvesi";
            this.btnDibek.UseVisualStyleBackColor = false;
            this.btnDibek.Click += new System.EventHandler(this.btnDibek_Click);
            // 
            // lblDamlaTurk
            // 
            this.lblDamlaTurk.AutoSize = true;
            this.lblDamlaTurk.BackColor = System.Drawing.Color.Snow;
            this.lblDamlaTurk.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.lblDamlaTurk.Location = new System.Drawing.Point(462, 350);
            this.lblDamlaTurk.Name = "lblDamlaTurk";
            this.lblDamlaTurk.Size = new System.Drawing.Size(34, 23);
            this.lblDamlaTurk.TabIndex = 18;
            this.lblDamlaTurk.Text = "27";
            // 
            // btnDamlaTurk
            // 
            this.btnDamlaTurk.BackColor = System.Drawing.Color.Snow;
            this.btnDamlaTurk.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.btnDamlaTurk.Location = new System.Drawing.Point(388, 197);
            this.btnDamlaTurk.Name = "btnDamlaTurk";
            this.btnDamlaTurk.Size = new System.Drawing.Size(182, 150);
            this.btnDamlaTurk.TabIndex = 17;
            this.btnDamlaTurk.Text = "Damla Sakızlı Türk Kahvesi";
            this.btnDamlaTurk.UseVisualStyleBackColor = false;
            this.btnDamlaTurk.Click += new System.EventHandler(this.btnDamlaTurk_Click);
            // 
            // lblTurk
            // 
            this.lblTurk.AutoSize = true;
            this.lblTurk.BackColor = System.Drawing.Color.Snow;
            this.lblTurk.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.lblTurk.Location = new System.Drawing.Point(274, 350);
            this.lblTurk.Name = "lblTurk";
            this.lblTurk.Size = new System.Drawing.Size(34, 23);
            this.lblTurk.TabIndex = 16;
            this.lblTurk.Text = "25";
            // 
            // lblEspresso
            // 
            this.lblEspresso.AutoSize = true;
            this.lblEspresso.BackColor = System.Drawing.Color.Snow;
            this.lblEspresso.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.lblEspresso.Location = new System.Drawing.Point(86, 350);
            this.lblEspresso.Name = "lblEspresso";
            this.lblEspresso.Size = new System.Drawing.Size(34, 23);
            this.lblEspresso.TabIndex = 15;
            this.lblEspresso.Text = "20";
            // 
            // lblCapp
            // 
            this.lblCapp.AutoSize = true;
            this.lblCapp.BackColor = System.Drawing.Color.Snow;
            this.lblCapp.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.lblCapp.Location = new System.Drawing.Point(650, 165);
            this.lblCapp.Name = "lblCapp";
            this.lblCapp.Size = new System.Drawing.Size(34, 23);
            this.lblCapp.TabIndex = 14;
            this.lblCapp.Text = "20";
            // 
            // lblLatte
            // 
            this.lblLatte.AutoSize = true;
            this.lblLatte.BackColor = System.Drawing.Color.Snow;
            this.lblLatte.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.lblLatte.Location = new System.Drawing.Point(462, 165);
            this.lblLatte.Name = "lblLatte";
            this.lblLatte.Size = new System.Drawing.Size(34, 23);
            this.lblLatte.TabIndex = 13;
            this.lblLatte.Text = "20";
            // 
            // lblMocha
            // 
            this.lblMocha.AutoSize = true;
            this.lblMocha.BackColor = System.Drawing.Color.Snow;
            this.lblMocha.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.lblMocha.Location = new System.Drawing.Point(274, 165);
            this.lblMocha.Name = "lblMocha";
            this.lblMocha.Size = new System.Drawing.Size(34, 23);
            this.lblMocha.TabIndex = 12;
            this.lblMocha.Text = "20";
            // 
            // btnTurk
            // 
            this.btnTurk.BackColor = System.Drawing.Color.Snow;
            this.btnTurk.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.btnTurk.Location = new System.Drawing.Point(200, 197);
            this.btnTurk.Name = "btnTurk";
            this.btnTurk.Size = new System.Drawing.Size(182, 150);
            this.btnTurk.TabIndex = 9;
            this.btnTurk.Text = "Türk Kahvesi";
            this.btnTurk.UseVisualStyleBackColor = false;
            this.btnTurk.Click += new System.EventHandler(this.btnTurk_Click);
            // 
            // btnEspresso
            // 
            this.btnEspresso.BackColor = System.Drawing.Color.Snow;
            this.btnEspresso.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.btnEspresso.Location = new System.Drawing.Point(12, 197);
            this.btnEspresso.Name = "btnEspresso";
            this.btnEspresso.Size = new System.Drawing.Size(182, 150);
            this.btnEspresso.TabIndex = 8;
            this.btnEspresso.Text = "Espresso";
            this.btnEspresso.UseVisualStyleBackColor = false;
            this.btnEspresso.Click += new System.EventHandler(this.btnEspresso_Click);
            // 
            // lblCay
            // 
            this.lblCay.AutoSize = true;
            this.lblCay.BackColor = System.Drawing.Color.Snow;
            this.lblCay.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.lblCay.Location = new System.Drawing.Point(92, 165);
            this.lblCay.Name = "lblCay";
            this.lblCay.Size = new System.Drawing.Size(22, 23);
            this.lblCay.TabIndex = 7;
            this.lblCay.Text = "5";
            // 
            // btnCapp
            // 
            this.btnCapp.BackColor = System.Drawing.Color.Snow;
            this.btnCapp.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.btnCapp.Location = new System.Drawing.Point(576, 12);
            this.btnCapp.Name = "btnCapp";
            this.btnCapp.Size = new System.Drawing.Size(182, 150);
            this.btnCapp.TabIndex = 6;
            this.btnCapp.Text = "Cappucino";
            this.btnCapp.UseVisualStyleBackColor = false;
            this.btnCapp.Click += new System.EventHandler(this.btnCapp_Click);
            // 
            // btnLatte
            // 
            this.btnLatte.BackColor = System.Drawing.Color.Snow;
            this.btnLatte.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.btnLatte.Location = new System.Drawing.Point(388, 12);
            this.btnLatte.Name = "btnLatte";
            this.btnLatte.Size = new System.Drawing.Size(182, 150);
            this.btnLatte.TabIndex = 2;
            this.btnLatte.Text = "Latte";
            this.btnLatte.UseVisualStyleBackColor = false;
            this.btnLatte.Click += new System.EventHandler(this.btnLatte_Click);
            // 
            // btnMocha
            // 
            this.btnMocha.BackColor = System.Drawing.Color.Snow;
            this.btnMocha.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.btnMocha.Location = new System.Drawing.Point(200, 12);
            this.btnMocha.Name = "btnMocha";
            this.btnMocha.Size = new System.Drawing.Size(182, 150);
            this.btnMocha.TabIndex = 1;
            this.btnMocha.Text = "Mocha";
            this.btnMocha.UseVisualStyleBackColor = false;
            this.btnMocha.Click += new System.EventHandler(this.btnMocha_Click);
            // 
            // btnCay
            // 
            this.btnCay.BackColor = System.Drawing.Color.Snow;
            this.btnCay.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.btnCay.Location = new System.Drawing.Point(12, 12);
            this.btnCay.Name = "btnCay";
            this.btnCay.Size = new System.Drawing.Size(182, 150);
            this.btnCay.TabIndex = 0;
            this.btnCay.Text = "Çay";
            this.btnCay.UseVisualStyleBackColor = false;
            this.btnCay.Click += new System.EventHandler(this.btnCay_Click);
            // 
            // SicakIceceklerForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.RosyBrown;
            this.ClientSize = new System.Drawing.Size(1255, 657);
            this.Controls.Add(this.splitSicakI);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "SicakIceceklerForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Sıcak İçecekler";
            this.Load += new System.EventHandler(this.SicakIceceklerForm_Load);
            this.splitSicakI.Panel1.ResumeLayout(false);
            this.splitSicakI.Panel2.ResumeLayout(false);
            this.splitSicakI.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitSicakI)).EndInit();
            this.splitSicakI.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgwSicakI)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.SplitContainer splitSicakI;
        private System.Windows.Forms.Label lblSicakCiko;
        private System.Windows.Forms.Button btnSicakCiko;
        private System.Windows.Forms.Label lblBalliSut;
        private System.Windows.Forms.Button btnBalliSut;
        private System.Windows.Forms.Label lblSahlep;
        private System.Windows.Forms.Button btnSahlep;
        private System.Windows.Forms.Label lblMenengic;
        private System.Windows.Forms.Button btnMenengic;
        private System.Windows.Forms.Label lblDibek;
        private System.Windows.Forms.Button btnDibek;
        private System.Windows.Forms.Label lblDamlaTurk;
        private System.Windows.Forms.Button btnDamlaTurk;
        private System.Windows.Forms.Label lblTurk;
        private System.Windows.Forms.Label lblEspresso;
        private System.Windows.Forms.Label lblCapp;
        private System.Windows.Forms.Label lblLatte;
        private System.Windows.Forms.Label lblMocha;
        private System.Windows.Forms.Button btnTurk;
        private System.Windows.Forms.Button btnEspresso;
        private System.Windows.Forms.Label lblCay;
        private System.Windows.Forms.Button btnCapp;
        private System.Windows.Forms.Button btnLatte;
        private System.Windows.Forms.Button btnMocha;
        private System.Windows.Forms.Button btnCay;
        private System.Windows.Forms.Button btnMenuDon11;
        private System.Windows.Forms.DataGridView dgwSicakI;
    }
}