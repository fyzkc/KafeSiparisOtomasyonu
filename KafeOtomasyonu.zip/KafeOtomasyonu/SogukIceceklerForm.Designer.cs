﻿
namespace KafeOtomasyonu
{
    partial class SogukIceceklerForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SogukIceceklerForm));
            this.splitSogukI = new System.Windows.Forms.SplitContainer();
            this.btnMenuDon12 = new System.Windows.Forms.Button();
            this.dgwSogukI = new System.Windows.Forms.DataGridView();
            this.lblRedbull = new System.Windows.Forms.Label();
            this.btnRedbull = new System.Windows.Forms.Button();
            this.lblMeyveSoda = new System.Windows.Forms.Label();
            this.btnMeyveSoda = new System.Windows.Forms.Button();
            this.lblSadeSoda = new System.Windows.Forms.Label();
            this.btnSadeSoda = new System.Windows.Forms.Button();
            this.lblIceTeaLim = new System.Windows.Forms.Label();
            this.btnIceTeaLim = new System.Windows.Forms.Button();
            this.lblIceTeaSef = new System.Windows.Forms.Label();
            this.btnIceTeaSef = new System.Windows.Forms.Button();
            this.lblSprite = new System.Windows.Forms.Label();
            this.btnSprite = new System.Windows.Forms.Button();
            this.lblFanta = new System.Windows.Forms.Label();
            this.btnFanta = new System.Windows.Forms.Button();
            this.lblCola = new System.Windows.Forms.Label();
            this.btnCola = new System.Windows.Forms.Button();
            this.lblAtom = new System.Windows.Forms.Label();
            this.btnAtom = new System.Windows.Forms.Button();
            this.lblPortakalSu = new System.Windows.Forms.Label();
            this.btnPortakalSu = new System.Windows.Forms.Button();
            this.lblLimonata = new System.Windows.Forms.Label();
            this.btnLimonata = new System.Windows.Forms.Button();
            this.lblOreoMilks = new System.Windows.Forms.Label();
            this.btnOreoMilks = new System.Windows.Forms.Button();
            this.lblVanilyaMilks = new System.Windows.Forms.Label();
            this.btnVanilyaMilks = new System.Windows.Forms.Button();
            this.lblCikoMilks = new System.Windows.Forms.Label();
            this.btnCikoMilks = new System.Windows.Forms.Button();
            this.lblCilekMilks = new System.Windows.Forms.Label();
            this.lblIcedEspresso = new System.Windows.Forms.Label();
            this.lblIcedCapp = new System.Windows.Forms.Label();
            this.lblIcedLatte = new System.Windows.Forms.Label();
            this.lblIcedMocha = new System.Windows.Forms.Label();
            this.btnCilekMilks = new System.Windows.Forms.Button();
            this.btnIcedEspresso = new System.Windows.Forms.Button();
            this.lblSu = new System.Windows.Forms.Label();
            this.btnIcedCapp = new System.Windows.Forms.Button();
            this.btnIcedLatte = new System.Windows.Forms.Button();
            this.btnIcedMocha = new System.Windows.Forms.Button();
            this.btnSu = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.splitSogukI)).BeginInit();
            this.splitSogukI.Panel1.SuspendLayout();
            this.splitSogukI.Panel2.SuspendLayout();
            this.splitSogukI.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgwSogukI)).BeginInit();
            this.SuspendLayout();
            // 
            // splitSogukI
            // 
            this.splitSogukI.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitSogukI.Location = new System.Drawing.Point(0, 0);
            this.splitSogukI.Name = "splitSogukI";
            // 
            // splitSogukI.Panel1
            // 
            this.splitSogukI.Panel1.Controls.Add(this.dgwSogukI);
            // 
            // splitSogukI.Panel2
            // 
            this.splitSogukI.Panel2.Controls.Add(this.btnMenuDon12);
            this.splitSogukI.Panel2.Controls.Add(this.lblRedbull);
            this.splitSogukI.Panel2.Controls.Add(this.btnRedbull);
            this.splitSogukI.Panel2.Controls.Add(this.lblMeyveSoda);
            this.splitSogukI.Panel2.Controls.Add(this.btnMeyveSoda);
            this.splitSogukI.Panel2.Controls.Add(this.lblSadeSoda);
            this.splitSogukI.Panel2.Controls.Add(this.btnSadeSoda);
            this.splitSogukI.Panel2.Controls.Add(this.lblIceTeaLim);
            this.splitSogukI.Panel2.Controls.Add(this.btnIceTeaLim);
            this.splitSogukI.Panel2.Controls.Add(this.lblIceTeaSef);
            this.splitSogukI.Panel2.Controls.Add(this.btnIceTeaSef);
            this.splitSogukI.Panel2.Controls.Add(this.lblSprite);
            this.splitSogukI.Panel2.Controls.Add(this.btnSprite);
            this.splitSogukI.Panel2.Controls.Add(this.lblFanta);
            this.splitSogukI.Panel2.Controls.Add(this.btnFanta);
            this.splitSogukI.Panel2.Controls.Add(this.lblCola);
            this.splitSogukI.Panel2.Controls.Add(this.btnCola);
            this.splitSogukI.Panel2.Controls.Add(this.lblAtom);
            this.splitSogukI.Panel2.Controls.Add(this.btnAtom);
            this.splitSogukI.Panel2.Controls.Add(this.lblPortakalSu);
            this.splitSogukI.Panel2.Controls.Add(this.btnPortakalSu);
            this.splitSogukI.Panel2.Controls.Add(this.lblLimonata);
            this.splitSogukI.Panel2.Controls.Add(this.btnLimonata);
            this.splitSogukI.Panel2.Controls.Add(this.lblOreoMilks);
            this.splitSogukI.Panel2.Controls.Add(this.btnOreoMilks);
            this.splitSogukI.Panel2.Controls.Add(this.lblVanilyaMilks);
            this.splitSogukI.Panel2.Controls.Add(this.btnVanilyaMilks);
            this.splitSogukI.Panel2.Controls.Add(this.lblCikoMilks);
            this.splitSogukI.Panel2.Controls.Add(this.btnCikoMilks);
            this.splitSogukI.Panel2.Controls.Add(this.lblCilekMilks);
            this.splitSogukI.Panel2.Controls.Add(this.lblIcedEspresso);
            this.splitSogukI.Panel2.Controls.Add(this.lblIcedCapp);
            this.splitSogukI.Panel2.Controls.Add(this.lblIcedLatte);
            this.splitSogukI.Panel2.Controls.Add(this.lblIcedMocha);
            this.splitSogukI.Panel2.Controls.Add(this.btnCilekMilks);
            this.splitSogukI.Panel2.Controls.Add(this.btnIcedEspresso);
            this.splitSogukI.Panel2.Controls.Add(this.lblSu);
            this.splitSogukI.Panel2.Controls.Add(this.btnIcedCapp);
            this.splitSogukI.Panel2.Controls.Add(this.btnIcedLatte);
            this.splitSogukI.Panel2.Controls.Add(this.btnIcedMocha);
            this.splitSogukI.Panel2.Controls.Add(this.btnSu);
            this.splitSogukI.Size = new System.Drawing.Size(1255, 657);
            this.splitSogukI.SplitterDistance = 326;
            this.splitSogukI.TabIndex = 7;
            // 
            // btnMenuDon12
            // 
            this.btnMenuDon12.BackColor = System.Drawing.Color.Snow;
            this.btnMenuDon12.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.btnMenuDon12.Location = new System.Drawing.Point(775, 595);
            this.btnMenuDon12.Name = "btnMenuDon12";
            this.btnMenuDon12.Size = new System.Drawing.Size(138, 50);
            this.btnMenuDon12.TabIndex = 19;
            this.btnMenuDon12.Text = "Geri";
            this.btnMenuDon12.UseVisualStyleBackColor = false;
            this.btnMenuDon12.Click += new System.EventHandler(this.btnMenuDon12_Click);
            // 
            // dgwSogukI
            // 
            this.dgwSogukI.BackgroundColor = System.Drawing.Color.Snow;
            this.dgwSogukI.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgwSogukI.Location = new System.Drawing.Point(12, 12);
            this.dgwSogukI.Name = "dgwSogukI";
            this.dgwSogukI.RowHeadersWidth = 62;
            this.dgwSogukI.RowTemplate.Height = 28;
            this.dgwSogukI.Size = new System.Drawing.Size(297, 503);
            this.dgwSogukI.TabIndex = 18;
            // 
            // lblRedbull
            // 
            this.lblRedbull.AutoSize = true;
            this.lblRedbull.BackColor = System.Drawing.Color.Snow;
            this.lblRedbull.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.lblRedbull.Location = new System.Drawing.Point(206, 566);
            this.lblRedbull.Name = "lblRedbull";
            this.lblRedbull.Size = new System.Drawing.Size(34, 23);
            this.lblRedbull.TabIndex = 44;
            this.lblRedbull.Text = "20";
            // 
            // btnRedbull
            // 
            this.btnRedbull.BackColor = System.Drawing.Color.Snow;
            this.btnRedbull.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.btnRedbull.Location = new System.Drawing.Point(155, 451);
            this.btnRedbull.Name = "btnRedbull";
            this.btnRedbull.Size = new System.Drawing.Size(137, 115);
            this.btnRedbull.TabIndex = 43;
            this.btnRedbull.Text = "Redbull";
            this.btnRedbull.UseVisualStyleBackColor = false;
            this.btnRedbull.Click += new System.EventHandler(this.btnRedbull_Click);
            // 
            // lblMeyveSoda
            // 
            this.lblMeyveSoda.AutoSize = true;
            this.lblMeyveSoda.BackColor = System.Drawing.Color.Snow;
            this.lblMeyveSoda.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.lblMeyveSoda.Location = new System.Drawing.Point(63, 566);
            this.lblMeyveSoda.Name = "lblMeyveSoda";
            this.lblMeyveSoda.Size = new System.Drawing.Size(34, 23);
            this.lblMeyveSoda.TabIndex = 42;
            this.lblMeyveSoda.Text = "15";
            // 
            // btnMeyveSoda
            // 
            this.btnMeyveSoda.BackColor = System.Drawing.Color.Snow;
            this.btnMeyveSoda.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.btnMeyveSoda.Location = new System.Drawing.Point(12, 451);
            this.btnMeyveSoda.Name = "btnMeyveSoda";
            this.btnMeyveSoda.Size = new System.Drawing.Size(137, 115);
            this.btnMeyveSoda.TabIndex = 41;
            this.btnMeyveSoda.Text = "Meyveli Soda";
            this.btnMeyveSoda.UseVisualStyleBackColor = false;
            this.btnMeyveSoda.Click += new System.EventHandler(this.btnMeyveSoda_Click);
            // 
            // lblSadeSoda
            // 
            this.lblSadeSoda.AutoSize = true;
            this.lblSadeSoda.BackColor = System.Drawing.Color.Snow;
            this.lblSadeSoda.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.lblSadeSoda.Location = new System.Drawing.Point(778, 423);
            this.lblSadeSoda.Name = "lblSadeSoda";
            this.lblSadeSoda.Size = new System.Drawing.Size(34, 23);
            this.lblSadeSoda.TabIndex = 40;
            this.lblSadeSoda.Text = "15";
            // 
            // btnSadeSoda
            // 
            this.btnSadeSoda.BackColor = System.Drawing.Color.Snow;
            this.btnSadeSoda.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.btnSadeSoda.Location = new System.Drawing.Point(727, 306);
            this.btnSadeSoda.Name = "btnSadeSoda";
            this.btnSadeSoda.Size = new System.Drawing.Size(137, 115);
            this.btnSadeSoda.TabIndex = 39;
            this.btnSadeSoda.Text = "Sade Soda";
            this.btnSadeSoda.UseVisualStyleBackColor = false;
            this.btnSadeSoda.Click += new System.EventHandler(this.btnSadeSoda_Click);
            // 
            // lblIceTeaLim
            // 
            this.lblIceTeaLim.AutoSize = true;
            this.lblIceTeaLim.BackColor = System.Drawing.Color.Snow;
            this.lblIceTeaLim.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.lblIceTeaLim.Location = new System.Drawing.Point(635, 423);
            this.lblIceTeaLim.Name = "lblIceTeaLim";
            this.lblIceTeaLim.Size = new System.Drawing.Size(34, 23);
            this.lblIceTeaLim.TabIndex = 38;
            this.lblIceTeaLim.Text = "15";
            // 
            // btnIceTeaLim
            // 
            this.btnIceTeaLim.BackColor = System.Drawing.Color.Snow;
            this.btnIceTeaLim.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.btnIceTeaLim.Location = new System.Drawing.Point(584, 306);
            this.btnIceTeaLim.Name = "btnIceTeaLim";
            this.btnIceTeaLim.Size = new System.Drawing.Size(137, 115);
            this.btnIceTeaLim.TabIndex = 37;
            this.btnIceTeaLim.Text = "Limonlu Ice Tea";
            this.btnIceTeaLim.UseVisualStyleBackColor = false;
            this.btnIceTeaLim.Click += new System.EventHandler(this.btnIceTeaLim_Click);
            // 
            // lblIceTeaSef
            // 
            this.lblIceTeaSef.AutoSize = true;
            this.lblIceTeaSef.BackColor = System.Drawing.Color.Snow;
            this.lblIceTeaSef.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.lblIceTeaSef.Location = new System.Drawing.Point(492, 423);
            this.lblIceTeaSef.Name = "lblIceTeaSef";
            this.lblIceTeaSef.Size = new System.Drawing.Size(34, 23);
            this.lblIceTeaSef.TabIndex = 36;
            this.lblIceTeaSef.Text = "15";
            // 
            // btnIceTeaSef
            // 
            this.btnIceTeaSef.BackColor = System.Drawing.Color.Snow;
            this.btnIceTeaSef.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.btnIceTeaSef.Location = new System.Drawing.Point(441, 306);
            this.btnIceTeaSef.Name = "btnIceTeaSef";
            this.btnIceTeaSef.Size = new System.Drawing.Size(137, 115);
            this.btnIceTeaSef.TabIndex = 35;
            this.btnIceTeaSef.Text = "Şeftalili Ice Tea";
            this.btnIceTeaSef.UseVisualStyleBackColor = false;
            this.btnIceTeaSef.Click += new System.EventHandler(this.btnIceTeaSef_Click);
            // 
            // lblSprite
            // 
            this.lblSprite.AutoSize = true;
            this.lblSprite.BackColor = System.Drawing.Color.Snow;
            this.lblSprite.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.lblSprite.Location = new System.Drawing.Point(349, 423);
            this.lblSprite.Name = "lblSprite";
            this.lblSprite.Size = new System.Drawing.Size(34, 23);
            this.lblSprite.TabIndex = 34;
            this.lblSprite.Text = "15";
            // 
            // btnSprite
            // 
            this.btnSprite.BackColor = System.Drawing.Color.Snow;
            this.btnSprite.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.btnSprite.Location = new System.Drawing.Point(298, 306);
            this.btnSprite.Name = "btnSprite";
            this.btnSprite.Size = new System.Drawing.Size(137, 115);
            this.btnSprite.TabIndex = 33;
            this.btnSprite.Text = "Sprite";
            this.btnSprite.UseVisualStyleBackColor = false;
            this.btnSprite.Click += new System.EventHandler(this.btnSprite_Click);
            // 
            // lblFanta
            // 
            this.lblFanta.AutoSize = true;
            this.lblFanta.BackColor = System.Drawing.Color.Snow;
            this.lblFanta.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.lblFanta.Location = new System.Drawing.Point(206, 423);
            this.lblFanta.Name = "lblFanta";
            this.lblFanta.Size = new System.Drawing.Size(34, 23);
            this.lblFanta.TabIndex = 32;
            this.lblFanta.Text = "15";
            // 
            // btnFanta
            // 
            this.btnFanta.BackColor = System.Drawing.Color.Snow;
            this.btnFanta.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.btnFanta.Location = new System.Drawing.Point(155, 306);
            this.btnFanta.Name = "btnFanta";
            this.btnFanta.Size = new System.Drawing.Size(137, 115);
            this.btnFanta.TabIndex = 31;
            this.btnFanta.Text = "Fanta";
            this.btnFanta.UseVisualStyleBackColor = false;
            this.btnFanta.Click += new System.EventHandler(this.btnFanta_Click);
            // 
            // lblCola
            // 
            this.lblCola.AutoSize = true;
            this.lblCola.BackColor = System.Drawing.Color.Snow;
            this.lblCola.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.lblCola.Location = new System.Drawing.Point(63, 423);
            this.lblCola.Name = "lblCola";
            this.lblCola.Size = new System.Drawing.Size(34, 23);
            this.lblCola.TabIndex = 30;
            this.lblCola.Text = "15";
            // 
            // btnCola
            // 
            this.btnCola.BackColor = System.Drawing.Color.Snow;
            this.btnCola.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.btnCola.Location = new System.Drawing.Point(12, 306);
            this.btnCola.Name = "btnCola";
            this.btnCola.Size = new System.Drawing.Size(137, 115);
            this.btnCola.TabIndex = 29;
            this.btnCola.Text = "Coca Cola";
            this.btnCola.UseVisualStyleBackColor = false;
            this.btnCola.Click += new System.EventHandler(this.btnCola_Click);
            // 
            // lblAtom
            // 
            this.lblAtom.AutoSize = true;
            this.lblAtom.BackColor = System.Drawing.Color.Snow;
            this.lblAtom.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.lblAtom.Location = new System.Drawing.Point(778, 273);
            this.lblAtom.Name = "lblAtom";
            this.lblAtom.Size = new System.Drawing.Size(34, 23);
            this.lblAtom.TabIndex = 28;
            this.lblAtom.Text = "25";
            // 
            // btnAtom
            // 
            this.btnAtom.BackColor = System.Drawing.Color.Snow;
            this.btnAtom.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.btnAtom.Location = new System.Drawing.Point(727, 155);
            this.btnAtom.Name = "btnAtom";
            this.btnAtom.Size = new System.Drawing.Size(137, 115);
            this.btnAtom.TabIndex = 27;
            this.btnAtom.Text = "Atom";
            this.btnAtom.UseVisualStyleBackColor = false;
            this.btnAtom.Click += new System.EventHandler(this.btnAtom_Click);
            // 
            // lblPortakalSu
            // 
            this.lblPortakalSu.AutoSize = true;
            this.lblPortakalSu.BackColor = System.Drawing.Color.Snow;
            this.lblPortakalSu.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.lblPortakalSu.Location = new System.Drawing.Point(635, 273);
            this.lblPortakalSu.Name = "lblPortakalSu";
            this.lblPortakalSu.Size = new System.Drawing.Size(34, 23);
            this.lblPortakalSu.TabIndex = 26;
            this.lblPortakalSu.Text = "15";
            // 
            // btnPortakalSu
            // 
            this.btnPortakalSu.BackColor = System.Drawing.Color.Snow;
            this.btnPortakalSu.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.btnPortakalSu.Location = new System.Drawing.Point(584, 155);
            this.btnPortakalSu.Name = "btnPortakalSu";
            this.btnPortakalSu.Size = new System.Drawing.Size(137, 115);
            this.btnPortakalSu.TabIndex = 25;
            this.btnPortakalSu.Text = "Portakal Suyu";
            this.btnPortakalSu.UseVisualStyleBackColor = false;
            this.btnPortakalSu.Click += new System.EventHandler(this.btnPortakalSu_Click);
            // 
            // lblLimonata
            // 
            this.lblLimonata.AutoSize = true;
            this.lblLimonata.BackColor = System.Drawing.Color.Snow;
            this.lblLimonata.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.lblLimonata.Location = new System.Drawing.Point(492, 273);
            this.lblLimonata.Name = "lblLimonata";
            this.lblLimonata.Size = new System.Drawing.Size(34, 23);
            this.lblLimonata.TabIndex = 24;
            this.lblLimonata.Text = "15";
            // 
            // btnLimonata
            // 
            this.btnLimonata.BackColor = System.Drawing.Color.Snow;
            this.btnLimonata.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.btnLimonata.Location = new System.Drawing.Point(441, 155);
            this.btnLimonata.Name = "btnLimonata";
            this.btnLimonata.Size = new System.Drawing.Size(137, 115);
            this.btnLimonata.TabIndex = 23;
            this.btnLimonata.Text = "Limonata";
            this.btnLimonata.UseVisualStyleBackColor = false;
            this.btnLimonata.Click += new System.EventHandler(this.btnLimonata_Click);
            // 
            // lblOreoMilks
            // 
            this.lblOreoMilks.AutoSize = true;
            this.lblOreoMilks.BackColor = System.Drawing.Color.Snow;
            this.lblOreoMilks.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.lblOreoMilks.Location = new System.Drawing.Point(349, 273);
            this.lblOreoMilks.Name = "lblOreoMilks";
            this.lblOreoMilks.Size = new System.Drawing.Size(34, 23);
            this.lblOreoMilks.TabIndex = 22;
            this.lblOreoMilks.Text = "27";
            // 
            // btnOreoMilks
            // 
            this.btnOreoMilks.BackColor = System.Drawing.Color.Snow;
            this.btnOreoMilks.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.btnOreoMilks.Location = new System.Drawing.Point(298, 155);
            this.btnOreoMilks.Name = "btnOreoMilks";
            this.btnOreoMilks.Size = new System.Drawing.Size(137, 115);
            this.btnOreoMilks.TabIndex = 21;
            this.btnOreoMilks.Text = "Oreolu Milkshake";
            this.btnOreoMilks.UseVisualStyleBackColor = false;
            this.btnOreoMilks.Click += new System.EventHandler(this.btnOreoMilks_Click);
            // 
            // lblVanilyaMilks
            // 
            this.lblVanilyaMilks.AutoSize = true;
            this.lblVanilyaMilks.BackColor = System.Drawing.Color.Snow;
            this.lblVanilyaMilks.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.lblVanilyaMilks.Location = new System.Drawing.Point(206, 273);
            this.lblVanilyaMilks.Name = "lblVanilyaMilks";
            this.lblVanilyaMilks.Size = new System.Drawing.Size(34, 23);
            this.lblVanilyaMilks.TabIndex = 20;
            this.lblVanilyaMilks.Text = "25";
            // 
            // btnVanilyaMilks
            // 
            this.btnVanilyaMilks.BackColor = System.Drawing.Color.Snow;
            this.btnVanilyaMilks.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.btnVanilyaMilks.Location = new System.Drawing.Point(155, 155);
            this.btnVanilyaMilks.Name = "btnVanilyaMilks";
            this.btnVanilyaMilks.Size = new System.Drawing.Size(137, 115);
            this.btnVanilyaMilks.TabIndex = 19;
            this.btnVanilyaMilks.Text = "Vanilyalı Milkshake";
            this.btnVanilyaMilks.UseVisualStyleBackColor = false;
            this.btnVanilyaMilks.Click += new System.EventHandler(this.btnVanilyaMilks_Click);
            // 
            // lblCikoMilks
            // 
            this.lblCikoMilks.AutoSize = true;
            this.lblCikoMilks.BackColor = System.Drawing.Color.Snow;
            this.lblCikoMilks.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.lblCikoMilks.Location = new System.Drawing.Point(63, 273);
            this.lblCikoMilks.Name = "lblCikoMilks";
            this.lblCikoMilks.Size = new System.Drawing.Size(34, 23);
            this.lblCikoMilks.TabIndex = 18;
            this.lblCikoMilks.Text = "25";
            // 
            // btnCikoMilks
            // 
            this.btnCikoMilks.BackColor = System.Drawing.Color.Snow;
            this.btnCikoMilks.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.btnCikoMilks.Location = new System.Drawing.Point(12, 155);
            this.btnCikoMilks.Name = "btnCikoMilks";
            this.btnCikoMilks.Size = new System.Drawing.Size(137, 115);
            this.btnCikoMilks.TabIndex = 17;
            this.btnCikoMilks.Text = "Çikolatalı Milkshake";
            this.btnCikoMilks.UseVisualStyleBackColor = false;
            this.btnCikoMilks.Click += new System.EventHandler(this.btnCikoMilks_Click);
            // 
            // lblCilekMilks
            // 
            this.lblCilekMilks.AutoSize = true;
            this.lblCilekMilks.BackColor = System.Drawing.Color.Snow;
            this.lblCilekMilks.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.lblCilekMilks.Location = new System.Drawing.Point(778, 125);
            this.lblCilekMilks.Name = "lblCilekMilks";
            this.lblCilekMilks.Size = new System.Drawing.Size(34, 23);
            this.lblCilekMilks.TabIndex = 16;
            this.lblCilekMilks.Text = "25";
            // 
            // lblIcedEspresso
            // 
            this.lblIcedEspresso.AutoSize = true;
            this.lblIcedEspresso.BackColor = System.Drawing.Color.Snow;
            this.lblIcedEspresso.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.lblIcedEspresso.Location = new System.Drawing.Point(635, 125);
            this.lblIcedEspresso.Name = "lblIcedEspresso";
            this.lblIcedEspresso.Size = new System.Drawing.Size(34, 23);
            this.lblIcedEspresso.TabIndex = 15;
            this.lblIcedEspresso.Text = "20";
            // 
            // lblIcedCapp
            // 
            this.lblIcedCapp.AutoSize = true;
            this.lblIcedCapp.BackColor = System.Drawing.Color.Snow;
            this.lblIcedCapp.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.lblIcedCapp.Location = new System.Drawing.Point(492, 125);
            this.lblIcedCapp.Name = "lblIcedCapp";
            this.lblIcedCapp.Size = new System.Drawing.Size(34, 23);
            this.lblIcedCapp.TabIndex = 14;
            this.lblIcedCapp.Text = "20";
            // 
            // lblIcedLatte
            // 
            this.lblIcedLatte.AutoSize = true;
            this.lblIcedLatte.BackColor = System.Drawing.Color.Snow;
            this.lblIcedLatte.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.lblIcedLatte.Location = new System.Drawing.Point(349, 125);
            this.lblIcedLatte.Name = "lblIcedLatte";
            this.lblIcedLatte.Size = new System.Drawing.Size(34, 23);
            this.lblIcedLatte.TabIndex = 13;
            this.lblIcedLatte.Text = "20";
            // 
            // lblIcedMocha
            // 
            this.lblIcedMocha.AutoSize = true;
            this.lblIcedMocha.BackColor = System.Drawing.Color.Snow;
            this.lblIcedMocha.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.lblIcedMocha.Location = new System.Drawing.Point(206, 125);
            this.lblIcedMocha.Name = "lblIcedMocha";
            this.lblIcedMocha.Size = new System.Drawing.Size(34, 23);
            this.lblIcedMocha.TabIndex = 12;
            this.lblIcedMocha.Text = "20";
            // 
            // btnCilekMilks
            // 
            this.btnCilekMilks.BackColor = System.Drawing.Color.Snow;
            this.btnCilekMilks.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.btnCilekMilks.Location = new System.Drawing.Point(727, 7);
            this.btnCilekMilks.Name = "btnCilekMilks";
            this.btnCilekMilks.Size = new System.Drawing.Size(137, 115);
            this.btnCilekMilks.TabIndex = 9;
            this.btnCilekMilks.Text = "Çilekli Milkshake";
            this.btnCilekMilks.UseVisualStyleBackColor = false;
            this.btnCilekMilks.Click += new System.EventHandler(this.btnCilekMilks_Click);
            // 
            // btnIcedEspresso
            // 
            this.btnIcedEspresso.BackColor = System.Drawing.Color.Snow;
            this.btnIcedEspresso.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.btnIcedEspresso.Location = new System.Drawing.Point(584, 7);
            this.btnIcedEspresso.Name = "btnIcedEspresso";
            this.btnIcedEspresso.Size = new System.Drawing.Size(137, 115);
            this.btnIcedEspresso.TabIndex = 8;
            this.btnIcedEspresso.Text = "Iced Espresso";
            this.btnIcedEspresso.UseVisualStyleBackColor = false;
            this.btnIcedEspresso.Click += new System.EventHandler(this.btnIcedEspresso_Click);
            // 
            // lblSu
            // 
            this.lblSu.AutoSize = true;
            this.lblSu.BackColor = System.Drawing.Color.Snow;
            this.lblSu.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.lblSu.Location = new System.Drawing.Point(69, 125);
            this.lblSu.Name = "lblSu";
            this.lblSu.Size = new System.Drawing.Size(22, 23);
            this.lblSu.TabIndex = 7;
            this.lblSu.Text = "3";
            // 
            // btnIcedCapp
            // 
            this.btnIcedCapp.BackColor = System.Drawing.Color.Snow;
            this.btnIcedCapp.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.btnIcedCapp.Location = new System.Drawing.Point(441, 7);
            this.btnIcedCapp.Name = "btnIcedCapp";
            this.btnIcedCapp.Size = new System.Drawing.Size(137, 115);
            this.btnIcedCapp.TabIndex = 6;
            this.btnIcedCapp.Text = "Iced Cappucino";
            this.btnIcedCapp.UseVisualStyleBackColor = false;
            this.btnIcedCapp.Click += new System.EventHandler(this.btnIcedCapp_Click);
            // 
            // btnIcedLatte
            // 
            this.btnIcedLatte.BackColor = System.Drawing.Color.Snow;
            this.btnIcedLatte.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.btnIcedLatte.Location = new System.Drawing.Point(298, 7);
            this.btnIcedLatte.Name = "btnIcedLatte";
            this.btnIcedLatte.Size = new System.Drawing.Size(137, 115);
            this.btnIcedLatte.TabIndex = 2;
            this.btnIcedLatte.Text = "Iced Latte";
            this.btnIcedLatte.UseVisualStyleBackColor = false;
            this.btnIcedLatte.Click += new System.EventHandler(this.btnIcedLatte_Click);
            // 
            // btnIcedMocha
            // 
            this.btnIcedMocha.BackColor = System.Drawing.Color.Snow;
            this.btnIcedMocha.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.btnIcedMocha.Location = new System.Drawing.Point(155, 7);
            this.btnIcedMocha.Name = "btnIcedMocha";
            this.btnIcedMocha.Size = new System.Drawing.Size(137, 115);
            this.btnIcedMocha.TabIndex = 1;
            this.btnIcedMocha.Text = "Iced Mocha";
            this.btnIcedMocha.UseVisualStyleBackColor = false;
            this.btnIcedMocha.Click += new System.EventHandler(this.btnIcedMocha_Click);
            // 
            // btnSu
            // 
            this.btnSu.BackColor = System.Drawing.Color.Snow;
            this.btnSu.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.btnSu.Location = new System.Drawing.Point(12, 7);
            this.btnSu.Name = "btnSu";
            this.btnSu.Size = new System.Drawing.Size(137, 115);
            this.btnSu.TabIndex = 0;
            this.btnSu.Text = "Su";
            this.btnSu.UseVisualStyleBackColor = false;
            this.btnSu.Click += new System.EventHandler(this.btnSu_Click);
            // 
            // SogukIceceklerForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.RosyBrown;
            this.ClientSize = new System.Drawing.Size(1255, 657);
            this.Controls.Add(this.splitSogukI);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "SogukIceceklerForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Soguk İçecekler";
            this.Load += new System.EventHandler(this.SogukIceceklerForm_Load);
            this.splitSogukI.Panel1.ResumeLayout(false);
            this.splitSogukI.Panel2.ResumeLayout(false);
            this.splitSogukI.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitSogukI)).EndInit();
            this.splitSogukI.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgwSogukI)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.SplitContainer splitSogukI;
        private System.Windows.Forms.Label lblAtom;
        private System.Windows.Forms.Button btnAtom;
        private System.Windows.Forms.Label lblPortakalSu;
        private System.Windows.Forms.Button btnPortakalSu;
        private System.Windows.Forms.Label lblLimonata;
        private System.Windows.Forms.Button btnLimonata;
        private System.Windows.Forms.Label lblOreoMilks;
        private System.Windows.Forms.Button btnOreoMilks;
        private System.Windows.Forms.Label lblVanilyaMilks;
        private System.Windows.Forms.Button btnVanilyaMilks;
        private System.Windows.Forms.Label lblCikoMilks;
        private System.Windows.Forms.Button btnCikoMilks;
        private System.Windows.Forms.Label lblCilekMilks;
        private System.Windows.Forms.Label lblIcedEspresso;
        private System.Windows.Forms.Label lblIcedCapp;
        private System.Windows.Forms.Label lblIcedLatte;
        private System.Windows.Forms.Label lblIcedMocha;
        private System.Windows.Forms.Button btnCilekMilks;
        private System.Windows.Forms.Button btnIcedEspresso;
        private System.Windows.Forms.Label lblSu;
        private System.Windows.Forms.Button btnIcedCapp;
        private System.Windows.Forms.Button btnIcedLatte;
        private System.Windows.Forms.Button btnIcedMocha;
        private System.Windows.Forms.Button btnSu;
        private System.Windows.Forms.Label lblMeyveSoda;
        private System.Windows.Forms.Button btnMeyveSoda;
        private System.Windows.Forms.Label lblSadeSoda;
        private System.Windows.Forms.Button btnSadeSoda;
        private System.Windows.Forms.Label lblIceTeaLim;
        private System.Windows.Forms.Button btnIceTeaLim;
        private System.Windows.Forms.Label lblIceTeaSef;
        private System.Windows.Forms.Button btnIceTeaSef;
        private System.Windows.Forms.Label lblSprite;
        private System.Windows.Forms.Button btnSprite;
        private System.Windows.Forms.Label lblFanta;
        private System.Windows.Forms.Button btnFanta;
        private System.Windows.Forms.Label lblCola;
        private System.Windows.Forms.Button btnCola;
        private System.Windows.Forms.Label lblRedbull;
        private System.Windows.Forms.Button btnRedbull;
        private System.Windows.Forms.Button btnMenuDon12;
        private System.Windows.Forms.DataGridView dgwSogukI;
    }
}