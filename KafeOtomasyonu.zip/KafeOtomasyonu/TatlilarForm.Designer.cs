﻿
namespace KafeOtomasyonu
{
    partial class TatlilarForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(TatlilarForm));
            this.splitTatlilar = new System.Windows.Forms.SplitContainer();
            this.btnMenuDon10 = new System.Windows.Forms.Button();
            this.dgwTatli = new System.Windows.Forms.DataGridView();
            this.lblDilimPCilek = new System.Windows.Forms.Label();
            this.btnDilimPCilek = new System.Windows.Forms.Button();
            this.lblDilimPMeyve = new System.Windows.Forms.Label();
            this.btnDilimPMeyve = new System.Windows.Forms.Button();
            this.lblDilimPCiko = new System.Windows.Forms.Label();
            this.btnDilimPCiko = new System.Windows.Forms.Button();
            this.lblPastaProf = new System.Windows.Forms.Label();
            this.btnPastaProf = new System.Windows.Forms.Button();
            this.lblTrileceF = new System.Windows.Forms.Label();
            this.lblTrileceK = new System.Windows.Forms.Label();
            this.lblRedVel = new System.Windows.Forms.Label();
            this.lblLimCheesecake = new System.Windows.Forms.Label();
            this.lblFramCheesecake = new System.Windows.Forms.Label();
            this.btnTrileceF = new System.Windows.Forms.Button();
            this.btnTrileceK = new System.Windows.Forms.Button();
            this.lblSanSeb = new System.Windows.Forms.Label();
            this.btnRedVel = new System.Windows.Forms.Button();
            this.btnLimCheesecake = new System.Windows.Forms.Button();
            this.btnFramCheesecake = new System.Windows.Forms.Button();
            this.btnSanSeb = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.splitTatlilar)).BeginInit();
            this.splitTatlilar.Panel1.SuspendLayout();
            this.splitTatlilar.Panel2.SuspendLayout();
            this.splitTatlilar.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgwTatli)).BeginInit();
            this.SuspendLayout();
            // 
            // splitTatlilar
            // 
            this.splitTatlilar.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitTatlilar.Location = new System.Drawing.Point(0, 0);
            this.splitTatlilar.Name = "splitTatlilar";
            // 
            // splitTatlilar.Panel1
            // 
            this.splitTatlilar.Panel1.Controls.Add(this.dgwTatli);
            // 
            // splitTatlilar.Panel2
            // 
            this.splitTatlilar.Panel2.Controls.Add(this.btnMenuDon10);
            this.splitTatlilar.Panel2.Controls.Add(this.lblDilimPCilek);
            this.splitTatlilar.Panel2.Controls.Add(this.btnDilimPCilek);
            this.splitTatlilar.Panel2.Controls.Add(this.lblDilimPMeyve);
            this.splitTatlilar.Panel2.Controls.Add(this.btnDilimPMeyve);
            this.splitTatlilar.Panel2.Controls.Add(this.lblDilimPCiko);
            this.splitTatlilar.Panel2.Controls.Add(this.btnDilimPCiko);
            this.splitTatlilar.Panel2.Controls.Add(this.lblPastaProf);
            this.splitTatlilar.Panel2.Controls.Add(this.btnPastaProf);
            this.splitTatlilar.Panel2.Controls.Add(this.lblTrileceF);
            this.splitTatlilar.Panel2.Controls.Add(this.lblTrileceK);
            this.splitTatlilar.Panel2.Controls.Add(this.lblRedVel);
            this.splitTatlilar.Panel2.Controls.Add(this.lblLimCheesecake);
            this.splitTatlilar.Panel2.Controls.Add(this.lblFramCheesecake);
            this.splitTatlilar.Panel2.Controls.Add(this.btnTrileceF);
            this.splitTatlilar.Panel2.Controls.Add(this.btnTrileceK);
            this.splitTatlilar.Panel2.Controls.Add(this.lblSanSeb);
            this.splitTatlilar.Panel2.Controls.Add(this.btnRedVel);
            this.splitTatlilar.Panel2.Controls.Add(this.btnLimCheesecake);
            this.splitTatlilar.Panel2.Controls.Add(this.btnFramCheesecake);
            this.splitTatlilar.Panel2.Controls.Add(this.btnSanSeb);
            this.splitTatlilar.Size = new System.Drawing.Size(1255, 657);
            this.splitTatlilar.SplitterDistance = 326;
            this.splitTatlilar.TabIndex = 5;
            // 
            // btnMenuDon10
            // 
            this.btnMenuDon10.BackColor = System.Drawing.Color.Snow;
            this.btnMenuDon10.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.btnMenuDon10.Location = new System.Drawing.Point(775, 595);
            this.btnMenuDon10.Name = "btnMenuDon10";
            this.btnMenuDon10.Size = new System.Drawing.Size(138, 50);
            this.btnMenuDon10.TabIndex = 15;
            this.btnMenuDon10.Text = "Geri";
            this.btnMenuDon10.UseVisualStyleBackColor = false;
            this.btnMenuDon10.Click += new System.EventHandler(this.btnMenuDon10_Click);
            // 
            // dgwTatli
            // 
            this.dgwTatli.BackgroundColor = System.Drawing.Color.Snow;
            this.dgwTatli.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgwTatli.Location = new System.Drawing.Point(12, 12);
            this.dgwTatli.Name = "dgwTatli";
            this.dgwTatli.RowHeadersWidth = 62;
            this.dgwTatli.RowTemplate.Height = 28;
            this.dgwTatli.Size = new System.Drawing.Size(297, 503);
            this.dgwTatli.TabIndex = 14;
            // 
            // lblDilimPCilek
            // 
            this.lblDilimPCilek.AutoSize = true;
            this.lblDilimPCilek.BackColor = System.Drawing.Color.Snow;
            this.lblDilimPCilek.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.lblDilimPCilek.Location = new System.Drawing.Point(267, 553);
            this.lblDilimPCilek.Name = "lblDilimPCilek";
            this.lblDilimPCilek.Size = new System.Drawing.Size(34, 23);
            this.lblDilimPCilek.TabIndex = 24;
            this.lblDilimPCilek.Text = "45";
            // 
            // btnDilimPCilek
            // 
            this.btnDilimPCilek.BackColor = System.Drawing.Color.Snow;
            this.btnDilimPCilek.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.btnDilimPCilek.Location = new System.Drawing.Point(200, 400);
            this.btnDilimPCilek.Name = "btnDilimPCilek";
            this.btnDilimPCilek.Size = new System.Drawing.Size(182, 150);
            this.btnDilimPCilek.TabIndex = 23;
            this.btnDilimPCilek.Text = "Çilekli Dilim Pasta";
            this.btnDilimPCilek.UseVisualStyleBackColor = false;
            this.btnDilimPCilek.Click += new System.EventHandler(this.btnDilimPCilek_Click);
            // 
            // lblDilimPMeyve
            // 
            this.lblDilimPMeyve.AutoSize = true;
            this.lblDilimPMeyve.BackColor = System.Drawing.Color.Snow;
            this.lblDilimPMeyve.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.lblDilimPMeyve.Location = new System.Drawing.Point(86, 553);
            this.lblDilimPMeyve.Name = "lblDilimPMeyve";
            this.lblDilimPMeyve.Size = new System.Drawing.Size(34, 23);
            this.lblDilimPMeyve.TabIndex = 22;
            this.lblDilimPMeyve.Text = "45";
            // 
            // btnDilimPMeyve
            // 
            this.btnDilimPMeyve.BackColor = System.Drawing.Color.Snow;
            this.btnDilimPMeyve.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.btnDilimPMeyve.Location = new System.Drawing.Point(12, 400);
            this.btnDilimPMeyve.Name = "btnDilimPMeyve";
            this.btnDilimPMeyve.Size = new System.Drawing.Size(182, 150);
            this.btnDilimPMeyve.TabIndex = 21;
            this.btnDilimPMeyve.Text = "Meyveli Dilim Pasta";
            this.btnDilimPMeyve.UseVisualStyleBackColor = false;
            this.btnDilimPMeyve.Click += new System.EventHandler(this.btnDilimPMeyve_Click);
            // 
            // lblDilimPCiko
            // 
            this.lblDilimPCiko.AutoSize = true;
            this.lblDilimPCiko.BackColor = System.Drawing.Color.Snow;
            this.lblDilimPCiko.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.lblDilimPCiko.Location = new System.Drawing.Point(650, 350);
            this.lblDilimPCiko.Name = "lblDilimPCiko";
            this.lblDilimPCiko.Size = new System.Drawing.Size(34, 23);
            this.lblDilimPCiko.TabIndex = 20;
            this.lblDilimPCiko.Text = "45";
            // 
            // btnDilimPCiko
            // 
            this.btnDilimPCiko.BackColor = System.Drawing.Color.Snow;
            this.btnDilimPCiko.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.btnDilimPCiko.Location = new System.Drawing.Point(576, 197);
            this.btnDilimPCiko.Name = "btnDilimPCiko";
            this.btnDilimPCiko.Size = new System.Drawing.Size(182, 150);
            this.btnDilimPCiko.TabIndex = 19;
            this.btnDilimPCiko.Text = "Çikolatalı Dilim Pasta";
            this.btnDilimPCiko.UseVisualStyleBackColor = false;
            this.btnDilimPCiko.Click += new System.EventHandler(this.btnDilimPCiko_Click);
            // 
            // lblPastaProf
            // 
            this.lblPastaProf.AutoSize = true;
            this.lblPastaProf.BackColor = System.Drawing.Color.Snow;
            this.lblPastaProf.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.lblPastaProf.Location = new System.Drawing.Point(462, 350);
            this.lblPastaProf.Name = "lblPastaProf";
            this.lblPastaProf.Size = new System.Drawing.Size(34, 23);
            this.lblPastaProf.TabIndex = 18;
            this.lblPastaProf.Text = "45";
            // 
            // btnPastaProf
            // 
            this.btnPastaProf.BackColor = System.Drawing.Color.Snow;
            this.btnPastaProf.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.btnPastaProf.Location = new System.Drawing.Point(388, 197);
            this.btnPastaProf.Name = "btnPastaProf";
            this.btnPastaProf.Size = new System.Drawing.Size(182, 150);
            this.btnPastaProf.TabIndex = 17;
            this.btnPastaProf.Text = "Profiterol Pasta";
            this.btnPastaProf.UseVisualStyleBackColor = false;
            this.btnPastaProf.Click += new System.EventHandler(this.btnPastaProf_Click);
            // 
            // lblTrileceF
            // 
            this.lblTrileceF.AutoSize = true;
            this.lblTrileceF.BackColor = System.Drawing.Color.Snow;
            this.lblTrileceF.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.lblTrileceF.Location = new System.Drawing.Point(267, 350);
            this.lblTrileceF.Name = "lblTrileceF";
            this.lblTrileceF.Size = new System.Drawing.Size(34, 23);
            this.lblTrileceF.TabIndex = 16;
            this.lblTrileceF.Text = "45";
            // 
            // lblTrileceK
            // 
            this.lblTrileceK.AutoSize = true;
            this.lblTrileceK.BackColor = System.Drawing.Color.Snow;
            this.lblTrileceK.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.lblTrileceK.Location = new System.Drawing.Point(86, 350);
            this.lblTrileceK.Name = "lblTrileceK";
            this.lblTrileceK.Size = new System.Drawing.Size(34, 23);
            this.lblTrileceK.TabIndex = 15;
            this.lblTrileceK.Text = "45";
            // 
            // lblRedVel
            // 
            this.lblRedVel.AutoSize = true;
            this.lblRedVel.BackColor = System.Drawing.Color.Snow;
            this.lblRedVel.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.lblRedVel.Location = new System.Drawing.Point(650, 165);
            this.lblRedVel.Name = "lblRedVel";
            this.lblRedVel.Size = new System.Drawing.Size(34, 23);
            this.lblRedVel.TabIndex = 14;
            this.lblRedVel.Text = "40";
            // 
            // lblLimCheesecake
            // 
            this.lblLimCheesecake.AutoSize = true;
            this.lblLimCheesecake.BackColor = System.Drawing.Color.Snow;
            this.lblLimCheesecake.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.lblLimCheesecake.Location = new System.Drawing.Point(462, 165);
            this.lblLimCheesecake.Name = "lblLimCheesecake";
            this.lblLimCheesecake.Size = new System.Drawing.Size(34, 23);
            this.lblLimCheesecake.TabIndex = 13;
            this.lblLimCheesecake.Text = "40";
            // 
            // lblFramCheesecake
            // 
            this.lblFramCheesecake.AutoSize = true;
            this.lblFramCheesecake.BackColor = System.Drawing.Color.Snow;
            this.lblFramCheesecake.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.lblFramCheesecake.Location = new System.Drawing.Point(267, 165);
            this.lblFramCheesecake.Name = "lblFramCheesecake";
            this.lblFramCheesecake.Size = new System.Drawing.Size(34, 23);
            this.lblFramCheesecake.TabIndex = 12;
            this.lblFramCheesecake.Text = "40";
            // 
            // btnTrileceF
            // 
            this.btnTrileceF.BackColor = System.Drawing.Color.Snow;
            this.btnTrileceF.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.btnTrileceF.Location = new System.Drawing.Point(200, 197);
            this.btnTrileceF.Name = "btnTrileceF";
            this.btnTrileceF.Size = new System.Drawing.Size(182, 150);
            this.btnTrileceF.TabIndex = 9;
            this.btnTrileceF.Text = "Frambuazlı Trileçe";
            this.btnTrileceF.UseVisualStyleBackColor = false;
            this.btnTrileceF.Click += new System.EventHandler(this.btnTrileceF_Click);
            // 
            // btnTrileceK
            // 
            this.btnTrileceK.BackColor = System.Drawing.Color.Snow;
            this.btnTrileceK.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.btnTrileceK.Location = new System.Drawing.Point(12, 197);
            this.btnTrileceK.Name = "btnTrileceK";
            this.btnTrileceK.Size = new System.Drawing.Size(182, 150);
            this.btnTrileceK.TabIndex = 8;
            this.btnTrileceK.Text = "Karamelli Trileçe";
            this.btnTrileceK.UseVisualStyleBackColor = false;
            this.btnTrileceK.Click += new System.EventHandler(this.btnTrileceK_Click);
            // 
            // lblSanSeb
            // 
            this.lblSanSeb.AutoSize = true;
            this.lblSanSeb.BackColor = System.Drawing.Color.Snow;
            this.lblSanSeb.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.lblSanSeb.Location = new System.Drawing.Point(86, 165);
            this.lblSanSeb.Name = "lblSanSeb";
            this.lblSanSeb.Size = new System.Drawing.Size(34, 23);
            this.lblSanSeb.TabIndex = 7;
            this.lblSanSeb.Text = "50";
            // 
            // btnRedVel
            // 
            this.btnRedVel.BackColor = System.Drawing.Color.Snow;
            this.btnRedVel.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.btnRedVel.Location = new System.Drawing.Point(576, 12);
            this.btnRedVel.Name = "btnRedVel";
            this.btnRedVel.Size = new System.Drawing.Size(182, 150);
            this.btnRedVel.TabIndex = 6;
            this.btnRedVel.Text = "Red Velvet";
            this.btnRedVel.UseVisualStyleBackColor = false;
            this.btnRedVel.Click += new System.EventHandler(this.btnRedVel_Click);
            // 
            // btnLimCheesecake
            // 
            this.btnLimCheesecake.BackColor = System.Drawing.Color.Snow;
            this.btnLimCheesecake.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.btnLimCheesecake.Location = new System.Drawing.Point(388, 12);
            this.btnLimCheesecake.Name = "btnLimCheesecake";
            this.btnLimCheesecake.Size = new System.Drawing.Size(182, 150);
            this.btnLimCheesecake.TabIndex = 2;
            this.btnLimCheesecake.Text = "Limonlu Cheesecake";
            this.btnLimCheesecake.UseVisualStyleBackColor = false;
            this.btnLimCheesecake.Click += new System.EventHandler(this.btnLimCheesecake_Click);
            // 
            // btnFramCheesecake
            // 
            this.btnFramCheesecake.BackColor = System.Drawing.Color.Snow;
            this.btnFramCheesecake.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.btnFramCheesecake.Location = new System.Drawing.Point(200, 12);
            this.btnFramCheesecake.Name = "btnFramCheesecake";
            this.btnFramCheesecake.Size = new System.Drawing.Size(182, 150);
            this.btnFramCheesecake.TabIndex = 1;
            this.btnFramCheesecake.Text = "Frambuazlı Cheesecake";
            this.btnFramCheesecake.UseVisualStyleBackColor = false;
            this.btnFramCheesecake.Click += new System.EventHandler(this.btnFramCheesecake_Click);
            // 
            // btnSanSeb
            // 
            this.btnSanSeb.BackColor = System.Drawing.Color.Snow;
            this.btnSanSeb.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.btnSanSeb.Location = new System.Drawing.Point(12, 12);
            this.btnSanSeb.Name = "btnSanSeb";
            this.btnSanSeb.Size = new System.Drawing.Size(182, 150);
            this.btnSanSeb.TabIndex = 0;
            this.btnSanSeb.Text = "Çikolatalı San Sebastian";
            this.btnSanSeb.UseVisualStyleBackColor = false;
            this.btnSanSeb.Click += new System.EventHandler(this.btnSanSeb_Click);
            // 
            // TatlilarForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.RosyBrown;
            this.ClientSize = new System.Drawing.Size(1255, 657);
            this.Controls.Add(this.splitTatlilar);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "TatlilarForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Tatlılar";
            this.Load += new System.EventHandler(this.TatlilarForm_Load);
            this.splitTatlilar.Panel1.ResumeLayout(false);
            this.splitTatlilar.Panel2.ResumeLayout(false);
            this.splitTatlilar.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitTatlilar)).EndInit();
            this.splitTatlilar.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgwTatli)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.SplitContainer splitTatlilar;
        private System.Windows.Forms.Label lblPastaProf;
        private System.Windows.Forms.Button btnPastaProf;
        private System.Windows.Forms.Label lblTrileceF;
        private System.Windows.Forms.Label lblTrileceK;
        private System.Windows.Forms.Label lblRedVel;
        private System.Windows.Forms.Label lblLimCheesecake;
        private System.Windows.Forms.Label lblFramCheesecake;
        private System.Windows.Forms.Button btnTrileceF;
        private System.Windows.Forms.Button btnTrileceK;
        private System.Windows.Forms.Label lblSanSeb;
        private System.Windows.Forms.Button btnRedVel;
        private System.Windows.Forms.Button btnLimCheesecake;
        private System.Windows.Forms.Button btnFramCheesecake;
        private System.Windows.Forms.Button btnSanSeb;
        private System.Windows.Forms.Label lblDilimPCilek;
        private System.Windows.Forms.Button btnDilimPCilek;
        private System.Windows.Forms.Label lblDilimPMeyve;
        private System.Windows.Forms.Button btnDilimPMeyve;
        private System.Windows.Forms.Label lblDilimPCiko;
        private System.Windows.Forms.Button btnDilimPCiko;
        private System.Windows.Forms.Button btnMenuDon10;
        private System.Windows.Forms.DataGridView dgwTatli;
    }
}