﻿
namespace KafeOtomasyonu
{
    partial class TostlarForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(TostlarForm));
            this.splitTost = new System.Windows.Forms.SplitContainer();
            this.btnMenuDon2 = new System.Windows.Forms.Button();
            this.dgwTost = new System.Windows.Forms.DataGridView();
            this.lblPizzaTost = new System.Windows.Forms.Label();
            this.lblAyvalik = new System.Windows.Forms.Label();
            this.lblBazlamaKarisik = new System.Windows.Forms.Label();
            this.lblBazlamaSucuk = new System.Windows.Forms.Label();
            this.lblBazlamaKasar = new System.Windows.Forms.Label();
            this.lblKarisik = new System.Windows.Forms.Label();
            this.lblSucuklu = new System.Windows.Forms.Label();
            this.btnPizzaTost = new System.Windows.Forms.Button();
            this.btnAyvalik = new System.Windows.Forms.Button();
            this.btnBazlamaKarisik = new System.Windows.Forms.Button();
            this.btnBazlamaSucuk = new System.Windows.Forms.Button();
            this.lblKasarli = new System.Windows.Forms.Label();
            this.btnBazlamaKasar = new System.Windows.Forms.Button();
            this.btnKarisik = new System.Windows.Forms.Button();
            this.btnSucuklu = new System.Windows.Forms.Button();
            this.btnKasarli = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.splitTost)).BeginInit();
            this.splitTost.Panel1.SuspendLayout();
            this.splitTost.Panel2.SuspendLayout();
            this.splitTost.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgwTost)).BeginInit();
            this.SuspendLayout();
            // 
            // splitTost
            // 
            this.splitTost.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitTost.Location = new System.Drawing.Point(0, 0);
            this.splitTost.Name = "splitTost";
            // 
            // splitTost.Panel1
            // 
            this.splitTost.Panel1.Controls.Add(this.dgwTost);
            // 
            // splitTost.Panel2
            // 
            this.splitTost.Panel2.Controls.Add(this.btnMenuDon2);
            this.splitTost.Panel2.Controls.Add(this.lblPizzaTost);
            this.splitTost.Panel2.Controls.Add(this.lblAyvalik);
            this.splitTost.Panel2.Controls.Add(this.lblBazlamaKarisik);
            this.splitTost.Panel2.Controls.Add(this.lblBazlamaSucuk);
            this.splitTost.Panel2.Controls.Add(this.lblBazlamaKasar);
            this.splitTost.Panel2.Controls.Add(this.lblKarisik);
            this.splitTost.Panel2.Controls.Add(this.lblSucuklu);
            this.splitTost.Panel2.Controls.Add(this.btnPizzaTost);
            this.splitTost.Panel2.Controls.Add(this.btnAyvalik);
            this.splitTost.Panel2.Controls.Add(this.btnBazlamaKarisik);
            this.splitTost.Panel2.Controls.Add(this.btnBazlamaSucuk);
            this.splitTost.Panel2.Controls.Add(this.lblKasarli);
            this.splitTost.Panel2.Controls.Add(this.btnBazlamaKasar);
            this.splitTost.Panel2.Controls.Add(this.btnKarisik);
            this.splitTost.Panel2.Controls.Add(this.btnSucuklu);
            this.splitTost.Panel2.Controls.Add(this.btnKasarli);
            this.splitTost.Size = new System.Drawing.Size(1255, 657);
            this.splitTost.SplitterDistance = 326;
            this.splitTost.TabIndex = 1;
            // 
            // btnMenuDon2
            // 
            this.btnMenuDon2.BackColor = System.Drawing.Color.Snow;
            this.btnMenuDon2.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.btnMenuDon2.Location = new System.Drawing.Point(775, 595);
            this.btnMenuDon2.Name = "btnMenuDon2";
            this.btnMenuDon2.Size = new System.Drawing.Size(138, 50);
            this.btnMenuDon2.TabIndex = 3;
            this.btnMenuDon2.Text = "Geri";
            this.btnMenuDon2.UseVisualStyleBackColor = false;
            this.btnMenuDon2.Click += new System.EventHandler(this.btnMenuDon2_Click);
            // 
            // dgwTost
            // 
            this.dgwTost.BackgroundColor = System.Drawing.Color.Snow;
            this.dgwTost.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgwTost.Location = new System.Drawing.Point(12, 12);
            this.dgwTost.Name = "dgwTost";
            this.dgwTost.RowHeadersWidth = 62;
            this.dgwTost.RowTemplate.Height = 28;
            this.dgwTost.Size = new System.Drawing.Size(297, 503);
            this.dgwTost.TabIndex = 2;
            // 
            // lblPizzaTost
            // 
            this.lblPizzaTost.AutoSize = true;
            this.lblPizzaTost.BackColor = System.Drawing.Color.Snow;
            this.lblPizzaTost.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.lblPizzaTost.Location = new System.Drawing.Point(650, 350);
            this.lblPizzaTost.Name = "lblPizzaTost";
            this.lblPizzaTost.Size = new System.Drawing.Size(34, 23);
            this.lblPizzaTost.TabIndex = 18;
            this.lblPizzaTost.Text = "40";
            // 
            // lblAyvalik
            // 
            this.lblAyvalik.AutoSize = true;
            this.lblAyvalik.BackColor = System.Drawing.Color.Snow;
            this.lblAyvalik.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.lblAyvalik.Location = new System.Drawing.Point(462, 350);
            this.lblAyvalik.Name = "lblAyvalik";
            this.lblAyvalik.Size = new System.Drawing.Size(34, 23);
            this.lblAyvalik.TabIndex = 17;
            this.lblAyvalik.Text = "40";
            // 
            // lblBazlamaKarisik
            // 
            this.lblBazlamaKarisik.AutoSize = true;
            this.lblBazlamaKarisik.BackColor = System.Drawing.Color.Snow;
            this.lblBazlamaKarisik.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.lblBazlamaKarisik.Location = new System.Drawing.Point(267, 350);
            this.lblBazlamaKarisik.Name = "lblBazlamaKarisik";
            this.lblBazlamaKarisik.Size = new System.Drawing.Size(34, 23);
            this.lblBazlamaKarisik.TabIndex = 16;
            this.lblBazlamaKarisik.Text = "35";
            // 
            // lblBazlamaSucuk
            // 
            this.lblBazlamaSucuk.AutoSize = true;
            this.lblBazlamaSucuk.BackColor = System.Drawing.Color.Snow;
            this.lblBazlamaSucuk.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.lblBazlamaSucuk.Location = new System.Drawing.Point(86, 350);
            this.lblBazlamaSucuk.Name = "lblBazlamaSucuk";
            this.lblBazlamaSucuk.Size = new System.Drawing.Size(34, 23);
            this.lblBazlamaSucuk.TabIndex = 15;
            this.lblBazlamaSucuk.Text = "30";
            // 
            // lblBazlamaKasar
            // 
            this.lblBazlamaKasar.AutoSize = true;
            this.lblBazlamaKasar.BackColor = System.Drawing.Color.Snow;
            this.lblBazlamaKasar.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.lblBazlamaKasar.Location = new System.Drawing.Point(650, 165);
            this.lblBazlamaKasar.Name = "lblBazlamaKasar";
            this.lblBazlamaKasar.Size = new System.Drawing.Size(34, 23);
            this.lblBazlamaKasar.TabIndex = 14;
            this.lblBazlamaKasar.Text = "25";
            // 
            // lblKarisik
            // 
            this.lblKarisik.AutoSize = true;
            this.lblKarisik.BackColor = System.Drawing.Color.Snow;
            this.lblKarisik.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.lblKarisik.Location = new System.Drawing.Point(462, 165);
            this.lblKarisik.Name = "lblKarisik";
            this.lblKarisik.Size = new System.Drawing.Size(34, 23);
            this.lblKarisik.TabIndex = 13;
            this.lblKarisik.Text = "25";
            // 
            // lblSucuklu
            // 
            this.lblSucuklu.AutoSize = true;
            this.lblSucuklu.BackColor = System.Drawing.Color.Snow;
            this.lblSucuklu.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.lblSucuklu.Location = new System.Drawing.Point(267, 165);
            this.lblSucuklu.Name = "lblSucuklu";
            this.lblSucuklu.Size = new System.Drawing.Size(34, 23);
            this.lblSucuklu.TabIndex = 12;
            this.lblSucuklu.Text = "20";
            // 
            // btnPizzaTost
            // 
            this.btnPizzaTost.BackColor = System.Drawing.Color.Snow;
            this.btnPizzaTost.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.btnPizzaTost.Location = new System.Drawing.Point(576, 197);
            this.btnPizzaTost.Name = "btnPizzaTost";
            this.btnPizzaTost.Size = new System.Drawing.Size(182, 150);
            this.btnPizzaTost.TabIndex = 11;
            this.btnPizzaTost.Text = "Pizza Tost";
            this.btnPizzaTost.UseVisualStyleBackColor = false;
            this.btnPizzaTost.Click += new System.EventHandler(this.btnPizzaTost_Click);
            // 
            // btnAyvalik
            // 
            this.btnAyvalik.BackColor = System.Drawing.Color.Snow;
            this.btnAyvalik.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.btnAyvalik.Location = new System.Drawing.Point(388, 197);
            this.btnAyvalik.Name = "btnAyvalik";
            this.btnAyvalik.Size = new System.Drawing.Size(182, 150);
            this.btnAyvalik.TabIndex = 10;
            this.btnAyvalik.Text = "Ayvalık Tostu";
            this.btnAyvalik.UseVisualStyleBackColor = false;
            this.btnAyvalik.Click += new System.EventHandler(this.btnAyvalik_Click);
            // 
            // btnBazlamaKarisik
            // 
            this.btnBazlamaKarisik.BackColor = System.Drawing.Color.Snow;
            this.btnBazlamaKarisik.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.btnBazlamaKarisik.Location = new System.Drawing.Point(200, 197);
            this.btnBazlamaKarisik.Name = "btnBazlamaKarisik";
            this.btnBazlamaKarisik.Size = new System.Drawing.Size(182, 150);
            this.btnBazlamaKarisik.TabIndex = 9;
            this.btnBazlamaKarisik.Text = "Karışık Bazlama Tost";
            this.btnBazlamaKarisik.UseVisualStyleBackColor = false;
            this.btnBazlamaKarisik.Click += new System.EventHandler(this.btnBazlamaKarisik_Click);
            // 
            // btnBazlamaSucuk
            // 
            this.btnBazlamaSucuk.BackColor = System.Drawing.Color.Snow;
            this.btnBazlamaSucuk.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.btnBazlamaSucuk.Location = new System.Drawing.Point(12, 197);
            this.btnBazlamaSucuk.Name = "btnBazlamaSucuk";
            this.btnBazlamaSucuk.Size = new System.Drawing.Size(182, 150);
            this.btnBazlamaSucuk.TabIndex = 8;
            this.btnBazlamaSucuk.Text = "Sucuklu Bazlama Tost";
            this.btnBazlamaSucuk.UseVisualStyleBackColor = false;
            this.btnBazlamaSucuk.Click += new System.EventHandler(this.btnBazlamaSucuk_Click);
            // 
            // lblKasarli
            // 
            this.lblKasarli.AutoSize = true;
            this.lblKasarli.BackColor = System.Drawing.Color.Snow;
            this.lblKasarli.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.lblKasarli.Location = new System.Drawing.Point(86, 165);
            this.lblKasarli.Name = "lblKasarli";
            this.lblKasarli.Size = new System.Drawing.Size(34, 23);
            this.lblKasarli.TabIndex = 7;
            this.lblKasarli.Text = "15";
            // 
            // btnBazlamaKasar
            // 
            this.btnBazlamaKasar.BackColor = System.Drawing.Color.Snow;
            this.btnBazlamaKasar.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.btnBazlamaKasar.Location = new System.Drawing.Point(576, 12);
            this.btnBazlamaKasar.Name = "btnBazlamaKasar";
            this.btnBazlamaKasar.Size = new System.Drawing.Size(182, 150);
            this.btnBazlamaKasar.TabIndex = 6;
            this.btnBazlamaKasar.Text = "Kaşarlı Bazlama Tost";
            this.btnBazlamaKasar.UseVisualStyleBackColor = false;
            this.btnBazlamaKasar.Click += new System.EventHandler(this.btnBazlamaKasar_Click);
            // 
            // btnKarisik
            // 
            this.btnKarisik.BackColor = System.Drawing.Color.Snow;
            this.btnKarisik.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.btnKarisik.Location = new System.Drawing.Point(388, 12);
            this.btnKarisik.Name = "btnKarisik";
            this.btnKarisik.Size = new System.Drawing.Size(182, 150);
            this.btnKarisik.TabIndex = 2;
            this.btnKarisik.Text = "Karışık Tost";
            this.btnKarisik.UseVisualStyleBackColor = false;
            this.btnKarisik.Click += new System.EventHandler(this.btnKarisik_Click);
            // 
            // btnSucuklu
            // 
            this.btnSucuklu.BackColor = System.Drawing.Color.Snow;
            this.btnSucuklu.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.btnSucuklu.Location = new System.Drawing.Point(200, 12);
            this.btnSucuklu.Name = "btnSucuklu";
            this.btnSucuklu.Size = new System.Drawing.Size(182, 150);
            this.btnSucuklu.TabIndex = 1;
            this.btnSucuklu.Text = "Sucuklu Tost";
            this.btnSucuklu.UseVisualStyleBackColor = false;
            this.btnSucuklu.Click += new System.EventHandler(this.btnSucuklu_Click);
            // 
            // btnKasarli
            // 
            this.btnKasarli.BackColor = System.Drawing.Color.Snow;
            this.btnKasarli.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.btnKasarli.Location = new System.Drawing.Point(12, 12);
            this.btnKasarli.Name = "btnKasarli";
            this.btnKasarli.Size = new System.Drawing.Size(182, 150);
            this.btnKasarli.TabIndex = 0;
            this.btnKasarli.Text = "Kaşarlı Tost";
            this.btnKasarli.UseVisualStyleBackColor = false;
            this.btnKasarli.Click += new System.EventHandler(this.btnKasarli_Click);
            // 
            // TostlarForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.RosyBrown;
            this.ClientSize = new System.Drawing.Size(1255, 657);
            this.Controls.Add(this.splitTost);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "TostlarForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Tostlar";
            this.Load += new System.EventHandler(this.TostlarForm_Load);
            this.splitTost.Panel1.ResumeLayout(false);
            this.splitTost.Panel2.ResumeLayout(false);
            this.splitTost.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitTost)).EndInit();
            this.splitTost.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgwTost)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.SplitContainer splitTost;
        private System.Windows.Forms.Button btnKarisik;
        private System.Windows.Forms.Button btnSucuklu;
        private System.Windows.Forms.Button btnKasarli;
        private System.Windows.Forms.Button btnBazlamaKasar;
        private System.Windows.Forms.Label lblPizzaTost;
        private System.Windows.Forms.Label lblAyvalik;
        private System.Windows.Forms.Label lblBazlamaKarisik;
        private System.Windows.Forms.Label lblBazlamaSucuk;
        private System.Windows.Forms.Label lblBazlamaKasar;
        private System.Windows.Forms.Label lblKarisik;
        private System.Windows.Forms.Label lblSucuklu;
        private System.Windows.Forms.Button btnPizzaTost;
        private System.Windows.Forms.Button btnAyvalik;
        private System.Windows.Forms.Button btnBazlamaKarisik;
        private System.Windows.Forms.Button btnBazlamaSucuk;
        private System.Windows.Forms.Label lblKasarli;
        private System.Windows.Forms.Button btnMenuDon2;
        private System.Windows.Forms.DataGridView dgwTost;
    }
}