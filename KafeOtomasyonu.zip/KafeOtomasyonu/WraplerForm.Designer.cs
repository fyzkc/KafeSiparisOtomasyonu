﻿
namespace KafeOtomasyonu
{
    partial class WraplerForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(WraplerForm));
            this.splitWrap = new System.Windows.Forms.SplitContainer();
            this.btnMenuDon4 = new System.Windows.Forms.Button();
            this.dgwWrap = new System.Windows.Forms.DataGridView();
            this.lblSebzeWrap = new System.Windows.Forms.Label();
            this.lblVeganWrap = new System.Windows.Forms.Label();
            this.lblEtWrap = new System.Windows.Forms.Label();
            this.lblMantarWrap = new System.Windows.Forms.Label();
            this.lblTavukWrap = new System.Windows.Forms.Label();
            this.btnSebzeWrap = new System.Windows.Forms.Button();
            this.btnVeganWrap = new System.Windows.Forms.Button();
            this.lblKofteWrap = new System.Windows.Forms.Label();
            this.btnEtWrap = new System.Windows.Forms.Button();
            this.btnMantarWrap = new System.Windows.Forms.Button();
            this.btnTavukWrap = new System.Windows.Forms.Button();
            this.btnKofteWrap = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.splitWrap)).BeginInit();
            this.splitWrap.Panel1.SuspendLayout();
            this.splitWrap.Panel2.SuspendLayout();
            this.splitWrap.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgwWrap)).BeginInit();
            this.SuspendLayout();
            // 
            // splitWrap
            // 
            this.splitWrap.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitWrap.Location = new System.Drawing.Point(0, 0);
            this.splitWrap.Name = "splitWrap";
            // 
            // splitWrap.Panel1
            // 
            this.splitWrap.Panel1.Controls.Add(this.dgwWrap);
            // 
            // splitWrap.Panel2
            // 
            this.splitWrap.Panel2.Controls.Add(this.btnMenuDon4);
            this.splitWrap.Panel2.Controls.Add(this.lblSebzeWrap);
            this.splitWrap.Panel2.Controls.Add(this.lblVeganWrap);
            this.splitWrap.Panel2.Controls.Add(this.lblEtWrap);
            this.splitWrap.Panel2.Controls.Add(this.lblMantarWrap);
            this.splitWrap.Panel2.Controls.Add(this.lblTavukWrap);
            this.splitWrap.Panel2.Controls.Add(this.btnSebzeWrap);
            this.splitWrap.Panel2.Controls.Add(this.btnVeganWrap);
            this.splitWrap.Panel2.Controls.Add(this.lblKofteWrap);
            this.splitWrap.Panel2.Controls.Add(this.btnEtWrap);
            this.splitWrap.Panel2.Controls.Add(this.btnMantarWrap);
            this.splitWrap.Panel2.Controls.Add(this.btnTavukWrap);
            this.splitWrap.Panel2.Controls.Add(this.btnKofteWrap);
            this.splitWrap.Size = new System.Drawing.Size(1255, 657);
            this.splitWrap.SplitterDistance = 326;
            this.splitWrap.TabIndex = 3;
            // 
            // btnMenuDon4
            // 
            this.btnMenuDon4.BackColor = System.Drawing.Color.Snow;
            this.btnMenuDon4.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.btnMenuDon4.Location = new System.Drawing.Point(775, 595);
            this.btnMenuDon4.Name = "btnMenuDon4";
            this.btnMenuDon4.Size = new System.Drawing.Size(138, 50);
            this.btnMenuDon4.TabIndex = 3;
            this.btnMenuDon4.Text = "Geri";
            this.btnMenuDon4.UseVisualStyleBackColor = false;
            this.btnMenuDon4.Click += new System.EventHandler(this.btnMenuDon4_Click);
            // 
            // dgwWrap
            // 
            this.dgwWrap.BackgroundColor = System.Drawing.Color.Snow;
            this.dgwWrap.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgwWrap.Location = new System.Drawing.Point(12, 12);
            this.dgwWrap.Name = "dgwWrap";
            this.dgwWrap.RowHeadersWidth = 62;
            this.dgwWrap.RowTemplate.Height = 28;
            this.dgwWrap.Size = new System.Drawing.Size(297, 503);
            this.dgwWrap.TabIndex = 2;
            // 
            // lblSebzeWrap
            // 
            this.lblSebzeWrap.AutoSize = true;
            this.lblSebzeWrap.BackColor = System.Drawing.Color.Snow;
            this.lblSebzeWrap.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.lblSebzeWrap.Location = new System.Drawing.Point(274, 350);
            this.lblSebzeWrap.Name = "lblSebzeWrap";
            this.lblSebzeWrap.Size = new System.Drawing.Size(34, 23);
            this.lblSebzeWrap.TabIndex = 16;
            this.lblSebzeWrap.Text = "35";
            // 
            // lblVeganWrap
            // 
            this.lblVeganWrap.AutoSize = true;
            this.lblVeganWrap.BackColor = System.Drawing.Color.Snow;
            this.lblVeganWrap.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.lblVeganWrap.Location = new System.Drawing.Point(86, 350);
            this.lblVeganWrap.Name = "lblVeganWrap";
            this.lblVeganWrap.Size = new System.Drawing.Size(34, 23);
            this.lblVeganWrap.TabIndex = 15;
            this.lblVeganWrap.Text = "50";
            // 
            // lblEtWrap
            // 
            this.lblEtWrap.AutoSize = true;
            this.lblEtWrap.BackColor = System.Drawing.Color.Snow;
            this.lblEtWrap.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.lblEtWrap.Location = new System.Drawing.Point(650, 165);
            this.lblEtWrap.Name = "lblEtWrap";
            this.lblEtWrap.Size = new System.Drawing.Size(34, 23);
            this.lblEtWrap.TabIndex = 14;
            this.lblEtWrap.Text = "55";
            // 
            // lblMantarWrap
            // 
            this.lblMantarWrap.AutoSize = true;
            this.lblMantarWrap.BackColor = System.Drawing.Color.Snow;
            this.lblMantarWrap.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.lblMantarWrap.Location = new System.Drawing.Point(462, 165);
            this.lblMantarWrap.Name = "lblMantarWrap";
            this.lblMantarWrap.Size = new System.Drawing.Size(34, 23);
            this.lblMantarWrap.TabIndex = 13;
            this.lblMantarWrap.Text = "35";
            // 
            // lblTavukWrap
            // 
            this.lblTavukWrap.AutoSize = true;
            this.lblTavukWrap.BackColor = System.Drawing.Color.Snow;
            this.lblTavukWrap.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.lblTavukWrap.Location = new System.Drawing.Point(274, 165);
            this.lblTavukWrap.Name = "lblTavukWrap";
            this.lblTavukWrap.Size = new System.Drawing.Size(34, 23);
            this.lblTavukWrap.TabIndex = 12;
            this.lblTavukWrap.Text = "40";
            // 
            // btnSebzeWrap
            // 
            this.btnSebzeWrap.BackColor = System.Drawing.Color.Snow;
            this.btnSebzeWrap.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.btnSebzeWrap.Location = new System.Drawing.Point(200, 197);
            this.btnSebzeWrap.Name = "btnSebzeWrap";
            this.btnSebzeWrap.Size = new System.Drawing.Size(182, 150);
            this.btnSebzeWrap.TabIndex = 9;
            this.btnSebzeWrap.Text = "Sebzeli Wrap";
            this.btnSebzeWrap.UseVisualStyleBackColor = false;
            this.btnSebzeWrap.Click += new System.EventHandler(this.btnSebzeWrap_Click);
            // 
            // btnVeganWrap
            // 
            this.btnVeganWrap.BackColor = System.Drawing.Color.Snow;
            this.btnVeganWrap.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.btnVeganWrap.Location = new System.Drawing.Point(12, 197);
            this.btnVeganWrap.Name = "btnVeganWrap";
            this.btnVeganWrap.Size = new System.Drawing.Size(182, 150);
            this.btnVeganWrap.TabIndex = 8;
            this.btnVeganWrap.Text = "Vegan Wrap";
            this.btnVeganWrap.UseVisualStyleBackColor = false;
            this.btnVeganWrap.Click += new System.EventHandler(this.btnVeganWrap_Click);
            // 
            // lblKofteWrap
            // 
            this.lblKofteWrap.AutoSize = true;
            this.lblKofteWrap.BackColor = System.Drawing.Color.Snow;
            this.lblKofteWrap.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.lblKofteWrap.Location = new System.Drawing.Point(86, 165);
            this.lblKofteWrap.Name = "lblKofteWrap";
            this.lblKofteWrap.Size = new System.Drawing.Size(34, 23);
            this.lblKofteWrap.TabIndex = 7;
            this.lblKofteWrap.Text = "50";
            // 
            // btnEtWrap
            // 
            this.btnEtWrap.BackColor = System.Drawing.Color.Snow;
            this.btnEtWrap.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.btnEtWrap.Location = new System.Drawing.Point(576, 12);
            this.btnEtWrap.Name = "btnEtWrap";
            this.btnEtWrap.Size = new System.Drawing.Size(182, 150);
            this.btnEtWrap.TabIndex = 6;
            this.btnEtWrap.Text = "Etli Wrap";
            this.btnEtWrap.UseVisualStyleBackColor = false;
            this.btnEtWrap.Click += new System.EventHandler(this.btnEtWrap_Click);
            // 
            // btnMantarWrap
            // 
            this.btnMantarWrap.BackColor = System.Drawing.Color.Snow;
            this.btnMantarWrap.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.btnMantarWrap.Location = new System.Drawing.Point(388, 12);
            this.btnMantarWrap.Name = "btnMantarWrap";
            this.btnMantarWrap.Size = new System.Drawing.Size(182, 150);
            this.btnMantarWrap.TabIndex = 2;
            this.btnMantarWrap.Text = "Mantarlı Wrap";
            this.btnMantarWrap.UseVisualStyleBackColor = false;
            this.btnMantarWrap.Click += new System.EventHandler(this.btnMantarWrap_Click);
            // 
            // btnTavukWrap
            // 
            this.btnTavukWrap.BackColor = System.Drawing.Color.Snow;
            this.btnTavukWrap.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.btnTavukWrap.Location = new System.Drawing.Point(200, 12);
            this.btnTavukWrap.Name = "btnTavukWrap";
            this.btnTavukWrap.Size = new System.Drawing.Size(182, 150);
            this.btnTavukWrap.TabIndex = 1;
            this.btnTavukWrap.Text = "Tavuklu Wrap";
            this.btnTavukWrap.UseVisualStyleBackColor = false;
            this.btnTavukWrap.Click += new System.EventHandler(this.btnTavukWrap_Click);
            // 
            // btnKofteWrap
            // 
            this.btnKofteWrap.BackColor = System.Drawing.Color.Snow;
            this.btnKofteWrap.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.btnKofteWrap.Location = new System.Drawing.Point(12, 12);
            this.btnKofteWrap.Name = "btnKofteWrap";
            this.btnKofteWrap.Size = new System.Drawing.Size(182, 150);
            this.btnKofteWrap.TabIndex = 0;
            this.btnKofteWrap.Text = "Köfte Wrap";
            this.btnKofteWrap.UseVisualStyleBackColor = false;
            this.btnKofteWrap.Click += new System.EventHandler(this.btnKofteWrap_Click);
            // 
            // WraplerForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.RosyBrown;
            this.ClientSize = new System.Drawing.Size(1255, 657);
            this.Controls.Add(this.splitWrap);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "WraplerForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Wrapler";
            this.Load += new System.EventHandler(this.WraplerForm_Load);
            this.splitWrap.Panel1.ResumeLayout(false);
            this.splitWrap.Panel2.ResumeLayout(false);
            this.splitWrap.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitWrap)).EndInit();
            this.splitWrap.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgwWrap)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.SplitContainer splitWrap;
        private System.Windows.Forms.Label lblSebzeWrap;
        private System.Windows.Forms.Label lblVeganWrap;
        private System.Windows.Forms.Label lblEtWrap;
        private System.Windows.Forms.Label lblMantarWrap;
        private System.Windows.Forms.Label lblTavukWrap;
        private System.Windows.Forms.Button btnSebzeWrap;
        private System.Windows.Forms.Button btnVeganWrap;
        private System.Windows.Forms.Label lblKofteWrap;
        private System.Windows.Forms.Button btnEtWrap;
        private System.Windows.Forms.Button btnMantarWrap;
        private System.Windows.Forms.Button btnTavukWrap;
        private System.Windows.Forms.Button btnKofteWrap;
        private System.Windows.Forms.Button btnMenuDon4;
        private System.Windows.Forms.DataGridView dgwWrap;
    }
}